<?php
/**
 * دمج RustDesk للتحكم عن بعد
 */

function generateRustDeskConfig($device_id) {
    // توليد معرف RustDesk فريد (في الواقع، هذا سيكون معرف RustDesk الفعلي)
    // هنا نستخدم معرفاً وهمياً للتوضيح
    
    $rustdesk_id = generateRustDeskId($device_id);
    $rustdesk_password = generateRandomPassword(8);
    
    return [
        'id' => $rustdesk_id,
        'password' => $rustdesk_password,
        'relay_server' => 'rs-relay.rustdesk.com',
        'api_server' => 'rs-api.rustdesk.com',
        'direct_link' => "rustdesk://{$rustdesk_id}"
    ];
}

function generateRustDeskId($device_id) {
    // توليد معرف RustDesk من معرف الجهاز
    $hash = hash('sha256', $device_id . 'rustdesk_salt_' . time());
    return substr($hash, 0, 16);
}

function generateRandomPassword($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

function saveRustDeskCredentials($device_id, $rustdesk_id, $rustdesk_password) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE devices 
            SET rustdesk_id = :rustdesk_id, 
                rustdesk_password = :rustdesk_password 
            WHERE device_id = :device_id
        ");
        
        $stmt->execute([
            ':rustdesk_id' => $rustdesk_id,
            ':rustdesk_password' => password_hash($rustdesk_password, PASSWORD_DEFAULT),
            ':device_id' => $device_id
        ]);
        
        return true;
    } catch (PDOException $e) {
        error_log("RustDesk Error: " . $e->getMessage());
        return false;
    }
}

function getRustDeskConnection($device_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT rustdesk_id, rustdesk_password 
        FROM devices 
        WHERE device_id = :device_id
    ");
    $stmt->execute([':device_id' => $device_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($data && $data['rustdesk_id'] && $data['rustdesk_password']) {
        return [
            'id' => $data['rustdesk_id'],
            'password' => $data['rustdesk_password']
        ];
    }
    
    return null;
}

/**
 * إعداد RustDesk على الجهاز الوكيل
 */
function setupRustDeskOnAgent($device_id, $agent_config) {
    // هذا سيكون جزءاً من ملف الـAgent
    $rustdesk_config = generateRustDeskConfig($device_id);
    
    // إضافة إعدادات RustDesk لملف التكوين
    $agent_config['rustdesk'] = $rustdesk_config;
    
    // في الواقع، هنا نرسل أوامر لإعداد RustDesk على الجهاز البعيد
    // أو نضيفه لملف التثبيت
    
    return $agent_config;
}
?>