<?php
header('Content-Type: application/json');
session_start();

require_once '../includes/auth_check.php';

// التحقق من الصلاحيات
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    echo json_encode(['error' => 'غير مصرح لك']);
    exit();
}

// قراءة البيانات
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['device_name'])) {
    echo json_encode(['error' => 'بيانات غير مكتملة']);
    exit();
}

// توليد معرف فريد للجهاز
$device_id = 'DEV_' . strtoupper(bin2hex(random_bytes(8)));
$server_url = isset($data['server_url']) ? $data['server_url'] : 
              'http://' . $_SERVER['HTTP_HOST'] . dirname(dirname($_SERVER['REQUEST_URI']));

// إنشاء محتوى ملف الـAgent المعدل
$agent_template = <<<PYTHON
import psutil
import platform
import socket
import requests
import json
import time
from datetime import datetime
import os
import sys
import winreg

DEVICE_ID = "{$device_id}"
DEVICE_NAME = "{$data['device_name']}"
SERVER_URL = "{$server_url}"
DEVICE_GROUP = "{$data['device_group']}"

class DeviceMonitor:
    def __init__(self):
        self.device_info = self.get_system_info()
        
    def get_system_info(self):
        """جمع معلومات النظام"""
        return {
            'device_id': DEVICE_ID,
            'device_name': DEVICE_NAME,
            'device_group': DEVICE_GROUP,
            'os_name': platform.system(),
            'os_version': platform.version(),
            'cpu_name': platform.processor(),
            'cpu_cores': psutil.cpu_count(logical=False),
            'total_ram_gb': round(psutil.virtual_memory().total / (1024**3), 2),
            'total_disk_gb': round(psutil.disk_usage('C:').total / (1024**3), 2),
            'mac_address': ':'.join(['{:02x}'.format((int.from_bytes(psutil.net_if_addrs()['Ethernet'][0].address.encode(), 'little') >> i) & 0xff) for i in range(0, 48, 8)])
        }
    
    def send_data(self, data):
        """إرسال البيانات للسيرفر"""
        try:
            response = requests.post(
                f"{SERVER_URL}/api/save_metrics.php",
                json=data,
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            print(f"Error sending: {e}")
            return False
    
    def add_to_startup(self):
        """إضافة للتشغيل التلقائي"""
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                0, winreg.KEY_SET_VALUE
            )
            exe_path = os.path.abspath(sys.argv[0])
            winreg.SetValueEx(key, "DeviceMonitorAgent", 0, winreg.REG_SZ, exe_path)
            winreg.CloseKey(key)
            return True
        except:
            return False
    
    def run(self):
        """تشغيل المراقبة الرئيسية"""
        print("🚀 بدء مراقبة الجهاز...")
        
        # إضافة للتشغيل التلقائي
        self.add_to_startup()
        
        # إرسال معلومات النظام أول مرة
        system_data = {'type': 'system_info', **self.device_info}
        self.send_data(system_data)
        
        # حلقة المراقبة الرئيسية
        while True:
            try:
                # جمع البيانات الحية
                cpu = psutil.cpu_percent(interval=1)
                ram = psutil.virtual_memory().percent
                disk = psutil.disk_usage('C:').percent
                
                # فحص الإنترنت
                internet = self.check_internet()
                
                # إرسال البيانات
                metrics = {
                    'type': 'metrics',
                    'device_id': DEVICE_ID,
                    'cpu_usage': cpu,
                    'ram_usage': ram,
                    'disk_usage': disk,
                    'internet_status': internet,
                    'timestamp': datetime.now().isoformat()
                }
                
                if self.send_data(metrics):
                    print(f"✓ تم إرسال البيانات: CPU={cpu}%, RAM={ram}%")
                else:
                    print("✗ فشل إرسال البيانات")
                
                # الانتظار 60 ثانية
                time.sleep(60)
                
            except KeyboardInterrupt:
                print("\\nإيقاف المراقبة...")
                break
            except Exception as e:
                print(f"خطأ: {e}")
                time.sleep(60)
    
    def check_internet(self):
        """فحص اتصال الإنترنت"""
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except:
            return False

if __name__ == "__main__":
    monitor = DeviceMonitor()
    monitor.run()

PYTHON;

// حفظ الملف المؤقت
$temp_dir = '../temp/installers/';
if (!is_dir($temp_dir)) {
    mkdir($temp_dir, 0755, true);
}

$python_file = $temp_dir . $device_id . '.py';
file_put_contents($python_file, $agent_template);

// إنشاء ملف bat لتثبيت المتطلبات وتشغيل البرنامج
$bat_content = <<<BAT
@echo off
echo جاري تثبيت برنامج مراقبة الجهاز...
echo.

REM التحقق من تثبيت Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python غير مثبت!
    echo جاري تثبيت Python تلقائياً...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.9.0/python-3.9.0-amd64.exe' -OutFile 'python_installer.exe'"
    start /wait python_installer.exe /quiet InstallAllUsers=1 PrependPath=1
    del python_installer.exe
    echo ✓ تم تثبيت Python
) else (
    echo ✓ Python مثبت مسبقاً
)

REM تثبيت المكتبات المطلوبة
echo.
echo جاري تثبيت المكتبات المطلوبة...
pip install psutil requests >nul 2>&1
echo ✓ تم تثبيت المكتبات

REM إنشاء اختصار على سطح المكتب
echo.
echo جاري إنشاء اختصار على سطح المكتب...
set SCRIPT_PATH=%~dp0agent_monitor.py
echo Dim objShell, objShortcut > "%TEMP%\\create_shortcut.vbs"
echo Set objShell = CreateObject("WScript.Shell") >> "%TEMP%\\create_shortcut.vbs"
echo Set objShortcut = objShell.CreateShortcut(objShell.SpecialFolders("Desktop") ^& "\\مراقبة الجهاز.lnk") >> "%TEMP%\\create_shortcut.vbs"
echo objShortcut.TargetPath = "pythonw.exe" >> "%TEMP%\\create_shortcut.vbs"
echo objShortcut.Arguments = chr(34) ^& "%SCRIPT_PATH%" ^& chr(34) >> "%TEMP%\\create_shortcut.vbs"
echo objShortcut.WorkingDirectory = "%~dp0" >> "%TEMP%\\create_shortcut.vbs"
echo objShortcut.IconLocation = "%~dp0icon.ico, 0" >> "%TEMP%\\create_shortcut.vbs"
echo objShortcut.Save >> "%TEMP%\\create_shortcut.vbs"
cscript //nologo "%TEMP%\\create_shortcut.vbs"
del "%TEMP%\\create_shortcut.vbs"

REM تشغيل البرنامج في الخلفية
echo.
echo جاري تشغيل برنامج المراقبة...
start pythonw.exe agent_monitor.py

echo.
echo ✅ تم التثبيت بنجاح!
echo سيتم مراقبة الجهاز تلقائياً مع كل تشغيل للكمبيوتر
echo يمكنك إغلاق هذه النافذة
pause

BAT;

$bat_file = $temp_dir . 'install_' . $device_id . '.bat';
file_put_contents($bat_file, $bat_content);

// إضافة أيقونة
$icon_url = 'https://cdn-icons-png.flaticon.com/512/3014/3014279.png';
$icon_file = $temp_dir . 'icon.ico';
file_put_contents($icon_file, file_get_contents($icon_url));

// إنشاء ملف ZIP يحتوي على كل شيء
$zip_file = $temp_dir . $device_id . '.zip';
$zip = new ZipArchive();
if ($zip->open($zip_file, ZipArchive::CREATE) === TRUE) {
    $zip->addFile($python_file, 'agent_monitor.py');
    $zip->addFile($bat_file, 'install.bat');
    $zip->addFile($icon_file, 'icon.ico');
    
    // إضافة ملف تعليمات
    $readme = "# تعليمات التثبيت\n\n1. فك ضغط الملف\n2. شغل install.bat كمسؤول\n3. اتبع التعليمات";
    $zip->addFromString('README.txt', $readme);
    
    $zip->close();
}

// حفظ معلومات الجهاز في قاعدة البيانات
require_once '../config/db.php';
$stmt = $pdo->prepare("
    INSERT INTO devices (device_id, device_name, device_group, created_by)
    VALUES (:device_id, :device_name, :device_group, :user_id)
");
$stmt->execute([
    ':device_id' => $device_id,
    ':device_name' => $data['device_name'],
    ':device_group' => $data['device_group'],
    ':user_id' => $_SESSION['user_id']
]);

// رد بالرابط للتحميل
$download_url = str_replace('../', '', $zip_file);
echo json_encode([
    'success' => true,
    'device_id' => $device_id,
    'download_url' => $download_url,
    'message' => 'تم إنشاء ملف التثبيت بنجاح'
]);
?>