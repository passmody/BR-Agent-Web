<?php
session_start();
require_once '../includes/auth_check.php';

// التحقق من الصلاحيات
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    header('Location: unauthorized.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة جهاز جديد - نظام المراقبة</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/add-device.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="container">
            <!-- رأس الصفحة -->
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-plus-circle"></i>
                    إضافة جهاز جديد للمراقبة
                </h1>
                <div class="header-actions">
                    <a href="devices.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-right"></i> العودة للأجهزة
                    </a>
                </div>
            </div>

            <!-- خطوات العمل -->
            <div class="steps-container">
                <div class="steps">
                    <div class="step active" data-step="1">
                        <div class="step-number">1</div>
                        <div class="step-title">معلومات الجهاز</div>
                    </div>
                    <div class="step" data-step="2">
                        <div class="step-number">2</div>
                        <div class="step-title">إنشاء ملف التثبيت</div>
                    </div>
                    <div class="step" data-step="3">
                        <div class="step-number">3</div>
                        <div class="step-title">التثبيت على الجهاز</div>
                    </div>
                </div>
            </div>

            <!-- الخطوة 1: معلومات الجهاز -->
            <div class="step-content active" id="step1">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-info-circle"></i> المعلومات الأساسية للجهاز</h3>
                    </div>
                    <div class="card-body">
                        <form id="deviceInfoForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="device_name">
                                            <i class="fas fa-desktop"></i> اسم الجهاز *
                                        </label>
                                        <input type="text" 
                                               id="device_name" 
                                               name="device_name" 
                                               class="form-control"
                                               placeholder="مثال: جهاز مكتب المدير، سيرفر قاعدة البيانات"
                                               required>
                                        <small class="form-text text-muted">اسم معرّف للجهاز يظهر في لوحة التحكم</small>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="device_group">
                                            <i class="fas fa-sitemap"></i> المجموعة/الموقع *
                                        </label>
                                        <select id="device_group" name="device_group" class="form-control" required>
                                            <option value="">اختر المجموعة...</option>
                                            <option value="المكتب الرئيسي">المكتب الرئيسي</option>
                                            <option value="فرع الرياض">فرع الرياض</option>
                                            <option value="فرع جدة">فرع جدة</option>
                                            <option value="فرع الدمام">فرع الدمام</option>
                                            <option value="فرع الخبر">فرع الخبر</option>
                                            <option value="سيرفرات">سيرفرات</option>
                                            <option value="أجهزة الموظفين">أجهزة الموظفين</option>
                                            <option value="أجهزة العرض">أجهزة العرض</option>
                                            <option value="آخرى">آخرى</option>
                                        </select>
                                        <small class="form-text text-muted">لتجميع الأجهزة حسب الموقع أو النوع</small>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="device_type">
                                            <i class="fas fa-laptop"></i> نوع الجهاز
                                        </label>
                                        <select id="device_type" name="device_type" class="form-control">
                                            <option value="desktop">كمبيوتر مكتب</option>
                                            <option value="laptop">لابتوب</option>
                                            <option value="server">سيرفر</option>
                                            <option value="virtual">جهاز افتراضي</option>
                                            <option value="other">آخر</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="device_owner">
                                            <i class="fas fa-user"></i> مالك الجهاز
                                        </label>
                                        <input type="text" 
                                               id="device_owner" 
                                               name="device_owner" 
                                               class="form-control"
                                               placeholder="اسم المستخدم أو القسم">
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="device_description">
                                            <i class="fas fa-file-alt"></i> وصف الجهاز (اختياري)
                                        </label>
                                        <textarea id="device_description" 
                                                  name="device_description" 
                                                  class="form-control" 
                                                  rows="3"
                                                  placeholder="مثال: جهاز المدير العام، يحتوي على برامج المحاسبة..."></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="update_interval">
                                            <i class="fas fa-clock"></i> فاصل التحديث *
                                        </label>
                                        <select id="update_interval" name="update_interval" class="form-control" required>
                                            <option value="30">كل 30 ثانية</option>
                                            <option value="60" selected>كل دقيقة (مستحسن)</option>
                                            <option value="120">كل دقيقتين</option>
                                            <option value="300">كل 5 دقائق</option>
                                            <option value="600">كل 10 دقائق</option>
                                        </select>
                                        <small class="form-text text-muted">معدل إرسال البيانات من الـAgent للسيرفر</small>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <i class="fas fa-shield-alt"></i> خيارات الأمان
                                        </label>
                                        <div class="security-options">
                                            <div class="form-check">
                                                <input type="checkbox" 
                                                       class="form-check-input" 
                                                       id="enable_rustdesk" 
                                                       name="enable_rustdesk" 
                                                       checked>
                                                <label class="form-check-label" for="enable_rustdesk">
                                                    تفعيل التحكم عن بعد (RustDesk)
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input type="checkbox" 
                                                       class="form-check-input" 
                                                       id="auto_start" 
                                                       name="auto_start" 
                                                       checked>
                                                <label class="form-check-label" for="auto_start">
                                                    التشغيل التلقائي مع إقلاع النظام
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input type="checkbox" 
                                                       class="form-check-input" 
                                                       id="encrypt_data" 
                                                       name="encrypt_data">
                                                <label class="form-check-label" for="encrypt_data">
                                                    تشفير البيانات المرسلة (SSL)
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- معلومات السيرفر (تلقائية) -->
                            <div class="server-info mt-4">
                                <div class="alert alert-info">
                                    <h5><i class="fas fa-server"></i> معلومات السيرفر</h5>
                                    <p>سيستخدم الـAgent هذا العنوان لإرسال البيانات:</p>
                                    <div class="server-url-display">
                                        <code id="server_url_display">جاري التحميل...</code>
                                        <button type="button" class="btn btn-sm btn-outline-info" onclick="copyServerUrl()">
                                            <i class="fas fa-copy"></i> نسخ
                                        </button>
                                    </div>
                                    <small class="text-muted">تأكد من أن العنوان صحيح وقابل للوصول من الأجهزة المستهدفة</small>
                                </div>
                            </div>

                            <div class="form-actions mt-4">
                                <button type="button" class="btn btn-secondary" onclick="window.history.back()">
                                    <i class="fas fa-times"></i> إلغاء
                                </button>
                                <button type="button" class="btn btn-primary" onclick="goToStep(2)">
                                    التالي <i class="fas fa-arrow-left"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- الخطوة 2: إنشاء ملف التثبيت -->
            <div class="step-content" id="step2">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-file-download"></i> إنشاء ملف التثبيت</h3>
                    </div>
                    <div class="card-body">
                        <div class="creation-status text-center">
                            <div class="spinner-border text-primary mb-3" role="status" id="creationSpinner">
                                <span class="visually-hidden">جاري الإنشاء...</span>
                            </div>
                            <h4 id="creationStatus">جاهز للإنشاء</h4>
                            <p class="text-muted" id="creationMessage">املأ المعلومات ثم اضغط "إنشاء ملف التثبيت"</p>
                        </div>

                        <div class="installer-preview" id="installerPreview" style="display: none;">
                            <div class="text-center">
                                <div class="installer-icon mb-3">
                                    <i class="fas fa-file-archive fa-4x text-success"></i>
                                </div>
                                
                                <h4 class="installer-title" id="installerTitle"></h4>
                                <p class="text-muted" id="installerSize">حجم الملف: ~15 ميجابايت</p>
                                
                                <div class="device-details-preview mb-4">
                                    <div class="detail-item">
                                        <span>اسم الجهاز:</span>
                                        <strong id="previewDeviceName"></strong>
                                    </div>
                                    <div class="detail-item">
                                        <span>المجموعة:</span>
                                        <strong id="previewDeviceGroup"></strong>
                                    </div>
                                    <div class="detail-item">
                                        <span>معرف الجهاز:</span>
                                        <code id="previewDeviceId"></code>
                                    </div>
                                </div>

                                <!-- QR Code للتحميل -->
                                <div class="qr-section mb-4">
                                    <h5><i class="fas fa-qrcode"></i> مسح للتحميل السريع</h5>
                                    <div id="qrcode" class="mb-3"></div>
                                    <small class="text-muted">يمكنك مسح الكود لتحميل الملف مباشرة على الجهاز</small>
                                </div>

                                <!-- خيارات التحميل -->
                                <div class="download-options">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <button class="btn btn-success btn-lg btn-block" onclick="downloadInstaller()">
                                                <i class="fas fa-download"></i> تحميل مباشر
                                            </button>
                                        </div>
                                        <div class="col-md-4">
                                            <button class="btn btn-info btn-lg btn-block" onclick="sendViaEmail()">
                                                <i class="fas fa-envelope"></i> إرسال بالبريد
                                            </button>
                                        </div>
                                        <div class="col-md-4">
                                            <button class="btn btn-warning btn-lg btn-block" onclick="copyDownloadLink()">
                                                <i class="fas fa-link"></i> نسخ الرابط
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="row mt-3">
                                        <div class="col-md-12">
                                            <a href="#" class="btn btn-outline-secondary btn-block" id="advancedOptionsBtn">
                                                <i class="fas fa-cog"></i> خيارات متقدمة
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <!-- خيارات متقدمة -->
                                <div class="advanced-options mt-4" id="advancedOptions" style="display: none;">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5><i class="fas fa-code"></i> خيارات متقدمة</h5>
                                            <div class="form-group">
                                                <label for="custom_config">تكوين مخصص (JSON)</label>
                                                <textarea id="custom_config" class="form-control" rows="4" readonly></textarea>
                                                <small class="text-muted">يمكنك تعديل هذا التكوين يدوياً إذا كنت متقدماً</small>
                                            </div>
                                            <button class="btn btn-sm btn-outline-info mt-2" onclick="editCustomConfig()">
                                                <i class="fas fa-edit"></i> تعديل يدوي
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-actions mt-4">
                            <button type="button" class="btn btn-secondary" onclick="goToStep(1)">
                                <i class="fas fa-arrow-right"></i> السابق
                            </button>
                            <button type="button" class="btn btn-primary" id="createInstallerBtn" onclick="createInstaller()">
                                <i class="fas fa-magic"></i> إنشاء ملف التثبيت
                            </button>
                            <button type="button" class="btn btn-success" onclick="goToStep(3)" style="display: none;" id="nextStepBtn">
                                التالي <i class="fas fa-arrow-left"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الخطوة 3: تعليمات التثبيت -->
            <div class="step-content" id="step3">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-laptop-medical"></i> تثبيت الـAgent على الجهاز</h3>
                    </div>
                    <div class="card-body">
                        <div class="installation-guide">
                            <div class="guide-step">
                                <div class="step-number">1</div>
                                <div class="step-content">
                                    <h5>تحميل ملف التثبيت</h5>
                                    <p>قم بتحميل ملف <code>installer.exe</code> الذي تم إنشاؤه على الجهاز المراد مراقبته</p>
                                    <div class="note">
                                        <i class="fas fa-lightbulb"></i>
                                        <strong>ملاحظة:</strong> يمكنك استخدام QR Code لتحميل الملف مباشرة على الجهاز
                                    </div>
                                </div>
                            </div>
                            
                            <div class="guide-step">
                                <div class="step-number">2</div>
                                <div class="step-content">
                                    <h5>تشغيل الملف كمسؤول</h5>
                                    <p>انقر بزر الماوس الأيمن على الملف واختر <strong>"Run as administrator"</strong></p>
                                    <div class="screenshot-placeholder">
                                        <i class="fas fa-desktop"></i>
                                        <span>صورة توضيحية لشاشة التثبيت</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="guide-step">
                                <div class="step-number">3</div>
                                <div class="step-content">
                                    <h5>متابعة خطوات التثبيت</h5>
                                    <p>اتبع الخطوات التي تظهر في نافذة التثبيت:</p>
                                    <ul>
                                        <li>الموافقة على شروط الاستخدام</li>
                                        <li>تحديد مجلد التثبيت (يمكنك ترك الافتراضي)</li>
                                        <li>الانتظار حتى اكتمال التثبيت</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="guide-step">
                                <div class="step-number">4</div>
                                <div class="step-content">
                                    <h5>التحقق من التثبيت</h5>
                                    <p>بعد اكتمال التثبيت:</p>
                                    <ul>
                                        <li>سيكون هناك اختصار على سطح المكتب باسم "مراقبة الجهاز"</li>
                                        <li>سيبدأ البرنامج تلقائياً عند إقلاع النظام</li>
                                        <li>ستظهر رسالة تأكيد بنجاح التثبيت</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="guide-step">
                                <div class="step-number">5</div>
                                <div class="step-content">
                                    <h5>التحقق من الاتصال</h5>
                                    <p>ارجع للوحة التحكم وتأكد من:</p>
                                    <ul>
                                        <li>ظهور الجهاز في قائمة الأجهزة</li>
                                        <li>تغير حالة الجهاز إلى "🟢 متصل"</li>
                                        <li>بدء استقبال البيانات من الجهاز</li>
                                    </ul>
                                    <div class="alert alert-success">
                                        <i class="fas fa-check-circle"></i>
                                        <strong>مبروك!</strong> تمت إضافة الجهاز بنجاح. يمكنك الآن مراقبته والتحكم به عن بعد.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="troubleshooting mt-4">
                            <div class="card">
                                <div class="card-header">
                                    <h5><i class="fas fa-tools"></i> استكشاف الأخطاء وإصلاحها</h5>
                                </div>
                                <div class="card-body">
                                    <div class="accordion" id="troubleshootingAccordion">
                                        <div class="accordion-item">
                                            <h2 class="accordion-header">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#problem1">
                                                    الملف لا يعمل/غير قابل للتنفيذ
                                                </button>
                                            </h2>
                                            <div id="problem1" class="accordion-collapse collapse" data-bs-parent="#troubleshootingAccordion">
                                                <div class="accordion-body">
                                                    <ul>
                                                        <li>تحقق من أن النظام مضاد للفيروسات لا يحظر الملف</li>
                                                        <li>حاول تعطيل Windows Defender مؤقتاً</li>
                                                        <li>تحميل الملف مرة أخرى</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="accordion-item">
                                            <h2 class="accordion-header">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#problem2">
                                                    الجهاز لا يظهر في لوحة التحكم
                                                </button>
                                            </h2>
                                            <div id="problem2" class="accordion-collapse collapse" data-bs-parent="#troubleshootingAccordion">
                                                <div class="accordion-body">
                                                    <ul>
                                                        <li>تحقق من اتصال الإنترنت على الجهاز</li>
                                                        <li>تأكد من أن جدار الحماية يسمح باتصالات HTTP</li>
                                                        <li>انتظر دقيقتين ثم أعد تحميل الصفحة</li>
                                                        <li>تحقق من عنوان السيرفر في إعدادات الـAgent</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="accordion-item">
                                            <h2 class="accordion-header">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#problem3">
                                                    التحكم عن بعد لا يعمل
                                                </button>
                                            </h2>
                                            <div id="problem3" class="accordion-collapse collapse" data-bs-parent="#troubleshootingAccordion">
                                                <div class="accordion-body">
                                                    <ul>
                                                        <li>تأكد من تثبيت RustDesk على الجهاز المتحكم</li>
                                                        <li>تحقق من أن كلمة مرور RustDesk صحيحة</li>
                                                        <li>تأكد من أن الجهاز المستهدف متصل بالإنترنت</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="final-actions mt-4 text-center">
                            <a href="devices.php" class="btn btn-primary btn-lg">
                                <i class="fas fa-eye"></i> عرض جميع الأجهزة
                            </a>
                            <button class="btn btn-success btn-lg" onclick="addAnotherDevice()">
                                <i class="fas fa-plus"></i> إضافة جهاز آخر
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal لعرض معلومات الاتصال -->
    <div class="modal fade" id="connectionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-network-wired"></i> معلومات الاتصال</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="connection-details">
                        <div class="detail-item">
                            <span>معرف الجهاز:</span>
                            <code id="modalDeviceId"></code>
                        </div>
                        <div class="detail-item">
                            <span>عنوان السيرفر:</span>
                            <code id="modalServerUrl"></code>
                        </div>
                        <div class="detail-item">
                            <span>مفتاح التشفير:</span>
                            <code id="modalEncryptionKey"></code>
                        </div>
                        <div class="detail-item">
                            <span>RustDesk ID:</span>
                            <code id="modalRustdeskId"></code>
                        </div>
                        <div class="detail-item">
                            <span>RustDesk Password:</span>
                            <code id="modalRustdeskPassword"></code>
                        </div>
                    </div>
                    <div class="alert alert-warning mt-3">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>هام:</strong> احتفظ بهذه المعلومات في مكان آمن. ستحتاجها لإدارة الجهاز.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                    <button type="button" class="btn btn-primary" onclick="printConnectionDetails()">
                        <i class="fas fa-print"></i> طباعة
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/add-device.js"></script>
    
    <script>
        // تهيئة متغيرات
        let currentStep = 1;
        let deviceData = {};
        let installerData = null;
        
        // تهيئة عنوان السيرفر
        document.addEventListener('DOMContentLoaded', function() {
            const serverUrl = window.location.origin + '<?php echo dirname(dirname($_SERVER['REQUEST_URI'])); ?>';
            document.getElementById('server_url_display').textContent = serverUrl;
        });
        
        // التنقل بين الخطوات
        function goToStep(step) {
            // إخفاء جميع الخطوات
            document.querySelectorAll('.step-content').forEach(el => {
                el.classList.remove('active');
            });
            
            document.querySelectorAll('.step').forEach(el => {
                el.classList.remove('active');
            });
            
            // إظهار الخطوة المطلوبة
            document.getElementById(`step${step}`).classList.add('active');
            document.querySelector(`.step[data-step="${step}"]`).classList.add('active');
            
            currentStep = step;
            
            // إذا كانت الخطوة 2، قم بتحضير البيانات
            if (step === 2) {
                prepareStep2();
            }
        }
        
        // تحضير الخطوة 2
        function prepareStep2() {
            const form = document.getElementById('deviceInfoForm');
            const formData = new FormData(form);
            
            deviceData = {
                device_name: formData.get('device_name'),
                device_group: formData.get('device_group'),
                device_type: formData.get('device_type'),
                device_owner: formData.get('device_owner'),
                device_description: formData.get('device_description'),
                update_interval: formData.get('update_interval'),
                enable_rustdesk: formData.get('enable_rustdesk') === 'on',
                auto_start: formData.get('auto_start') === 'on',
                encrypt_data: formData.get('encrypt_data') === 'on',
                server_url: document.getElementById('server_url_display').textContent
            };
            
            // عرض المعاينة
            document.getElementById('previewDeviceName').textContent = deviceData.device_name;
            document.getElementById('previewDeviceGroup').textContent = deviceData.device_group;
            document.getElementById('previewDeviceId').textContent = 'DEV_' + Date.now().toString(36).toUpperCase();
            
            // إعداد التكوين المخصص
            const customConfig = {
                ...deviceData,
                created_at: new Date().toISOString(),
                created_by: '<?php echo $_SESSION["username"]; ?>'
            };
            document.getElementById('custom_config').value = JSON.stringify(customConfig, null, 2);
        }
        
        // إنشاء ملف التثبيت
        function createInstaller() {
            const btn = document.getElementById('createInstallerBtn');
            const spinner = document.getElementById('creationSpinner');
            const status = document.getElementById('creationStatus');
            const message = document.getElementById('creationMessage');
            const preview = document.getElementById('installerPreview');
            const nextBtn = document.getElementById('nextStepBtn');
            
            // عرض حالة الإنشاء
            btn.disabled = true;
            spinner.style.display = 'block';
            status.textContent = 'جاري إنشاء ملف التثبيت...';
            message.textContent = 'قد يستغرق هذا بضع ثواني';
            
            // محاكاة إنشاء الملف (في الواقع هنا راح يكون اتصال مع API)
            setTimeout(() => {
                // توليد معرف الجهاز
                const deviceId = 'DEV_' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substr(2, 5).toUpperCase();
                
                // توليد بيانات RustDesk
                const rustdeskId = 'RS' + Math.random().toString(36).substr(2, 9).toUpperCase();
                const rustdeskPassword = Math.random().toString(36).substr(2, 8);
                
                // بيانات الملف النهائية
                installerData = {
                    device_id: deviceId,
                    device_name: deviceData.device_name,
                    download_url: `/temp/installers/${deviceId}.zip`,
                    rustdesk_id: rustdeskId,
                    rustdesk_password: rustdeskPassword,
                    created_at: new Date().toISOString()
                };
                
                // تحديث العرض
                document.getElementById('previewDeviceId').textContent = deviceId;
                status.textContent = '✅ تم الإنشاء بنجاح!';
                message.textContent = 'ملف التثبيت جاهز للتحميل';
                spinner.style.display = 'none';
                preview.style.display = 'block';
                nextBtn.style.display = 'inline-block';
                
                // إنشاء QR Code
                generateQRCode(installerData.download_url);
                
                // حفظ بيانات الاتصال في الـModal
                document.getElementById('modalDeviceId').textContent = deviceId;
                document.getElementById('modalServerUrl').textContent = deviceData.server_url;
                document.getElementById('modalEncryptionKey').textContent = 'ENC_' + Math.random().toString(36).substr(2, 16).toUpperCase();
                document.getElementById('modalRustdeskId').textContent = rustdeskId;
                document.getElementById('modalRustdeskPassword').textContent = rustdeskPassword;
                
                // عرض Modal لمعلومات الاتصال
                const modal = new bootstrap.Modal(document.getElementById('connectionModal'));
                modal.show();
                
            }, 2000);
        }
        
        // إنشاء QR Code
        function generateQRCode(url) {
            const qrcodeDiv = document.getElementById('qrcode');
            qrcodeDiv.innerHTML = '';
            QRCode.toCanvas(qrcodeDiv, url, { width: 200 }, function(error) {
                if (error) console.error(error);
            });
        }
        
        // تحميل الملف
        function downloadInstaller() {
            if (!installerData) return;
            
            // محاكاة التحميل (في الواقع هنا راح يكون رابط حقيقي)
            const link = document.createElement('a');
            link.href = installerData.download_url;
            link.download = `device_installer_${installerData.device_id}.zip`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // عرض رسالة نجاح
            alert('✅ بدأ تحميل ملف التثبيت. راجع مجلد التحميلات.');
        }
        
        // نسخ رابط التحميل
        function copyDownloadLink() {
            if (!installerData) return;
            
            const tempInput = document.createElement('input');
            tempInput.value = window.location.origin + installerData.download_url;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            
            alert('✅ تم نسخ رابط التحميل إلى الحافظة');
        }
        
        // نسخ عنوان السيرفر
        function copyServerUrl() {
            const serverUrl = document.getElementById('server_url_display').textContent;
            navigator.clipboard.writeText(serverUrl).then(() => {
                alert('✅ تم نسخ عنوان السيرفر');
            });
        }
        
        // إرسال بالبريد
        function sendViaEmail() {
            const email = prompt('أدخل البريد الإلكتروني لإرسال رابط التحميل:');
            if (email && installerData) {
                alert(`📧 تم إرسال رابط التحميل إلى: ${email}\n(هذه محاكاة - في النسخة النهائية سيرسل بريداً حقيقياً)`);
            }
        }
        
        // إظهار/إخفاء الخيارات المتقدمة
        document.getElementById('advancedOptionsBtn').addEventListener('click', function(e) {
            e.preventDefault();
            const optionsDiv = document.getElementById('advancedOptions');
            optionsDiv.style.display = optionsDiv.style.display === 'none' ? 'block' : 'none';
            this.innerHTML = optionsDiv.style.display === 'none' ? 
                '<i class="fas fa-cog"></i> خيارات متقدمة' : 
                '<i class="fas fa-times"></i> إخفاء الخيارات';
        });
        
        // تعديل التكوين يدوياً
        function editCustomConfig() {
            const textarea = document.getElementById('custom_config');
            const isReadOnly = textarea.readOnly;
            textarea.readOnly = !isReadOnly;
            alert(isReadOnly ? '🔓 يمكنك الآن تعديل التكوين يدوياً' : '🔒 تم إقفال التعديل اليدوي');
        }
        
        // إضافة جهاز آخر
        function addAnotherDevice() {
            location.reload();
        }
        
        // طباعة معلومات الاتصال
        function printConnectionDetails() {
            window.print();
        }
        
        // إظهار تلميحات للمستخدم
        document.querySelectorAll('[title]').forEach(el => {
            new bootstrap.Tooltip(el);
        });
    </script>
</body>
</html>