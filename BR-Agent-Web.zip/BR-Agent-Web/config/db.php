<?php
// config/db.php - النسخة المحسنة

// منع الوصول المباشر
if (!defined('ROOT_PATH')) {
    die('Direct access not permitted');
}

// تحميل الإعدادات من ملف .env (أكثر أماناً)
$env = parse_ini_file('.env');

define('DB_HOST', $env['DB_HOST'] ?? 'localhost');
define('DB_NAME', $env['DB_NAME'] ?? 'device_monitoring');
define('DB_USER', $env['DB_USER'] ?? '');
define('DB_PASS', $env['DB_PASS'] ?? '');

// إعدادات PDO محسنة
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::ATTR_PERSISTENT => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
    PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => false,
];

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // تسجيل الخطأ دون عرض تفاصيل حساسة
    error_log("Database Connection Failed: " . $e->getMessage());
    
    // عرض رسالة ودية للمستخدم
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        die("فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
    } else {
        die("عذراً، حدث خطأ في النظام. الرجاء المحاولة لاحقاً.");
    }
}

// دالة مساعدة للاستعلامات الآمنة
function safe_query($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("Query Error: " . $e->getMessage() . " | SQL: " . $sql);
        throw $e;
    }
}
?>