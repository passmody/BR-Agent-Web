<?php
session_start();
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// جلب جميع الأجهزة مع التصفية
$filter_group = $_GET['group'] ?? '';
$filter_status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';

$query = "SELECT * FROM devices WHERE 1=1";
$params = [];

if (!empty($filter_group)) {
    $query .= " AND device_group = :group";
    $params[':group'] = $filter_group;
}

if (!empty($filter_status)) {
    if ($filter_status === 'online') {
        $query .= " AND is_active = 1 AND last_seen >= NOW() - INTERVAL 5 MINUTE";
    } elseif ($filter_status === 'offline') {
        $query .= " AND (is_active = 0 OR last_seen < NOW() - INTERVAL 5 MINUTE)";
    } elseif ($filter_status === 'warning') {
        $query .= " AND cpu_usage > 80 OR ram_usage > 85 OR disk_usage > 90";
    }
}

if (!empty($search)) {
    $query .= " AND (device_name LIKE :search OR device_id LIKE :search OR ip_address LIKE :search)";
    $params[':search'] = "%$search%";
}

$query .= " ORDER BY last_seen DESC, device_name ASC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$devices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب المجموعات المتاحة
$stmt = $pdo->query("SELECT DISTINCT device_group FROM devices ORDER BY device_group");
$groups = $stmt->fetchAll(PDO::FETCH_COLUMN);

// جلب الإحصائيات
$stats = [
    'total' => count($devices),
    'online' => 0,
    'offline' => 0,
    'warning' => 0
];

foreach ($devices as $device) {
    $last_seen = strtotime($device['last_seen']);
    $five_min_ago = time() - 300;
    
    if ($device['is_active'] && $last_seen >= $five_min_ago) {
        $stats['online']++;
        if ($device['cpu_usage'] > 80 || $device['ram_usage'] > 85 || $device['disk_usage'] > 90) {
            $stats['warning']++;
        }
    } else {
        $stats['offline']++;
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الأجهزة - نظام المراقبة</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/devices.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="container">
            <!-- رأس الصفحة -->
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-desktop"></i>
                    إدارة الأجهزة
                </h1>
                <div class="header-actions">
                    <a href="add-device.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> إضافة جهاز جديد
                    </a>
                </div>
            </div>

            <!-- بطاقات الإحصائيات -->
            <div class="stats-cards">
                <div class="stat-card total">
                    <div class="stat-icon">
                        <i class="fas fa-desktop"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total']; ?></h3>
                        <p>إجمالي الأجهزة</p>
                    </div>
                </div>
                
                <div class="stat-card online">
                    <div class="stat-icon">
                        <i class="fas fa-circle-check"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['online']; ?></h3>
                        <p>متصل الآن</p>
                    </div>
                </div>
                
                <div class="stat-card offline">
                    <div class="stat-icon">
                        <i class="fas fa-circle-xmark"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['offline']; ?></h3>
                        <p>غير متصل</p>
                    </div>
                </div>
                
                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-triangle-exclamation"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $stats['warning']; ?></h3>
                        <p>تحتاج انتباه</p>
                    </div>
                </div>
            </div>

            <!-- فلترة البحث -->
            <div class="filter-card">
                <form method="GET" class="filter-form">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>البحث</label>
                                <input type="text" name="search" placeholder="ابحث عن جهاز..." 
                                       value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>المجموعة</label>
                                <select name="group">
                                    <option value="">جميع المجموعات</option>
                                    <?php foreach ($groups as $group): ?>
                                    <option value="<?php echo $group; ?>" 
                                            <?php echo $filter_group === $group ? 'selected' : ''; ?>>
                                        <?php echo $group; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>الحالة</label>
                                <select name="status">
                                    <option value="">جميع الحالات</option>
                                    <option value="online" <?php echo $filter_status === 'online' ? 'selected' : ''; ?>>🟢 متصل</option>
                                    <option value="offline" <?php echo $filter_status === 'offline' ? 'selected' : ''; ?>>🔴 غير متصل</option>
                                    <option value="warning" <?php echo $filter_status === 'warning' ? 'selected' : ''; ?>>⚠️ يحتاج انتباه</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fas fa-filter"></i> تطبيق الفلتر
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- جدول الأجهزة -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="devices-table">
                            <thead>
                                <tr>
                                    <th>اسم الجهاز</th>
                                    <th>الحالة</th>
                                    <th>المجموعة</th>
                                    <th>المعالج</th>
                                    <th>الذاكرة</th>
                                    <th>القرص</th>
                                    <th>آخر اتصال</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($devices)): ?>
                                <tr>
                                    <td colspan="8" class="text-center">
                                        <div class="empty-state">
                                            <i class="fas fa-desktop fa-3x"></i>
                                            <h3>لا توجد أجهزة</h3>
                                            <p>لم يتم إضافة أي أجهزة بعد</p>
                                            <a href="add-device.php" class="btn btn-primary">إضافة جهاز جديد</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($devices as $device): 
                                        $status_class = 'offline';
                                        $status_text = 'غير متصل';
                                        $last_seen_time = strtotime($device['last_seen']);
                                        $five_min_ago = time() - 300;
                                        
                                        if ($device['is_active'] && $last_seen_time >= $five_min_ago) {
                                            $status_class = 'online';
                                            $status_text = 'متصل';
                                        }
                                        
                                        // تحذير إذا كانت النسب عالية
                                        $warning = '';
                                        if ($device['cpu_usage'] > 80) $warning = 'cpu-warning';
                                        if ($device['ram_usage'] > 85) $warning = 'ram-warning';
                                        if ($device['disk_usage'] > 90) $warning = 'disk-warning';
                                        if ($warning) $status_class = 'warning';
                                    ?>
                                    <tr class="<?php echo $warning; ?>">
                                        <td>
                                            <div class="device-info">
                                                <div class="device-icon">
                                                    <i class="fas fa-desktop"></i>
                                                </div>
                                                <div>
                                                    <strong><?php echo htmlspecialchars($device['device_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo $device['device_id']; ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <span class="status-badge <?php echo $status_class; ?>">
                                                <?php if ($status_class === 'online'): ?>
                                                🟢 <?php echo $status_text; ?>
                                                <?php elseif ($status_class === 'warning'): ?>
                                                ⚠️ يحتاج انتباه
                                                <?php else: ?>
                                                🔴 <?php echo $status_text; ?>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        
                                        <td>
                                            <span class="group-badge">
                                                <?php echo htmlspecialchars($device['device_group']); ?>
                                            </span>
                                        </td>
                                        
                                        <td>
                                            <div class="progress-cell">
                                                <div class="progress-label">
                                                    <?php echo $device['cpu_usage']; ?>%
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar <?php echo $device['cpu_usage'] > 80 ? 'bg-danger' : 'bg-success'; ?>" 
                                                         style="width: <?php echo $device['cpu_usage']; ?>%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <div class="progress-cell">
                                                <div class="progress-label">
                                                    <?php echo $device['ram_usage']; ?>%
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar <?php echo $device['ram_usage'] > 85 ? 'bg-warning' : 'bg-info'; ?>" 
                                                         style="width: <?php echo $device['ram_usage']; ?>%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <div class="progress-cell">
                                                <div class="progress-label">
                                                    <?php echo $device['disk_usage']; ?>%
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar <?php echo $device['disk_usage'] > 90 ? 'bg-danger' : 'bg-primary'; ?>" 
                                                         style="width: <?php echo $device['disk_usage']; ?>%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <?php echo time_ago($device['last_seen']); ?>
                                            <br>
                                            <small class="text-muted">
                                                <?php echo date('H:i', strtotime($device['last_seen'])); ?>
                                            </small>
                                        </td>
                                        
                                        <td>
                                            <div class="action-buttons">
                                                <a href="device-details.php?id=<?php echo $device['device_id']; ?>" 
                                                   class="btn btn-sm btn-info" title="تفاصيل">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                
                                                <button onclick="remoteControl('<?php echo $device['device_id']; ?>')" 
                                                        class="btn btn-sm btn-success" title="تحكم عن بعد">
                                                    <i class="fas fa-desktop"></i>
                                                </button>
                                                
                                                <div class="dropdown">
                                                    <button class="btn btn-sm btn-secondary dropdown-toggle" 
                                                            type="button" data-bs-toggle="dropdown">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#" onclick="sendCommand('<?php echo $device['device_id']; ?>', 'restart')">
                                                            <i class="fas fa-redo"></i> إعادة تشغيل
                                                        </a>
                                                        <a class="dropdown-item" href="#" onclick="sendCommand('<?php echo $device['device_id']; ?>', 'update')">
                                                            <i class="fas fa-sync"></i> تحديث
                                                        </a>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item text-danger" href="#" 
                                                           onclick="removeDevice('<?php echo $device['device_id']; ?>')">
                                                            <i class="fas fa-trash"></i> إزالة
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/devices.js"></script>
    <script>
        // التحكم عن بعد
        function remoteControl(deviceId) {
            fetch(`../api/send_command.php?device_id=${deviceId}&command=remote_control`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.rustdesk) {
                        if (confirm('فتح RustDesk للتحكم عن بعد؟')) {
                            window.open(data.rustdesk.direct_link, '_blank');
                        }
                    } else {
                        alert('فشل الاتصال بالجهاز');
                    }
                });
        }
        
        // إرسال أمر
        function sendCommand(deviceId, command) {
            if (!confirm('هل أنت متأكد من إرسال هذا الأمر؟')) return;
            
            fetch(`../api/send_command.php?device_id=${deviceId}&command=${command}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert(data.error || 'حدث خطأ');
                    }
                });
        }
        
        // تحديث تلقائي كل 30 ثانية
        setInterval(() => {
            // تحديث الإحصائيات فقط إذا كانت الصفحة مرئية
            if (!document.hidden) {
                location.reload();
            }
        }, 30000);
    </script>
</body>
</html>