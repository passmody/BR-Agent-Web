<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// التحقق من أن الطلب POST
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'الطريقة غير مسموحة']);
    exit();
}

// قراءة البيانات المرسلة
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data || !isset($data['device_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit();
}

require_once '../config/db.php';

try {
    $type = $data['type'] ?? 'metrics';
    
    if ($type === 'system_info') {
        // حفظ معلومات النظام الثابتة
        $stmt = $pdo->prepare("
            INSERT INTO devices (
                device_id, device_name, device_group, 
                os_name, os_version, cpu_name, cpu_cores, 
                total_ram_gb, total_disk_gb, mac_address,
                last_seen, is_active
            ) VALUES (
                :device_id, :device_name, :device_group,
                :os_name, :os_version, :cpu_name, :cpu_cores,
                :total_ram_gb, :total_disk_gb, :mac_address,
                NOW(), 1
            ) ON DUPLICATE KEY UPDATE
                device_name = VALUES(device_name),
                device_group = VALUES(device_group),
                os_name = VALUES(os_name),
                os_version = VALUES(os_version),
                cpu_name = VALUES(cpu_name),
                cpu_cores = VALUES(cpu_cores),
                total_ram_gb = VALUES(total_ram_gb),
                total_disk_gb = VALUES(total_disk_gb),
                last_seen = NOW(),
                is_active = 1
        ");
        
        $stmt->execute([
            ':device_id' => $data['device_id'],
            ':device_name' => $data['device_name'] ?? 'جهاز غير معروف',
            ':device_group' => $data['device_group'] ?? 'Default',
            ':os_name' => $data['os_name'] ?? 'Unknown',
            ':os_version' => $data['os_version'] ?? 'Unknown',
            ':cpu_name' => $data['cpu_name'] ?? 'Unknown',
            ':cpu_cores' => $data['cpu_cores'] ?? 1,
            ':total_ram_gb' => $data['total_ram_gb'] ?? 0,
            ':total_disk_gb' => $data['total_disk_gb'] ?? 0,
            ':mac_address' => $data['mac_address'] ?? '00:00:00:00:00:00'
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم حفظ معلومات النظام']);
        
    } elseif ($type === 'metrics') {
        // حفظ المقاييس الحية
        $stmt = $pdo->prepare("
            UPDATE devices SET
                cpu_usage = :cpu_usage,
                ram_usage = :ram_usage,
                disk_usage = :disk_usage,
                internet_status = :internet_status,
                network_up = :network_up_kb,
                network_down = :network_down_kb,
                last_seen = NOW(),
                is_active = 1
            WHERE device_id = :device_id
        ");
        
        $stmt->execute([
            ':device_id' => $data['device_id'],
            ':cpu_usage' => $data['cpu_usage'] ?? 0,
            ':ram_usage' => $data['ram_usage'] ?? 0,
            ':disk_usage' => $data['disk_usage'] ?? 0,
            ':internet_status' => $data['internet_status'] ? 1 : 0,
            ':network_up_kb' => $data['network_up_kb'] ?? 0,
            ':network_down_kb' => $data['network_down_kb'] ?? 0
        ]);
        
        // حفظ في السجل التاريخي
        $stmt2 = $pdo->prepare("
            INSERT INTO device_metrics 
            (device_id, cpu_usage, ram_usage, disk_usage, 
             network_up, network_down, timestamp)
            VALUES 
            (:device_id, :cpu_usage, :ram_usage, :disk_usage,
             :network_up, :network_down, NOW())
        ");
        
        $stmt2->execute([
            ':device_id' => $data['device_id'],
            ':cpu_usage' => $data['cpu_usage'] ?? 0,
            ':ram_usage' => $data['ram_usage'] ?? 0,
            ':disk_usage' => $data['disk_usage'] ?? 0,
            ':network_up' => $data['network_up_kb'] ?? 0,
            ':network_down' => $data['network_down_kb'] ?? 0
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم حفظ المقاييس']);
    } else {
        echo json_encode(['success' => true, 'message' => 'تم الاستلام']);
    }
    
} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'خطأ في قاعدة البيانات']);
}
?>