<?php
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $client = FirebaseConnection::getClient();
    
    if (!$client) {
        throw new Exception('فشل الاتصال بـ Firebase');
    }
    
    $alertsRef = $client->collection('alerts');
    
    // الفلترات
    $filters = [];
    
    if (isset($_GET['resolved']) && $_GET['resolved'] === 'false') {
        $filters[] = ['field' => 'resolved', 'operator' => '=', 'value' => false];
    }
    
    if (isset($_GET['severity'])) {
        $filters[] = ['field' => 'severity', 'operator' => '=', 'value' => $_GET['severity']];
    }
    
    if (isset($_GET['branch_id'])) {
        $filters[] = ['field' => 'branch_id', 'operator' => '=', 'value' => $_GET['branch_id']];
    }
    
    // بناء الاستعلام
    $query = $alertsRef;
    foreach ($filters as $filter) {
        $query = $query->where($filter['field'], $filter['operator'], $filter['value']);
    }
    
    // الترتيب والتحديد
    $query = $query->orderBy('timestamp', 'DESC');
    
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
    $query = $query->limit($limit);
    
    $alertsSnapshot = $query->documents();
    
    $alerts = [];
    foreach ($alertsSnapshot as $document) {
        if ($document->exists()) {
            $data = $document->data();
            $data['id'] = $document->id();
            $data['time_ago'] = get_time_ago($data['timestamp'] ?? null);
            $alerts[] = $data;
        }
    }
    
    json_response([
        'success' => true,
        'alerts' => $alerts,
        'count' => count($alerts),
        'filters' => $filters,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    json_response([
        'success' => false,
        'message' => $e->getMessage(),
        'alerts' => [],
        'count' => 0
    ], 500);
}
?>