/**
 * ملف مصادقة المستخدم
 * معالجة تسجيل الدخول، التسجيل، واستعادة كلمة المرور
 */

document.addEventListener('DOMContentLoaded', function() {
    // تبديل عرض كلمة المرور
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    
    togglePasswordButtons.forEach(button => {
        button.addEventListener('click', function() {
            const passwordInput = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // التحقق من صحة نموذج تسجيل الدخول
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const email = this.querySelector('#email');
            const password = this.querySelector('#password');
            let isValid = true;
            
            // التحقق من البريد الإلكتروني
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value)) {
                showError(email, 'البريد الإلكتروني غير صالح');
                isValid = false;
            } else {
                clearError(email);
            }
            
            // التحقق من كلمة المرور
            if (password.value.length < 6) {
                showError(password, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل');
                isValid = false;
            } else {
                clearError(password);
            }
            
            if (!isValid) {
                e.preventDefault();
                return false;
            }
            
            // إظهار تحميل
            const submitBtn = this.querySelector('.btn-login');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري تسجيل الدخول...';
            submitBtn.disabled = true;
            
            // محاكاة تأخير للشبكة
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 2000);
        });
    }
    
    // معالجة استعادة كلمة المرور
    const forgotForm = document.querySelector('.forgot-form');
    if (forgotForm) {
        forgotForm.addEventListener('submit', function(e) {
            const email = this.querySelector('#email');
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (!emailRegex.test(email.value)) {
                showError(email, 'البريد الإلكتروني غير صالح');
                e.preventDefault();
                return false;
            }
            
            // إظهار رسالة نجاح
            showMessage('success', 'تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني');
            e.preventDefault();
        });
    }
    
    // معالجة نموذج التسجيل
    const registerForm = document.querySelector('.register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const password = this.querySelector('#password');
            const confirmPassword = this.querySelector('#confirm_password');
            const terms = this.querySelector('#terms');
            
            let isValid = true;
            
            // التحقق من تطابق كلمتي المرور
            if (password.value !== confirmPassword.value) {
                showError(confirmPassword, 'كلمة المرور غير متطابقة');
                isValid = false;
            } else {
                clearError(confirmPassword);
            }
            
            // التحقق من شروط الخدمة
            if (!terms.checked) {
                showError(terms, 'يجب الموافقة على شروط الخدمة');
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // وظائف المساعدة
    function showError(input, message) {
        const formGroup = input.closest('.form-group');
        let errorElement = formGroup.querySelector('.error-message');
        
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            formGroup.appendChild(errorElement);
        }
        
        errorElement.textContent = message;
        input.classList.add('error');
    }
    
    function clearError(input) {
        const formGroup = input.closest('.form-group');
        const errorElement = formGroup.querySelector('.error-message');
        
        if (errorElement) {
            errorElement.remove();
        }
        
        input.classList.remove('error');
    }
    
    function showMessage(type, message) {
        // إزالة أي رسائل سابقة
        const existingMessages = document.querySelectorAll('.custom-message');
        existingMessages.forEach(msg => msg.remove());
        
        // إنشاء رسالة جديدة
        const messageElement = document.createElement('div');
        messageElement.className = `custom-message alert-${type}`;
        messageElement.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        
        // إضافة الرسالة للنموذج
        const form = document.querySelector('form');
        form.prepend(messageElement);
        
        // إخفاء الرسالة بعد 5 ثوانٍ
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }
    
    // تسجيل الدخول باستخدام Google (محاكاة)
    const googleBtn = document.querySelector('.btn-google');
    if (googleBtn) {
        googleBtn.addEventListener('click', function() {
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التوجيه...';
            this.disabled = true;
            
            setTimeout(() => {
                showMessage('info', 'هذه الميزة غير متاحة حالياً في النسخة التجريبية');
                this.innerHTML = originalText;
                this.disabled = false;
            }, 1500);
        });
    }
    
    // التحقق من حالة الجلسة
    checkSession();
});

// التحقق من حالة الجلسة
function checkSession() {
    const lastActivity = localStorage.getItem('lastActivity');
    const now = new Date().getTime();
    
    if (lastActivity) {
        const inactiveTime = now - parseInt(lastActivity);
        const sessionTimeout = 30 * 60 * 1000; // 30 دقيقة
        
        if (inactiveTime > sessionTimeout) {
            // جلسة منتهية الصلاحية
            showSessionExpired();
        }
    }
    
    // تحديث وقت النشاط
    updateLastActivity();
    
    // تحديث وقت النشاط كل دقيقة
    setInterval(updateLastActivity, 60000);
}

function updateLastActivity() {
    localStorage.setItem('lastActivity', new Date().getTime());
}

function showSessionExpired() {
    if (window.location.pathname.includes('login.php')) return;
    
    const modal = document.createElement('div');
    modal.className = 'session-expired-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <i class="fas fa-clock"></i>
            <h3>انتهت مدة الجلسة</h3>
            <p>لقد انتهت مدة جلستك بسبب عدم النشاط. يرجى تسجيل الدخول مرة أخرى.</p>
            <button onclick="redirectToLogin()" class="btn btn-primary">تسجيل الدخول</button>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // إضافة الأنماط
    const style = document.createElement('style');
    style.textContent = `
        .session-expired-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        
        .session-expired-modal .modal-content {
            background: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            max-width: 400px;
            width: 90%;
        }
        
        .session-expired-modal i {
            font-size: 4rem;
            color: #f39c12;
            margin-bottom: 20px;
        }
        
        .session-expired-modal h3 {
            color: #333;
            margin-bottom: 15px;
        }
        
        .session-expired-modal p {
            color: #666;
            margin-bottom: 25px;
            line-height: 1.6;
        }
    `;
    
    document.head.appendChild(style);
}

function redirectToLogin() {
    window.location.href = 'login.php?session=expired';
}