<?php
// config.php - إعدادات النظام

// إعدادات قاعدة البيانات (Firebase)
define('FIREBASE_CREDENTIALS_PATH', __DIR__ . '/serviceAccount.json');
define('FIREBASE_PROJECT_ID', 'YOUR_PROJECT_ID');
define('FIREBASE_DATABASE_URL', 'https://' . FIREBASE_PROJECT_ID . '.firebaseio.com');

// إعدادات التطبيق
define('APP_NAME', 'BR-Agent Dashboard');
define('APP_VERSION', '3.0.0');
define('TIMEZONE', 'Asia/Riyadh');

// إعدادات الجلسة
session_start();
date_default_timezone_set(TIMEZONE);

// إعدادات الأمان
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');

// مكتبات مطلوبة
require_once __DIR__ . '/vendor/autoload.php'; // Composer autoload

// فئة الاتصال بـ Firebase
class FirebaseConnection {
    private static $client = null;
    
    public static function getClient() {
        if (self::$client === null) {
            try {
                // استخدام Google Cloud Firestore
                putenv('GOOGLE_APPLICATION_CREDENTIALS=' . FIREBASE_CREDENTIALS_PATH);
                
                self::$client = new Google\Cloud\Firestore\FirestoreClient([
                    'projectId' => FIREBASE_PROJECT_ID,
                ]);
                
                error_log("✅ تم الاتصال بـ Firebase بنجاح");
            } catch (Exception $e) {
                error_log("❌ فشل الاتصال بـ Firebase: " . $e->getMessage());
                return null;
            }
        }
        return self::$client;
    }
    
    public static function testConnection() {
        try {
            $client = self::getClient();
            if ($client) {
                $docRef = $client->collection('test')->document('connection');
                $docRef->set(['test' => time()]);
                return true;
            }
            return false;
        } catch (Exception $e) {
            error_log("❌ فشل اختبار الاتصال: " . $e->getMessage());
            return false;
        }
    }
}

// دالات المساعدة
function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function format_date($timestamp, $format = 'Y-m-d H:i:s') {
    if (!$timestamp) return '-';
    $date = new DateTime($timestamp);
    return $date->format($format);
}

function get_time_ago($timestamp) {
    if (!$timestamp) return 'غير معروف';
    
    $time = strtotime($timestamp);
    $time_diff = time() - $time;
    
    if ($time_diff < 60) {
        return 'الآن';
    } elseif ($time_diff < 3600) {
        $minutes = floor($time_diff / 60);
        return "قبل $minutes دقيقة";
    } elseif ($time_diff < 86400) {
        $hours = floor($time_diff / 3600);
        return "قبل $hours ساعة";
    } elseif ($time_diff < 2592000) {
        $days = floor($time_diff / 86400);
        return "قبل $days يوم";
    } else {
        return date('Y-m-d', $time);
    }
}

// التحقق من الاتصال
if (isset($_GET['test_connection'])) {
    if (FirebaseConnection::testConnection()) {
        echo "✅ الاتصال بـ Firebase ناجح";
    } else {
        echo "❌ فشل الاتصال بـ Firebase";
    }
    exit;
}
?>