<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>غير مصرح بالوصول - النظام الإداري</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/error.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="error-container">
        <div class="error-content">
            <div class="error-icon">
                <i class="fas fa-ban"></i>
            </div>
            <h1>403</h1>
            <h2>غير مصرح بالوصول</h2>
            <p>عذراً، ليس لديك الصلاحيات اللازمة للوصول إلى هذه الصفحة.</p>
            
            <div class="error-actions">
                <a href="dashboard.php" class="btn btn-primary">
                    <i class="fas fa-home"></i> العودة للوحة التحكم
                </a>
                <a href="javascript:history.back()" class="btn btn-secondary">
                    <i class="fas fa-arrow-right"></i> العودة للصفحة السابقة
                </a>
            </div>
            
            <div class="error-help">
                <p>إذا كنت تعتقد أن هذا خطأ، يرجى التواصل مع <a href="mailto:admin@system.com">مدير النظام</a></p>
                <p>أو يمكنك <a href="logout.php">تسجيل الدخول</a> بحساب آخر</p>
            </div>
        </div>
    </div>
</body>
</html>