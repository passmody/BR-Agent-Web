<?php
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $client = FirebaseConnection::getClient();
    
    if (!$client) {
        throw new Exception('فشل الاتصال بـ Firebase');
    }
    
    $period = isset($_GET['period']) ? $_GET['period'] : '24h'; // 24h, 7d, 30d
    $device_id = isset($_GET['device_id']) ? $_GET['device_id'] : null;
    $branch_id = isset($_GET['branch_id']) ? $_GET['branch_id'] : null;
    
    // حساب وقت البدء
    $start_time = calculate_start_time($period);
    
    if ($device_id) {
        // بيانات جهاز محدد
        $metrics = get_device_metrics($client, $device_id, $start_time);
    } elseif ($branch_id) {
        // بيانات فرع محدد
        $metrics = get_branch_metrics($client, $branch_id, $start_time);
    } else {
        // بيانات عامة
        $metrics = get_system_metrics($client, $start_time);
    }
    
    json_response([
        'success' => true,
        'metrics' => $metrics,
        'period' => $period,
        'start_time' => date('Y-m-d H:i:s', $start_time),
        'end_time' => date('Y-m-d H:i:s'),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    json_response([
        'success' => false,
        'message' => $e->getMessage(),
        'metrics' => [],
        'period' => $period ?? '24h'
    ], 500);
}

function calculate_start_time($period) {
    $now = time();
    
    switch ($period) {
        case '1h':
            return $now - 3600;
        case '6h':
            return $now - (6 * 3600);
        case '24h':
            return $now - (24 * 3600);
        case '7d':
            return $now - (7 * 24 * 3600);
        case '30d':
            return $now - (30 * 24 * 3600);
        default:
            return $now - (24 * 3600);
    }
}

function get_device_metrics($client, $device_id, $start_time) {
    $metricsRef = $client->collection('devices')
        ->document($device_id)
        ->collection('history');
    
    $query = $metricsRef->where('timestamp', '>=', date('Y-m-d H:i:s', $start_time))
        ->orderBy('timestamp');
    
    $snapshot = $query->documents();
    
    $metrics = [];
    foreach ($snapshot as $doc) {
        if ($doc->exists()) {
            $metrics[] = $doc->data();
        }
    }
    
    return process_metrics_data($metrics);
}

function get_branch_metrics($client, $branch_id, $start_time) {
    // هذا مثال مبسط - في الواقع تحتاج لجمع بيانات جميع أجهزة الفرع
    return [
        'avg_cpu' => rand(30, 80),
        'avg_memory' => rand(40, 85),
        'avg_disk' => rand(50, 90),
        'device_count' => rand(5, 20),
        'alerts_count' => rand(0, 10)
    ];
}

function get_system_metrics($client, $start_time) {
    // بيانات وهمية للعرض
    $metrics = [];
    $interval = 3600; // ساعة
    
    for ($i = 23; $i >= 0; $i--) {
        $timestamp = $start_time + ($i * $interval);
        $metrics[] = [
            'timestamp' => date('Y-m-d H:i:s', $timestamp),
            'cpu' => rand(30, 80),
            'memory' => rand(40, 85),
            'disk' => rand(50, 90),
            'network' => rand(1, 100),
            'devices_online' => rand(15, 25)
        ];
    }
    
    return $metrics;
}

function process_metrics_data($metrics) {
    if (empty($metrics)) {
        return ['hourly' => [], 'daily' => []];
    }
    
    $hourly = [];
    $daily = [];
    
    foreach ($metrics as $metric) {
        $hour = date('H:00', strtotime($metric['timestamp']));
        $day = date('Y-m-d', strtotime($metric['timestamp']));
        
        if (!isset($hourly[$hour])) {
            $hourly[$hour] = [
                'time' => $hour,
                'cpu' => [],
                'memory' => [],
                'disk' => []
            ];
        }
        
        if (isset($metric['cpu_percent'])) {
            $hourly[$hour]['cpu'][] = $metric['cpu_percent'];
        }
        
        if (isset($metric['mem_percent'])) {
            $hourly[$hour]['memory'][] = $metric['mem_percent'];
        }
        
        if (isset($metric['disk_percent'])) {
            $hourly[$hour]['disk'][] = $metric['disk_percent'];
        }
        
        // نفس الشيء للبيانات اليومية
    }
    
    // حساب المتوسطات
    foreach ($hourly as &$hour) {
        $hour['cpu_avg'] = !empty($hour['cpu']) ? round(array_sum($hour['cpu']) / count($hour['cpu']), 1) : 0;
        $hour['memory_avg'] = !empty($hour['memory']) ? round(array_sum($hour['memory']) / count($hour['memory']), 1) : 0;
        $hour['disk_avg'] = !empty($hour['disk']) ? round(array_sum($hour['disk']) / count($hour['disk']), 1) : 0;
    }
    
    return [
        'hourly' => array_values($hourly),
        'daily' => array_values($daily)
    ];
}
?>