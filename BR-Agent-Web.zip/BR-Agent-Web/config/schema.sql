-- قاعدة البيانات: admin_system
CREATE DATABASE IF NOT EXISTS admin_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE admin_system;

-- جدول المستخدمين
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(255),
    bio TEXT,
    role ENUM('admin', 'editor', 'viewer') DEFAULT 'viewer',
    is_active BOOLEAN DEFAULT TRUE,
    two_factor_auth BOOLEAN DEFAULT FALSE,
    language VARCHAR(10) DEFAULT 'ar',
    theme VARCHAR(20) DEFAULT 'light',
    timezone VARCHAR(50) DEFAULT 'Asia/Riyadh',
    email_notifications BOOLEAN DEFAULT TRUE,
    push_notifications BOOLEAN DEFAULT TRUE,
    sms_notifications BOOLEAN DEFAULT FALSE,
    weekly_reports BOOLEAN DEFAULT TRUE,
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);


-- في config/schema.sql

CREATE DATABASE IF NOT EXISTS device_monitoring;
USE device_monitoring;

-- جدول المستخدمين (من النظام الإداري)
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role ENUM('admin', 'manager', 'viewer') DEFAULT 'viewer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول الأجهزة (الأساسي)
CREATE TABLE IF NOT EXISTS devices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(100) UNIQUE NOT NULL,
    device_name VARCHAR(100) NOT NULL,
    device_group VARCHAR(50) DEFAULT 'Default',
    
    -- معلومات النظام الثابتة
    os_name VARCHAR(50),
    os_version VARCHAR(50),
    cpu_name VARCHAR(100),
    cpu_cores INT,
    total_ram_gb DECIMAL(5,2),
    total_disk_gb DECIMAL(10,2),
    mac_address VARCHAR(17),
    ip_address VARCHAR(45),
    
    -- حالة الجهاز الحية
    cpu_usage DECIMAL(5,2) DEFAULT 0,
    ram_usage DECIMAL(5,2) DEFAULT 0,
    disk_usage DECIMAL(5,2) DEFAULT 0,
    internet_status BOOLEAN DEFAULT 0,
    network_up DECIMAL(10,2) DEFAULT 0, -- كيلوبايت
    network_down DECIMAL(10,2) DEFAULT 0, -- كيلوبايت
    
    -- إعدادات RustDesk
    rustdesk_id VARCHAR(50),
    rustdesk_password VARCHAR(255),
    
    -- إعدادات الـAgent
    agent_version VARCHAR(20) DEFAULT '1.0.0',
    update_interval INT DEFAULT 60,
    is_active BOOLEAN DEFAULT 1,
    
    -- معلومات التتبع
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_seen TIMESTAMP NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- جدول المقاييس التاريخية
CREATE TABLE IF NOT EXISTS device_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(100),
    cpu_usage DECIMAL(5,2),
    ram_usage DECIMAL(5,2),
    disk_usage DECIMAL(5,2),
    network_up DECIMAL(10,2),
    network_down DECIMAL(10,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_device_timestamp (device_id, timestamp),
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE
);

-- جدول النشاطات
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(100),
    action VARCHAR(100),
    details TEXT,
    user_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- جدول الأوامر
CREATE TABLE IF NOT EXISTS device_commands (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(100),
    command VARCHAR(50),
    status ENUM('pending', 'executed', 'failed', 'cancelled') DEFAULT 'pending',
    sent_by INT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    executed_at TIMESTAMP NULL,
    response TEXT,
    
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE,
    FOREIGN KEY (sent_by) REFERENCES users(id) ON DELETE SET NULL
);

-- جدول التنبيهات
CREATE TABLE IF NOT EXISTS alerts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(100),
    alert_type ENUM('cpu', 'ram', 'disk', 'network', 'offline', 'custom'),
    severity ENUM('low', 'medium', 'high', 'critical'),
    message TEXT,
    acknowledged BOOLEAN DEFAULT 0,
    acknowledged_by INT,
    acknowledged_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE,
    FOREIGN KEY (acknowledged_by) REFERENCES users(id) ON DELETE SET NULL
);

-- إدخال بيانات تجريبية
INSERT INTO users (username, email, password, full_name, role) VALUES
('admin', 'admin@system.com', '$2y$10$YourHashedPasswordHere', 'المسؤول العام', 'admin'),
('manager', 'manager@system.com', '$2y$10$YourHashedPasswordHere', 'مدير النظام', 'manager'),
('viewer', 'viewer@system.com', '$2y$10$YourHashedPasswordHere', 'مشاهد', 'viewer');



-- في ملف config/schema.sql
CREATE TABLE IF NOT EXISTS devices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(100) UNIQUE NOT NULL,
    device_name VARCHAR(100) NOT NULL,
    device_group VARCHAR(50) DEFAULT 'Default', -- للمناطق
    ip_address VARCHAR(45),
    mac_address VARCHAR(17),
    
    -- معلومات النظام
    os_name VARCHAR(50),
    os_version VARCHAR(50),
    cpu_name VARCHAR(100),
    cpu_cores INT,
    total_ram_gb DECIMAL(5,2),
    total_disk_gb DECIMAL(10,2),
    
    -- حالة الجهاز الحالية
    cpu_usage DECIMAL(5,2),
    ram_usage DECIMAL(5,2),
    disk_usage DECIMAL(5,2),
    internet_status BOOLEAN DEFAULT 1,
    last_seen TIMESTAMP,
    
    -- إعدادات RustDesk للتحكم عن بعد
    rustdesk_id VARCHAR(50),
    rustdesk_password VARCHAR(100),
    
    -- إعدادات الـ Agent
    agent_version VARCHAR(20),
    update_interval INT DEFAULT 60, -- ثواني
    is_active BOOLEAN DEFAULT 1,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول سجل البيانات التاريخية
CREATE TABLE IF NOT EXISTS device_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(100),
    cpu_usage DECIMAL(5,2),
    ram_usage DECIMAL(5,2),
    disk_usage DECIMAL(5,2),
    network_up DECIMAL(10,2), -- Mbps
    network_down DECIMAL(10,2), -- Mbps
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices(device_id)
);

-- جدول التقارير
CREATE TABLE reports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    report_type ENUM('daily', 'weekly', 'monthly', 'financial', 'analytical', 'custom') NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
    file_path VARCHAR(255),
    data JSON,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- جدول التنبيهات
CREATE TABLE alerts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    alert_type ENUM('info', 'success', 'warning', 'error', 'system') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    is_global BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- جدول المهام
CREATE TABLE tasks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    assigned_to INT,
    assigned_by INT,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    status ENUM('pending', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
    due_date DATE,
    completed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
);

-- جدول سجل النشاط
CREATE TABLE user_activity (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    activity_type VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- جدول جلسات الدخول
CREATE TABLE user_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    device_info TEXT,
    ip_address VARCHAR(45),
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- جدول الإعدادات العامة
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type VARCHAR(50) DEFAULT 'text',
    category VARCHAR(50),
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- إدراج البيانات الأولية
INSERT INTO users (name, email, password, role) VALUES
('مدير النظام', 'admin@system.com', '$2y$10$YourHashedPasswordHere', 'admin'),
('محرر النظام', 'editor@system.com', '$2y$10$YourHashedPasswordHere', 'editor'),
('مشاهد النظام', 'viewer@system.com', '$2y$10$YourHashedPasswordHere', 'viewer');

-- إدراج الإعدادات العامة
INSERT INTO system_settings (setting_key, setting_value, setting_type, category, description) VALUES
('site_name', 'النظام الإداري المتكامل', 'text', 'general', 'اسم الموقع'),
('site_url', 'http://localhost/admin-system', 'text', 'general', 'رابط الموقع'),
('admin_email', 'admin@system.com', 'email', 'general', 'بريد المدير'),
('timezone', 'Asia/Riyadh', 'text', 'general', 'المنطقة الزمنية'),
('maintenance_mode', '0', 'boolean', 'general', 'وضع الصيانة'),
('user_registration', '1', 'boolean', 'users', 'تفعيل تسجيل المستخدمين'),
('max_login_attempts', '5', 'number', 'security', 'أقصى محاولات تسجيل دخول'),
('session_timeout', '30', 'number', 'security', 'مدة انتهاء الجلسة بالدقائق');

-- إنشاء الفهارس
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_reports_user_id ON reports(user_id);
CREATE INDEX idx_reports_type ON reports(report_type);
CREATE INDEX idx_alerts_user_id ON alerts(user_id);
CREATE INDEX idx_alerts_is_read ON alerts(is_read);
CREATE INDEX idx_tasks_assigned_to ON tasks(assigned_to);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_user_activity_user_id ON user_activity(user_id);
CREATE INDEX idx_user_activity_type ON user_activity(activity_type);

-- تحسين الأداء بإضافة فهارس
CREATE INDEX idx_devices_last_seen ON devices(last_seen);
CREATE INDEX idx_devices_is_active ON devices(is_active);
CREATE INDEX idx_devices_device_group ON devices(device_group);
CREATE INDEX idx_metrics_device_timestamp ON device_metrics(device_id, timestamp);
CREATE INDEX idx_metrics_timestamp ON device_metrics(timestamp);
CREATE INDEX idx_alerts_device_created ON alerts(device_id, created_at);