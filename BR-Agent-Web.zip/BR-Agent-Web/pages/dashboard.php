<?php
session_start();
require_once '../config/db.php';
require_once '../includes/auth_check.php';

// جلب إحصائيات المستخدم
$user_id = $_SESSION['user_id'];
$stats = [];

// إحصائيات المستخدم
$stmt = $pdo->prepare("
    SELECT 
        (SELECT COUNT(*) FROM users WHERE is_active = 1) as total_users,
        (SELECT COUNT(*) FROM reports WHERE user_id = ?) as user_reports,
        (SELECT COUNT(*) FROM alerts WHERE user_id = ? AND is_read = 0) as unread_alerts,
        (SELECT COUNT(*) FROM tasks WHERE assigned_to = ? AND status = 'pending') as pending_tasks
");
$stmt->execute([$user_id, $user_id, $user_id]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// جلب آخر التنبيهات
$stmt = $pdo->prepare("
    SELECT * FROM alerts 
    WHERE user_id = ? OR is_global = 1
    ORDER BY created_at DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$recent_alerts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب آخر التقارير
$stmt = $pdo->prepare("
    SELECT * FROM reports 
    WHERE user_id = ?
    ORDER BY created_at DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$recent_reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب بيانات الرسم البياني
$chart_data = [];
$stmt = $pdo->prepare("
    SELECT DATE(created_at) as date, COUNT(*) as count 
    FROM reports 
    WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY DATE(created_at) 
    ORDER BY date
");
$stmt->execute([$user_id]);
$chart_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - النظام الإداري</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chart.js">
</head>
<body>
    <!-- شريط التنقل العلوي -->
    <?php include '../includes/header.php'; ?>
    
    <!-- الشريط الجانبي -->
    <?php include '../includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <main class="main-content">
        <!-- رأس الصفحة -->
        <div class="page-header">
            <div>
                <h1><i class="fas fa-tachometer-alt"></i> لوحة التحكم</h1>
                <p class="welcome-message">مرحباً <?php echo $_SESSION['user_name']; ?>! 👋</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-primary" id="quickReport">
                    <i class="fas fa-plus"></i> تقرير جديد
                </button>
                <button class="btn btn-secondary" id="refreshDashboard">
                    <i class="fas fa-sync-alt"></i> تحديث
                </button>
            </div>
        </div>
        
        <!-- الإحصائيات -->
        <div class="stats-grid">
            <div class="stat-card stat-users">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_users'] ?? 0; ?></h3>
                    <p>إجمالي المستخدمين</p>
                </div>
                <a href="users.php" class="stat-link">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
            
            <div class="stat-card stat-reports">
                <div class="stat-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['user_reports'] ?? 0; ?></h3>
                    <p>تقاريرك</p>
                </div>
                <a href="reports.php" class="stat-link">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
            
            <div class="stat-card stat-alerts">
                <div class="stat-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['unread_alerts'] ?? 0; ?></h3>
                    <p>تنبيهات غير مقروءة</p>
                </div>
                <a href="alerts.php" class="stat-link">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
            
            <div class="stat-card stat-tasks">
                <div class="stat-icon">
                    <i class="fas fa-tasks"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['pending_tasks'] ?? 0; ?></h3>
                    <p>مهام معلقة</p>
                </div>
                <a href="tasks.php" class="stat-link">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
        </div>
        
        <!-- الرسم البياني والتنبيهات -->
        <div class="dashboard-row">
            <!-- الرسم البياني -->
            <div class="chart-card">
                <div class="card-header">
                    <h3><i class="fas fa-chart-line"></i> نشاط التقارير (آخر 30 يوم)</h3>
                    <div class="chart-actions">
                        <select id="chartPeriod">
                            <option value="7">7 أيام</option>
                            <option value="30" selected>30 يوم</option>
                            <option value="90">90 يوم</option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <canvas id="reportsChart"></canvas>
                </div>
            </div>
            
            <!-- التنبيهات الأخيرة -->
            <div class="alerts-card">
                <div class="card-header">
                    <h3><i class="fas fa-bell"></i> التنبيهات الأخيرة</h3>
                    <a href="alerts.php" class="btn-link">عرض الكل</a>
                </div>
                <div class="card-body">
                    <?php if (empty($recent_alerts)): ?>
                        <div class="empty-state">
                            <i class="fas fa-bell-slash"></i>
                            <p>لا توجد تنبيهات جديدة</p>
                        </div>
                    <?php else: ?>
                        <div class="alerts-list">
                            <?php foreach ($recent_alerts as $alert): ?>
                                <div class="alert-item <?php echo $alert['is_read'] ? '' : 'unread'; ?>">
                                    <div class="alert-type">
                                        <?php
                                        $alert_icons = [
                                            'info' => 'fas fa-info-circle text-primary',
                                            'success' => 'fas fa-check-circle text-success',
                                            'warning' => 'fas fa-exclamation-triangle text-warning',
                                            'error' => 'fas fa-times-circle text-danger'
                                        ];
                                        $icon_class = $alert_icons[$alert['type']] ?? 'fas fa-bell';
                                        ?>
                                        <i class="<?php echo $icon_class; ?>"></i>
                                    </div>
                                    <div class="alert-content">
                                        <h4><?php echo htmlspecialchars($alert['title']); ?></h4>
                                        <p><?php echo htmlspecialchars(substr($alert['message'], 0, 60)); ?>...</p>
                                        <small class="text-muted">
                                            <?php echo date('H:i - Y/m/d', strtotime($alert['created_at'])); ?>
                                        </small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- التقارير الأخيرة والمهام -->
        <div class="dashboard-row">
            <!-- التقارير الأخيرة -->
            <div class="reports-card">
                <div class="card-header">
                    <h3><i class="fas fa-file-alt"></i> التقارير الأخيرة</h3>
                    <a href="reports.php" class="btn-link">عرض الكل</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>اسم التقرير</th>
                                    <th>النوع</th>
                                    <th>التاريخ</th>
                                    <th>الحالة</th>
                                    <th>إجراء</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_reports as $report): ?>
                                    <tr>
                                        <td><?php echo $report['id']; ?></td>
                                        <td><?php echo htmlspecialchars($report['title']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $report['type']; ?>">
                                                <?php echo $report['type']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('Y/m/d', strtotime($report['created_at'])); ?></td>
                                        <td>
                                            <span class="status status-<?php echo $report['status']; ?>">
                                                <?php echo $report['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="view_report.php?id=<?php echo $report['id']; ?>" 
                                                   class="btn-icon" title="عرض">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="edit_report.php?id=<?php echo $report['id']; ?>" 
                                                   class="btn-icon" title="تعديل">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="download_report.php?id=<?php echo $report['id']; ?>" 
                                                   class="btn-icon" title="تحميل">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- المهام السريعة -->
            <div class="quick-actions-card">
                <div class="card-header">
                    <h3><i class="fas fa-bolt"></i> إجراءات سريعة</h3>
                </div>
                <div class="card-body">
                    <div class="quick-actions">
                        <a href="create_report.php" class="quick-action">
                            <i class="fas fa-plus-circle"></i>
                            <span>إنشاء تقرير جديد</span>
                        </a>
                        <a href="users.php?action=add" class="quick-action">
                            <i class="fas fa-user-plus"></i>
                            <span>إضافة مستخدم جديد</span>
                        </a>
                        <a href="settings.php" class="quick-action">
                            <i class="fas fa-cog"></i>
                            <span>تعديل الإعدادات</span>
                        </a>
                        <a href="export_data.php" class="quick-action">
                            <i class="fas fa-file-export"></i>
                            <span>تصدير البيانات</span>
                        </a>
                        <a href="help.php" class="quick-action">
                            <i class="fas fa-question-circle"></i>
                            <span>مركز المساعدة</span>
                        </a>
                        <a href="backup.php" class="quick-action">
                            <i class="fas fa-database"></i>
                            <span>نسخة احتياطية</span>
                        </a>
                    </div>
                    
                    <!-- معلومات النظام -->
                    <div class="system-info">
                        <h4>معلومات النظام</h4>
                        <ul>
                            <li>
                                <span>آخر تحديث:</span>
                                <strong>اليوم <?php echo date('H:i'); ?></strong>
                            </li>
                            <li>
                                <span>إصدار النظام:</span>
                                <strong>v2.1.4</strong>
                            </li>
                            <li>
                                <span>حالة الخادم:</span>
                                <span class="status status-success">نشط</span>
                            </li>
                            <li>
                                <span>مساحة التخزين:</span>
                                <strong>1.2GB / 5GB</strong>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <!-- نموذج التقرير السريع -->
    <div id="quickReportModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus"></i> تقرير جديد</h3>
                <button class="close-modal">&times;</button>
            </div>
            <form id="quickReportForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="reportTitle">عنوان التقرير</label>
                        <input type="text" id="reportTitle" required>
                    </div>
                    <div class="form-group">
                        <label for="reportType">نوع التقرير</label>
                        <select id="reportType" required>
                            <option value="">اختر النوع</option>
                            <option value="daily">يومي</option>
                            <option value="weekly">أسبوعي</option>
                            <option value="monthly">شهري</option>
                            <option value="financial">مالي</option>
                            <option value="analytical">تحليلي</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="reportDescription">الوصف</label>
                        <textarea id="reportDescription" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary close-modal">إلغاء</button>
                    <button type="submit" class="btn btn-primary">إنشاء التقرير</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../assets/js/dashboard.js"></script>
    <script src="../assets/js/forms.js"></script>
    <script>
        // بيانات الرسم البياني
        const chartData = <?php echo json_encode($chart_data); ?>;
        
        // إنشاء الرسم البياني
        const ctx = document.getElementById('reportsChart').getContext('2d');
        const reportsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: chartData.map(item => item.date),
                datasets: [{
                    label: 'عدد التقارير',
                    data: chartData.map(item => item.count),
                    borderColor: '#4e73df',
                    backgroundColor: 'rgba(78, 115, 223, 0.05)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: {
                                family: 'Tahoma, Arial, sans-serif'
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
        
        // تحديث الرسم البياني حسب الفترة
        document.getElementById('chartPeriod').addEventListener('change', function() {
            // هنا يمكنك جلب البيانات الجديدة حسب الفترة
            console.log('تحديث الرسم البياني للفترة:', this.value + ' أيام');
        });
        
        // نموذج التقرير السريع
        document.getElementById('quickReport').addEventListener('click', function() {
            document.getElementById('quickReportModal').style.display = 'flex';
        });
        
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('quickReportModal').style.display = 'none';
            });
        });
        
        // إغلاق النموذج بالضغط خارج المحتوى
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('quickReportModal');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        // معالجة نموذج التقرير السريع
        document.getElementById('quickReportForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                title: document.getElementById('reportTitle').value,
                type: document.getElementById('reportType').value,
                description: document.getElementById('reportDescription').value
            };
            
            // محاكاة إرسال البيانات
            setTimeout(() => {
                alert('تم إنشاء التقرير بنجاح!');
                document.getElementById('quickReportModal').style.display = 'none';
                this.reset();
                // تحديث الصفحة أو إضافة التقرير ديناميكياً
                location.reload();
            }, 1000);
        });
    </script>
</body>
</html>