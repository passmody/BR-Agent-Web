<?php
header('Content-Type: application/json');
require_once '../config/db.php';

$device_id = $_GET['device_id'] ?? '';

if (empty($device_id)) {
    echo json_encode(['error' => 'معرف الجهاز مطلوب']);
    exit();
}

try {
    // جلب معلومات الجهاز
    $stmt = $pdo->prepare("
        SELECT d.*, u.username as created_by_name
        FROM devices d
        LEFT JOIN users u ON d.created_by = u.id
        WHERE d.device_id = :device_id
    ");
    $stmt->execute([':device_id' => $device_id]);
    $device = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$device) {
        echo json_encode(['error' => 'الجهاز غير موجود']);
        exit();
    }
    
    // جلب المقاييس التاريخية (آخر 24 ساعة)
    $stmt = $pdo->prepare("
        SELECT * FROM device_metrics 
        WHERE device_id = :device_id 
        AND timestamp >= NOW() - INTERVAL 24 HOUR
        ORDER BY timestamp ASC
    ");
    $stmt->execute([':device_id' => $device_id]);
    $metrics = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // جلب النشاطات الحديثة
    $stmt = $pdo->prepare("
        SELECT * FROM activity_logs 
        WHERE device_id = :device_id 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $stmt->execute([':device_id' => $device_id]);
    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // جلب الإحصائيات
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_alerts,
            SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high_alerts,
            MIN(timestamp) as first_seen,
            MAX(timestamp) as last_data
        FROM device_metrics 
        WHERE device_id = :device_id
    ");
    $stmt->execute([':device_id' => $device_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'device' => $device,
        'metrics' => $metrics,
        'activities' => $activities,
        'stats' => $stats
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['error' => 'خطأ في قاعدة البيانات']);
}
?>