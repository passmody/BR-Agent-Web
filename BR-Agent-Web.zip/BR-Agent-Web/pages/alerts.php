<?php
session_start();
require_once '../config/db.php';
require_once '../includes/auth_check.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// جلب التنبيهات من قاعدة البيانات
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT * FROM alerts 
    WHERE user_id = ? OR is_global = 1
    ORDER BY created_at DESC
    LIMIT 50
");
$stmt->execute([$user_id]);
$alerts = $stmt->fetchAll(PDO::FETCH_ASSOB);

// تحديث التنبيهات كمقروءة
$pdo->prepare("UPDATE alerts SET is_read = 1 WHERE user_id = ? AND is_read = 0")
    ->execute([$user_id]);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التنبيهات</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/alerts.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="page-header">
            <h1><i class="icon-bell"></i> التنبيهات</h1>
            <div class="header-actions">
                <button class="btn btn-secondary" id="markAllRead">تعيين الكل كمقروء</button>
                <button class="btn btn-danger" id="clearAll">حذف الكل</button>
            </div>
        </div>

        <div class="alerts-container">
            <?php if (empty($alerts)): ?>
                <div class="empty-state">
                    <i class="icon-bell-off"></i>
                    <h3>لا توجد تنبيهات</h3>
                    <p>ستظهر هنا أي تنبيهات جديدة تتلقاها</p>
                </div>
            <?php else: ?>
                <?php foreach ($alerts as $alert): ?>
                <div class="alert-card <?php echo $alert['is_read'] ? 'read' : 'unread'; ?> 
                    alert-<?php echo $alert['type']; ?>">
                    <div class="alert-icon">
                        <?php
                        $icons = [
                            'info' => 'ℹ️',
                            'success' => '✅',
                            'warning' => '⚠️',
                            'error' => '❌',
                            'system' => '🖥️'
                        ];
                        echo $icons[$alert['type']] ?? '🔔';
                        ?>
                    </div>
                    <div class="alert-content">
                        <h4><?php echo htmlspecialchars($alert['title']); ?></h4>
                        <p><?php echo htmlspecialchars($alert['message']); ?></p>
                        <small class="alert-time">
                            <?php echo date('Y-m-d H:i', strtotime($alert['created_at'])); ?>
                        </small>
                    </div>
                    <div class="alert-actions">
                        <?php if (!$alert['is_read']): ?>
                            <button class="btn-mark-read" data-id="<?php echo $alert['id']; ?>">
                                تعيين كمقروء
                            </button>
                        <?php endif; ?>
                        <button class="btn-delete" data-id="<?php echo $alert['id']; ?>">
                            حذف
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <script src="../assets/js/alerts.js"></script>
</body>
</html>