# agent_monitor.py
import psutil
import platform
import socket
import requests
import json
import time
from datetime import datetime
import uuid

class DeviceMonitor:
    def __init__(self, server_url, device_id, device_name):
        self.server_url = server_url
        self.device_id = device_id
        self.device_name = device_name
        
        # معلومات الجهاز الثابتة
        self.system_info = self.get_system_info()
        
    def get_system_info(self):
        """جمع معلومات النظام الثابتة"""
        return {
            'device_id': self.device_id,
            'device_name': self.device_name,
            'os_name': platform.system(),
            'os_version': platform.version(),
            'cpu_name': platform.processor(),
            'cpu_cores': psutil.cpu_count(logical=False),
            'total_ram_gb': round(psutil.virtual_memory().total / (1024**3), 2),
            'total_disk_gb': round(psutil.disk_usage('/').total / (1024**3), 2),
            'mac_address': ':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff) 
                                   for elements in range(0,2*6,2)][::-1])
        }
    
    def get_current_metrics(self):
        """جمع المقاييس الحية"""
        # استخدام المعالج
        cpu_percent = psutil.cpu_percent(interval=1)
        
        # استخدام الذاكرة
        memory = psutil.virtual_memory()
        ram_percent = memory.percent
        ram_used_gb = round(memory.used / (1024**3), 2)
        
        # استخدام القرص
        disk = psutil.disk_usage('/')
        disk_percent = disk.percent
        disk_used_gb = round(disk.used / (1024**3), 2)
        
        # حالة الإنترنت
        internet_status = self.check_internet()
        
        # سرعة الشبكة (مبسطة)
        net_io = psutil.net_io_counters()
        network_up = round(net_io.bytes_sent / 1024, 2)  # KB
        network_down = round(net_io.bytes_recv / 1024, 2)  # KB
        
        return {
            'cpu_usage': cpu_percent,
            'ram_usage': ram_percent,
            'ram_used_gb': ram_used_gb,
            'disk_usage': disk_percent,
            'disk_used_gb': disk_used_gb,
            'internet_status': internet_status,
            'network_up_kb': network_up,
            'network_down_kb': network_down,
            'timestamp': datetime.now().isoformat()
        }
    
    def check_internet(self):
        """فحص اتصال الإنترنت"""
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
    
    def send_to_server(self, data):
        """إرسال البيانات للسيرفر"""
        try:
            response = requests.post(
                f"{self.server_url}/api/save_metrics.php",
                json=data,
                timeout=5
            )
            return response.status_code == 200
        except:
            return False
    
    def run(self, interval=60):
        """تشغيل المراقبة المستمرة"""
        print(f"بدء مراقبة الجهاز: {self.device_name}")
        
        # إرسال معلومات النظام أول مرة
        self.send_to_server({
            'type': 'system_info',
            **self.system_info
        })
        
        # المراقبة المستمرة
        while True:
            try:
                # جمع البيانات الحالية
                metrics = self.get_current_metrics()
                
                # إرسال للسيرفر
                success = self.send_to_server({
                    'type': 'metrics',
                    'device_id': self.device_id,
                    **metrics
                })
                
                if success:
                    print(f"✓ بيانات مرسلة: {datetime.now().strftime('%H:%M:%S')}")
                else:
                    print(f"✗ فشل الإرسال: {datetime.now().strftime('%H:%M:%S')}")
                
                # الانتظار للدورة التالية
                time.sleep(interval)
                
            except KeyboardInterrupt:
                print("\nإيقاف المراقبة...")
                break
            except Exception as e:
                print(f"خطأ: {e}")
                time.sleep(interval)

if __name__ == "__main__":
    # إعدادات الـ Agent
    SERVER_URL = "http://your-server.com/dashboard"
    DEVICE_ID = socket.gethostname()  # أو توليد ID فريد
    DEVICE_NAME = "جهاز مكتب المدير"
    
    # تشغيل الـ Agent
    monitor = DeviceMonitor(SERVER_URL, DEVICE_ID, DEVICE_NAME)
    monitor.run(interval=60)  # كل 60 ثانية