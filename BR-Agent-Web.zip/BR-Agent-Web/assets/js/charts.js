// assets/js/charts.js - مكتبة المخططات

// مخططات Chart.js
let resourceChart = null;
let statusChart = null;
let cpuChart = null;
let memoryChart = null;

// تهيئة جميع المخططات
function initializeCharts() {
    initializeResourceChart();
    initializeStatusChart();
    initializeCpuChart();
    initializeMemoryChart();
}

// مخطط استخدام الموارد
function initializeResourceChart() {
    const ctx = document.getElementById('resource-chart').getContext('2d');
    
    resourceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'CPU %',
                    data: [],
                    borderColor: '#4e73df',
                    backgroundColor: 'rgba(78, 115, 223, 0.05)',
                    pointBackgroundColor: '#4e73df',
                    pointBorderColor: '#4e73df',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: '#4e73df',
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'الذاكرة %',
                    data: [],
                    borderColor: '#1cc88a',
                    backgroundColor: 'rgba(28, 200, 138, 0.05)',
                    pointBackgroundColor: '#1cc88a',
                    pointBorderColor: '#1cc88a',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: '#1cc88a',
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'القرص %',
                    data: [],
                    borderColor: '#f6c23e',
                    backgroundColor: 'rgba(246, 194, 62, 0.05)',
                    pointBackgroundColor: '#f6c23e',
                    pointBorderColor: '#f6c23e',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: '#f6c23e',
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    fill: true,
                    tension: 0.4
                }
            ]
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 7
                    }
                },
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        padding: 20,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    backgroundColor: "rgb(255,255,255)",
                    bodyColor: "#858796",
                    titleColor: '#6e707e',
                    titleFont: {
                        size: 14
                    },
                    bodyFont: {
                        size: 14
                    },
                    borderColor: '#dddfeb',
                    borderWidth: 1,
                    xPadding: 15,
                    yPadding: 15,
                    displayColors: false,
                    intersect: false,
                    mode: 'index',
                    caretPadding: 10,
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
}

// مخطط توزيع الحالة
function initializeStatusChart() {
    const ctx = document.getElementById('status-chart').getContext('2d');
    
    statusChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['سليم', 'تحذير', 'حرج', 'غير متصل'],
            datasets: [{
                data: [0, 0, 0, 0],
                backgroundColor: [
                    '#1cc88a',
                    '#f6c23e',
                    '#e74a3b',
                    '#858796'
                ],
                hoverBackgroundColor: [
                    '#17a673',
                    '#dda20a',
                    '#be2617',
                    '#6c757d'
                ],
                hoverBorderColor: "rgba(234, 236, 244, 1)",
                borderWidth: 2
            }]
        },
        options: {
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: "rgb(255,255,255)",
                    bodyColor: "#858796",
                    borderColor: '#dddfeb',
                    borderWidth: 1,
                    titleColor: '#6e707e',
                    titleFont: {
                        size: 14
                    },
                    bodyFont: {
                        size: 14
                    },
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// مخطط CPU
function initializeCpuChart() {
    const ctx = document.getElementById('cpu-chart').getContext('2d');
    
    cpuChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'استخدام CPU %',
                data: [],
                backgroundColor: function(context) {
                    const value = context.raw;
                    if (value > 80) return '#e74a3b';
                    if (value > 60) return '#f6c23e';
                    return '#1cc88a';
                },
                borderColor: function(context) {
                    const value = context.raw;
                    if (value > 80) return '#be2617';
                    if (value > 60) return '#dda20a';
                    return '#17a673';
                },
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// مخطط الذاكرة
function initializeMemoryChart() {
    const ctx = document.getElementById('memory-chart').getContext('2d');
    
    memoryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'استخدام الذاكرة %',
                data: [],
                backgroundColor: function(context) {
                    const value = context.raw;
                    if (value > 85) return '#e74a3b';
                    if (value > 70) return '#f6c23e';
                    return '#36b9cc';
                },
                borderColor: function(context) {
                    const value = context.raw;
                    if (value > 85) return '#be2617';
                    if (value > 70) return '#dda20a';
                    return '#2c9faf';
                },
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// تحديث المخططات بالبيانات
function updateCharts(data) {
    // تحديث مخطط الموارد
    if (resourceChart && data.resource_usage) {
        const times = data.resource_usage.map(item => item.time);
        const cpuData = data.resource_usage.map(item => item.cpu);
        const memoryData = data.resource_usage.map(item => item.memory);
        const diskData = data.resource_usage.map(item => item.disk);
        
        resourceChart.data.labels = times;
        resourceChart.data.datasets[0].data = cpuData;
        resourceChart.data.datasets[1].data = memoryData;
        resourceChart.data.datasets[2].data = diskData;
        resourceChart.update();
    }
    
    // تحديث مخطط توزيع الحالة
    if (statusChart && data.status_distribution) {
        const statusData = [
            data.status_distribution['سليم'] || 0,
            data.status_distribution['تحذير'] || 0,
            data.status_distribution['حرج'] || 0,
            data.status_distribution['غير متصل'] || 0
        ];
        
        statusChart.data.datasets[0].data = statusData;
        statusChart.update();
    }
}

// تحميل مخططات الأجهزة
function loadDeviceCharts(deviceId) {
    $.ajax({
        url: 'api/get_device_metrics.php',
        method: 'GET',
        data: { device_id: deviceId },
        success: function(response) {
            if (response.success && cpuChart && memoryChart) {
                // تحديث مخطط CPU
                cpuChart.data.labels = response.data.devices.map(d => d.name);
                cpuChart.data.datasets[0].data = response.data.devices.map(d => d.cpu);
                cpuChart.update();
                
                // تحديث مخطط الذاكرة
                memoryChart.data.labels = response.data.devices.map(d => d.name);
                memoryChart.data.datasets[0].data = response.data.devices.map(d => d.memory);
                memoryChart.update();
            }
        }
    });
}

// تحميل مخطط الفروع
function loadBranchesChart() {
    $.ajax({
        url: 'api/get_branches_stats.php',
        method: 'GET',
        success: function(response) {
            if (response.success) {
                updateBranchesChart(response.data);
            }
        }
    });
}

// تصدير المخططات
function downloadChart(chartId) {
    const canvas = document.getElementById(chartId);
    const link = document.createElement('a');
    link.download = `chart-${chartId}-${new Date().toISOString().slice(0,10)}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
}

function downloadChartData(chartId) {
    let chart;
    switch(chartId) {
        case 'resource-chart': chart = resourceChart; break;
        case 'status-chart': chart = statusChart; break;
        case 'cpu-chart': chart = cpuChart; break;
        case 'memory-chart': chart = memoryChart; break;
        default: return;
    }
    
    const data = {
        labels: chart.data.labels,
        datasets: chart.data.datasets
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const link = document.createElement('a');
    link.download = `chart-data-${chartId}-${new Date().toISOString().slice(0,10)}.json`;
    link.href = URL.createObjectURL(dataBlob);
    link.click();
}

// إعادة تعيين التكبير
function resetZoom(chartId) {
    let chart;
    switch(chartId) {
        case 'resource-chart': chart = resourceChart; break;
        default: return;
    }
    
    if (chart && chart.resetZoom) {
        chart.resetZoom();
    }
}

// تهيئة عند تحميل الصفحة
$(document).ready(function() {
    initializeCharts();
    
    // تحميل البيانات كل 30 ثانية
    setInterval(loadDashboardData, 30000);
    
    // تحميل مخططات الأجهزة إذا كانت الصفحة تحتوي عليها
    if ($('#cpu-chart').length && $('#memory-chart').length) {
        loadDeviceCharts();
    }
});