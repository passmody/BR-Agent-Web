<?php
session_start();
require_once '../config/db.php';
require_once '../includes/auth_check.php';

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header('Location: logout.php');
    exit();
}

// تحديث البيانات الشخصية
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    // التحقق من البريد الإلكتروني
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $stmt->execute([$email, $user_id]);
    
    if ($stmt->rowCount() > 0) {
        $error = 'البريد الإلكتروني مستخدم بالفعل';
    } else {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET name = ?, email = ?, phone = ?, updated_at = NOW()
            WHERE id = ?
        ");
        
        if ($stmt->execute([$name, $email, $phone, $user_id])) {
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            $success = 'تم تحديث الملف الشخصي بنجاح';
            
            // تحديث بيانات المستخدم
            $user['name'] = $name;
            $user['email'] = $email;
            $user['phone'] = $phone;
        } else {
            $error = 'حدث خطأ أثناء تحديث البيانات';
        }
    }
}

// تغيير كلمة المرور
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (strlen($new_password) < 6) {
        $error = 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل';
    } elseif ($new_password !== $confirm_password) {
        $error = 'كلمة المرور غير متطابقة';
    } elseif (!password_verify($current_password, $user['password'])) {
        $error = 'كلمة المرور الحالية غير صحيحة';
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("
            UPDATE users 
            SET password = ?, updated_at = NOW()
            WHERE id = ?
        ");
        
        if ($stmt->execute([$hashed_password, $user_id])) {
            $success = 'تم تغيير كلمة المرور بنجاح';
        } else {
            $error = 'حدث خطأ أثناء تغيير كلمة المرور';
        }
    }
}

// رفع صورة الملف الشخصي
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $avatar = $_FILES['avatar'];
    
    if ($avatar['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 2 * 1024 * 1024; // 2MB
        
        if (in_array($avatar['type'], $allowed_types) && $avatar['size'] <= $max_size) {
            $extension = pathinfo($avatar['name'], PATHINFO_EXTENSION);
            $filename = 'avatar_' . $user_id . '_' . time() . '.' . $extension;
            $upload_path = '../uploads/avatars/' . $filename;
            
            // حذف الصورة القديمة إن وجدت
            if (!empty($user['avatar']) && file_exists('../uploads/avatars/' . $user['avatar'])) {
                unlink('../uploads/avatars/' . $user['avatar']);
            }
            
            if (move_uploaded_file($avatar['tmp_name'], $upload_path)) {
                $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                $stmt->execute([$filename, $user_id]);
                
                $user['avatar'] = $filename;
                $success = 'تم تحديث صورة الملف الشخصي بنجاح';
            } else {
                $error = 'فشل في رفع الصورة';
            }
        } else {
            $error = 'نوع الملف غير مسموح أو حجمه أكبر من 2MB';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي - النظام الإداري</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="page-header">
            <h1><i class="fas fa-user-circle"></i> الملف الشخصي</h1>
            <p>إدارة بيانات حسابك الشخصي</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="profile-container">
            <!-- جانب المعلومات الشخصية -->
            <div class="profile-sidebar">
                <div class="profile-card">
                    <div class="profile-avatar">
                        <?php
                        $avatar_path = !empty($user['avatar']) ? 
                            '../uploads/avatars/' . $user['avatar'] : 
                            '../assets/images/default-avatar.png';
                        ?>
                        <img src="<?php echo $avatar_path; ?>" 
                             alt="<?php echo htmlspecialchars($user['name']); ?>"
                             id="avatarPreview">
                        
                        <form method="POST" enctype="multipart/form-data" class="avatar-form">
                            <input type="file" name="avatar" id="avatarInput" accept="image/*" hidden>
                            <label for="avatarInput" class="avatar-upload">
                                <i class="fas fa-camera"></i>
                            </label>
                            <button type="submit" class="avatar-submit" hidden></button>
                        </form>
                    </div>
                    
                    <h2 class="profile-name"><?php echo htmlspecialchars($user['name']); ?></h2>
                    <p class="profile-email"><?php echo htmlspecialchars($user['email']); ?></p>
                    
                    <div class="profile-stats">
                        <div class="stat">
                            <i class="fas fa-user-tag"></i>
                            <div>
                                <h4>الصلاحية</h4>
                                <p>
                                    <?php
                                    $roles = [
                                        'admin' => 'مدير',
                                        'editor' => 'محرر',
                                        'viewer' => 'مشاهد'
                                    ];
                                    echo $roles[$user['role']] ?? $user['role'];
                                    ?>
                                </p>
                            </div>
                        </div>
                        
                        <div class="stat">
                            <i class="fas fa-calendar-alt"></i>
                            <div>
                                <h4>تاريخ التسجيل</h4>
                                <p><?php echo date('Y/m/d', strtotime($user['created_at'])); ?></p>
                            </div>
                        </div>
                        
                        <div class="stat">
                            <i class="fas fa-sign-in-alt"></i>
                            <div>
                                <h4>آخر دخول</h4>
                                <p>
                                    <?php echo $user['last_login'] ? 
                                        date('Y/m/d H:i', strtotime($user['last_login'])) : 
                                        'لم يدخل بعد'; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="profile-quick-links">
                    <a href="dashboard.php" class="quick-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>لوحة التحكم</span>
                    </a>
                    <a href="settings.php" class="quick-link">
                        <i class="fas fa-cog"></i>
                        <span>الإعدادات</span>
                    </a>
                    <a href="activity_log.php" class="quick-link">
                        <i class="fas fa-history"></i>
                        <span>سجل النشاط</span>
                    </a>
                    <a href="logout.php" class="quick-link text-danger">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>تسجيل الخروج</span>
                    </a>
                </div>
            </div>
            
            <!-- المحتوى الرئيسي -->
            <div class="profile-content">
                <!-- علامات التبويب -->
                <div class="profile-tabs">
                    <button class="tab-btn active" data-tab="info">المعلومات الشخصية</button>
                    <button class="tab-btn" data-tab="security">الأمان</button>
                    <button class="tab-btn" data-tab="preferences">التفضيلات</button>
                    <button class="tab-btn" data-tab="activity">النشاط</button>
                </div>
                
                <!-- معلومات شخصية -->
                <div class="tab-pane active" id="info">
                    <form method="POST" class="profile-form">
                        <input type="hidden" name="update_profile" value="1">
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">الاسم الكامل *</label>
                                <input type="text" id="name" name="name" 
                                       value="<?php echo htmlspecialchars($user['name']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">البريد الإلكتروني *</label>
                                <input type="email" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone">رقم الهاتف</label>
                                <input type="tel" id="phone" name="phone" 
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="username">اسم المستخدم</label>
                                <input type="text" id="username" name="username" 
                                       value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" 
                                       disabled>
                                <small>لا يمكن تغيير اسم المستخدم</small>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="bio">نبذة شخصية</label>
                            <textarea id="bio" name="bio" rows="3"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                            <small>اكتب نبذة مختصرة عن نفسك (اختياري)</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ التغييرات
                        </button>
                    </form>
                </div>
                
                <!-- الأمان -->
                <div class="tab-pane" id="security">
                    <form method="POST" class="profile-form">
                        <input type="hidden" name="change_password" value="1">
                        
                        <div class="form-group">
                            <label for="current_password">كلمة المرور الحالية *</label>
                            <div class="password-wrapper">
                                <input type="password" id="current_password" name="current_password" required>
                                <button type="button" class="toggle-password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="new_password">كلمة المرور الجديدة *</label>
                                <div class="password-wrapper">
                                    <input type="password" id="new_password" name="new_password" required>
                                    <button type="button" class="toggle-password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <small>يجب أن تكون 6 أحرف على الأقل</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">تأكيد كلمة المرور *</label>
                                <div class="password-wrapper">
                                    <input type="password" id="confirm_password" name="confirm_password" required>
                                    <button type="button" class="toggle-password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="password-strength">
                            <div class="strength-meter">
                                <div class="strength-bar"></div>
                            </div>
                            <span class="strength-text">قوة كلمة المرور: ضعيفة</span>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-key"></i> تغيير كلمة المرور
                        </button>
                    </form>
                    
                    <div class="security-section">
                        <h3><i class="fas fa-shield-alt"></i> أمان إضافي</h3>
                        
                        <div class="security-item">
                            <div>
                                <h4>المصادقة الثنائية</h4>
                                <p>إضافة طبقة أمان إضافية لحسابك</p>
                            </div>
                            <label class="switch">
                                <input type="checkbox" <?php echo ($user['two_factor_auth'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                        </div>
                        
                        <div class="security-item">
                            <div>
                                <h4>جلسات الدخول النشطة</h4>
                                <p>إدارة الأجهزة التي تم تسجيل الدخول منها</p>
                            </div>
                            <a href="sessions.php" class="btn btn-outline">عرض الجلسات</a>
                        </div>
                    </div>
                </div>
                
                <!-- التفضيلات -->
                <div class="tab-pane" id="preferences">
                    <form method="POST" action="update_preferences.php" class="profile-form">
                        <div class="form-group">
                            <label for="language">اللغة المفضلة</label>
                            <select id="language" name="language">
                                <option value="ar" <?php echo ($user['language'] ?? 'ar') == 'ar' ? 'selected' : ''; ?>>العربية</option>
                                <option value="en" <?php echo ($user['language'] ?? 'ar') == 'en' ? 'selected' : ''; ?>>الإنجليزية</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="theme">المظهر</label>
                            <select id="theme" name="theme">
                                <option value="light" <?php echo ($user['theme'] ?? 'light') == 'light' ? 'selected' : ''; ?>>فاتح</option>
                                <option value="dark" <?php echo ($user['theme'] ?? 'light') == 'dark' ? 'selected' : ''; ?>>داكن</option>
                                <option value="auto" <?php echo ($user['theme'] ?? 'light') == 'auto' ? 'selected' : ''; ?>>تلقائي</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="timezone">المنطقة الزمنية</label>
                            <select id="timezone" name="timezone">
                                <option value="Asia/Riyadh" <?php echo ($user['timezone'] ?? 'Asia/Riyadh') == 'Asia/Riyadh' ? 'selected' : ''; ?>>الرياض (UTC+3)</option>
                                <option value="Asia/Dubai" <?php echo ($user['timezone'] ?? 'Asia/Riyadh') == 'Asia/Dubai' ? 'selected' : ''; ?>>دبي (UTC+4)</option>
                                <option value="UTC" <?php echo ($user['timezone'] ?? 'Asia/Riyadh') == 'UTC' ? 'selected' : ''; ?>>توقيت عالمي</option>
                            </select>
                        </div>
                        
                        <h4>إشعارات</h4>
                        <div class="preferences-list">
                            <label class="preference-item">
                                <input type="checkbox" name="email_notifications" 
                                       <?php echo ($user['email_notifications'] ?? 1) ? 'checked' : ''; ?>>
                                <span>الإشعارات البريدية</span>
                            </label>
                            
                            <label class="preference-item">
                                <input type="checkbox" name="push_notifications" 
                                       <?php echo ($user['push_notifications'] ?? 1) ? 'checked' : ''; ?>>
                                <span>إشعارات التطبيق</span>
                            </label>
                            
                            <label class="preference-item">
                                <input type="checkbox" name="sms_notifications" 
                                       <?php echo ($user['sms_notifications'] ?? 0) ? 'checked' : ''; ?>>
                                <span>إشعارات SMS</span>
                            </label>
                            
                            <label class="preference-item">
                                <input type="checkbox" name="weekly_reports" 
                                       <?php echo ($user['weekly_reports'] ?? 1) ? 'checked' : ''; ?>>
                                <span>تقارير أسبوعية</span>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ التفضيلات
                        </button>
                    </form>
                </div>
                
                <!-- النشاط -->
                <div class="tab-pane" id="activity">
                    <div class="activity-filters">
                        <select id="activityType">
                            <option value="all">جميع الأنشطة</option>
                            <option value="login">تسجيلات الدخول</option>
                            <option value="report">التقارير</option>
                            <option value="profile">تحديث الملف</option>
                            <option value="security">الأمان</option>
                        </select>
                        
                        <input type="date" id="activityDate" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="activity-list">
                        <!-- سيتم ملؤها بـ JavaScript -->
                        <div class="empty-state">
                            <i class="fas fa-history"></i>
                            <p>لا توجد أنشطة مسجلة</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/js/profile.js"></script>
    <script>
        // تغيير علامات التبويب
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // إزالة النشاط من جميع الأزرار
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                // إخفاء جميع المحتويات
                document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
                
                // تفعيل الزر الحالي
                this.classList.add('active');
                // إظهار المحتوى المناسب
                const tabId = this.dataset.tab;
                document.getElementById(tabId).classList.add('active');
            });
        });
        
        // معاينة صورة الملف الشخصي
        document.getElementById('avatarInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatarPreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
                
                // إرسال النموذج تلقائياً
                document.querySelector('.avatar-submit').click();
            }
        });
        
        // تبديل عرض كلمة المرور
        document.querySelectorAll('.toggle-password').forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.parentElement.querySelector('input');
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
        
        // قياس قوة كلمة المرور
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.querySelector('.strength-bar');
            const strengthText = document.querySelector('.strength-text');
            
            let strength = 0;
            let text = 'ضعيفة';
            let color = '#dc3545';
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            if (strength >= 4) {
                text = 'قوية';
                color = '#28a745';
            } else if (strength >= 2) {
                text = 'متوسطة';
                color = '#ffc107';
            }
            
            strengthBar.style.width = (strength * 20) + '%';
            strengthBar.style.backgroundColor = color;
            strengthText.textContent = 'قوة كلمة المرور: ' + text;
        });
    </script>
</body>
</html>