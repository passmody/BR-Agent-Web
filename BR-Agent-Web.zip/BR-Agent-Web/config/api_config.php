<?php
// config/api_config.php

class APIConfig {
    // مفاتيح API للوصول الخارجي
    public static $api_keys = [
        'mobile_app' => [
            'key' => 'MOB_APP_KEY_' . bin2hex(random_bytes(16)),
            'permissions' => ['read_devices', 'read_alerts', 'send_commands'],
            'rate_limit' => 100 // requests per hour
        ],
        'third_party' => [
            'key' => 'EXT_API_KEY_' . bin2hex(random_bytes(16)),
            'permissions' => ['read_devices'],
            'rate_limit' => 50
        ],
        'agent' => [
            'key' => 'AGENT_KEY_' . bin2hex(random_bytes(16)),
            'permissions' => ['send_metrics', 'receive_commands'],
            'rate_limit' => 1000
        ]
    ];
    
    // Endpoints المتاحة
    public static $endpoints = [
        'v1' => [
            'GET' => [
                '/devices' => 'get_devices_list',
                '/devices/{id}' => 'get_device_info',
                '/devices/{id}/metrics' => 'get_device_metrics',
                '/alerts' => 'get_alerts',
                '/dashboard' => 'get_dashboard_data'
            ],
            'POST' => [
                '/devices' => 'register_device',
                '/devices/{id}/command' => 'send_command',
                '/metrics' => 'receive_metrics',
                '/alerts' => 'create_alert'
            ],
            'PUT' => [
                '/devices/{id}' => 'update_device',
                '/alerts/{id}' => 'update_alert'
            ],
            'DELETE' => [
                '/devices/{id}' => 'remove_device'
            ]
        ]
    ];
    
    // توثيق الـAPI
    public static $documentation = [
        'base_url' => 'https://your-domain.com/api',
        'authentication' => 'API Key in Header: X-API-Key: your_api_key',
        'response_format' => 'JSON',
        'rate_limiting' => '100 requests per hour per key',
        'error_codes' => [
            200 => 'Success',
            400 => 'Bad Request',
            401 => 'Unauthorized',
            403 => 'Forbidden',
            404 => 'Not Found',
            429 => 'Too Many Requests',
            500 => 'Internal Server Error'
        ]
    ];
}

// Middleware للتحقق من الـAPI Key
class APIMiddleware {
    public static function authenticate($required_permissions = []) {
        $api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
        
        if (empty($api_key)) {
            http_response_code(401);
            die(json_encode(['error' => 'API key required']));
        }
        
        // البحث عن الـKey في القائمة
        $valid_key = false;
        $key_data = null;
        
        foreach (APIConfig::$api_keys as $key_name => $key_info) {
            if ($key_info['key'] === $api_key) {
                $valid_key = true;
                $key_data = $key_info;
                break;
            }
        }
        
        if (!$valid_key) {
            http_response_code(403);
            die(json_encode(['error' => 'Invalid API key']));
        }
        
        // التحقق من الصلاحيات
        foreach ($required_permissions as $permission) {
            if (!in_array($permission, $key_data['permissions'])) {
                http_response_code(403);
                die(json_encode(['error' => 'Insufficient permissions']));
            }
        }
        
        return $key_data;
    }
    
    public static function rateLimit($key_data) {
        $key_hash = md5($_SERVER['HTTP_X_API_KEY']);
        $cache_file = '../temp/api_ratelimit_' . $key_hash . '.json';
        
        $now = time();
        $window = 3600; // ساعة واحدة
        
        if (file_exists($cache_file)) {
            $data = json_decode(file_get_contents($cache_file), true);
            
            // تنظيف الطلبات القديمة
            $data['requests'] = array_filter($data['requests'], function($timestamp) use ($now, $window) {
                return ($now - $timestamp) < $window;
            });
            
            // التحقق من الحد
            if (count($data['requests']) >= $key_data['rate_limit']) {
                http_response_code(429);
                die(json_encode([
                    'error' => 'Rate limit exceeded',
                    'retry_after' => $window - ($now - min($data['requests']))
                ]));
            }
            
            // إضافة الطلب الحالي
            $data['requests'][] = $now;
        } else {
            $data = [
                'requests' => [$now],
                'created_at' => $now
            ];
        }
        
        file_put_contents($cache_file, json_encode($data));
    }
}
?>