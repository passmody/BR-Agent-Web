<?php
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $client = FirebaseConnection::getClient();
    
    if (!$client) {
        throw new Exception('فشل الاتصال بـ Firebase');
    }
    
    $devicesRef = $client->collection('devices');
    
    // التحقق من وجود فلتر
    $branch_id = isset($_GET['branch_id']) ? sanitize_input($_GET['branch_id']) : null;
    
    if ($branch_id) {
        $query = $devicesRef->where('branch_id', '=', $branch_id);
    } else {
        $query = $devicesRef;
    }
    
    $devicesSnapshot = $query->documents();
    
    $devices = [];
    foreach ($devicesSnapshot as $document) {
        if ($document->exists()) {
            $data = $document->data();
            $data['id'] = $document->id();
            
            // حساب الحالة
            $data['status'] = calculate_device_status($data);
            $data['last_update_formatted'] = get_time_ago($data['last_update'] ?? null);
            
            $devices[] = $data;
        }
    }
    
    json_response([
        'success' => true,
        'devices' => $devices,
        'count' => count($devices),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    json_response([
        'success' => false,
        'message' => $e->getMessage(),
        'devices' => [],
        'count' => 0
    ], 500);
}

function calculate_device_status($device) {
    // حساب العمر
    $last_update = $device['last_update'] ?? null;
    if (!$last_update) {
        return 'غير متصل';
    }
    
    $age_seconds = time() - strtotime($last_update);
    if ($age_seconds > 600) { // أكثر من 10 دقائق
        return 'غير متصل';
    }
    
    // حساب الشذوذ
    $anomaly_score = $device['anomaly_score'] ?? 0;
    if ($anomaly_score > 80) {
        return 'حرج';
    } elseif ($anomaly_score > 60) {
        return 'تحذير';
    }
    
    return 'سليم';
}
?>