<?php
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $client = FirebaseConnection::getClient();
    
    if (!$client) {
        throw new Exception('فشل الاتصال بـ Firebase');
    }
    
    $branchesRef = $client->collection('branches');
    $branchesSnapshot = $branchesRef->documents();
    
    $branches = [];
    foreach ($branchesSnapshot as $document) {
        if ($document->exists()) {
            $data = $document->data();
            $data['id'] = $document->id();
            $branches[] = $data;
        }
    }
    
    json_response([
        'success' => true,
        'branches' => $branches,
        'count' => count($branches),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    json_response([
        'success' => false,
        'message' => $e->getMessage(),
        'branches' => [],
        'count' => 0
    ], 500);
}
?>