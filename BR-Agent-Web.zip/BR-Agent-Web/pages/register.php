<?php
session_start();
require_once '../config/db.php';

// إذا كان المستخدم مسجل الدخول بالفعل، توجيهه للصفحة الرئيسية
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // جمع البيانات
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $agree_terms = isset($_POST['agree_terms']) ? 1 : 0;
    
    // التحقق من البيانات
    if (empty($name)) {
        $errors[] = 'الاسم الكامل مطلوب';
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'البريد الإلكتروني غير صالح';
    }
    
    if (strlen($password) < 6) {
        $errors[] = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    }
    
    if ($password !== $confirm_password) {
        $errors[] = 'كلمة المرور غير متطابقة';
    }
    
    if (!$agree_terms) {
        $errors[] = 'يجب الموافقة على شروط الخدمة';
    }
    
    // التحقق من عدم وجود البريد الإلكتروني مسبقاً
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $errors[] = 'البريد الإلكتروني مستخدم بالفعل';
        }
    }
    
    // إنشاء الحساب
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $username = strtolower(str_replace(' ', '.', $name)) . rand(100, 999);
        
        $stmt = $pdo->prepare("
            INSERT INTO users (name, email, phone, username, password, role, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, 'viewer', 1, NOW())
        ");
        
        if ($stmt->execute([$name, $email, $phone, $username, $hashed_password])) {
            // تسجيل الدخول تلقائياً
            $user_id = $pdo->lastInsertId();
            
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // إنشاء الجلسة
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['login_time'] = time();
            
            // تسجيل النشاط
            $stmt = $pdo->prepare("
                INSERT INTO user_activity (user_id, activity_type, description)
                VALUES (?, 'register', 'إنشاء حساب جديد')
            ");
            $stmt->execute([$user_id]);
            
            // توجيه للصفحة الرئيسية
            header('Location: dashboard.php?welcome=1');
            exit();
        } else {
            $errors[] = 'حدث خطأ أثناء إنشاء الحساب. يرجى المحاولة مرة أخرى.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب جديد - النظام الإداري</title>
    <link rel="stylesheet" href="../assets/css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-chart-line"></i>
                    <h1>إنشاء حساب جديد</h1>
                </div>
                <p>انضم إلى النظام الإداري المتكامل الآن</p>
            </div>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo $error; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="login-form" id="registerForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">
                            <i class="fas fa-user"></i> الاسم الكامل *
                        </label>
                        <input type="text" id="name" name="name" 
                               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" 
                               required placeholder="ادخل اسمك الكامل">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">
                            <i class="fas fa-envelope"></i> البريد الإلكتروني *
                        </label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                               required placeholder="example@domain.com">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="phone">
                        <i class="fas fa-phone"></i> رقم الهاتف
                    </label>
                    <input type="tel" id="phone" name="phone" 
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" 
                           placeholder="05xxxxxxxx">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i> كلمة المرور *
                        </label>
                        <div class="password-wrapper">
                            <input type="password" id="password" name="password" 
                                   required placeholder="6 أحرف على الأقل">
                            <button type="button" class="toggle-password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">
                            <i class="fas fa-lock"></i> تأكيد كلمة المرور *
                        </label>
                        <div class="password-wrapper">
                            <input type="password" id="confirm_password" name="confirm_password" 
                                   required placeholder="أعد كتابة كلمة المرور">
                            <button type="button" class="toggle-password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="password-strength">
                    <div class="strength-meter">
                        <div class="strength-bar"></div>
                    </div>
                    <span class="strength-text">قوة كلمة المرور: ضعيفة</span>
                </div>
                
                <div class="form-group terms-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="agree_terms" id="agree_terms" 
                               <?php echo isset($_POST['agree_terms']) ? 'checked' : ''; ?>>
                        <span>أوافق على <a href="terms.php" target="_blank">شروط الخدمة</a> 
                        و <a href="privacy.php" target="_blank">سياسة الخصوصية</a></span>
                    </label>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-user-plus"></i> إنشاء الحساب
                </button>
                
                <div class="divider">
                    <span>أو</span>
                </div>
                
                <button type="button" class="btn-google">
                    <i class="fab fa-google"></i> التسجيل بحساب Google
                </button>
            </form>
            
            <div class="login-footer">
                <p>لديك حساب بالفعل؟ <a href="login.php">سجل الدخول الآن</a></p>
                <p><a href="../index.php"><i class="fas fa-home"></i> العودة للرئيسية</a></p>
            </div>
        </div>
        
        <div class="login-side">
            <div class="benefits-list">
                <h2>فوائد الانضمام إلينا</h2>
                <ul>
                    <li><i class="fas fa-check-circle"></i> وصول كامل إلى جميع الميزات</li>
                    <li><i class="fas fa-check-circle"></i> تخزين غير محدود للبيانات</li>
                    <li><i class="fas fa-check-circle"></i> دعم فني متخصص 24/7</li>
                    <li><i class="fas fa-check-circle"></i> تحديثات مجانية مستمرة</li>
                    <li><i class="fas fa-check-circle"></i> تجربة مجانية لمدة 30 يوم</li>
                    <li><i class="fas fa-check-circle"></i> إدارة متعددة المستخدمين</li>
                </ul>
                
                <div class="testimonial">
                    <div class="testimonial-content">
                        <p>"هذا النظام غير طريقة إدارة أعمالي بالكامل، أوصي به بشدة!"</p>
                        <div class="testimonial-author">
                            <strong>أحمد محمد</strong>
                            <span>مدير شركة التقنية</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/auth.js"></script>
    <script>
        // قياس قوة كلمة المرور
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.querySelector('.strength-bar');
            const strengthText = document.querySelector('.strength-text');
            
            let strength = 0;
            let text = 'ضعيفة';
            let color = '#dc3545';
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            if (strength >= 4) {
                text = 'قوية';
                color = '#28a745';
            } else if (strength >= 2) {
                text = 'متوسطة';
                color = '#ffc107';
            }
            
            strengthBar.style.width = (strength * 20) + '%';
            strengthBar.style.backgroundColor = color;
            strengthText.textContent = 'قوة كلمة المرور: ' + text;
        });
        
        // التحقق من تطابق كلمة المرور
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (confirmPassword && password !== confirmPassword) {
                this.style.borderColor = '#dc3545';
            } else {
                this.style.borderColor = '#ddd';
            }
        });
        
        // تبديل عرض كلمة المرور
        document.querySelectorAll('.toggle-password').forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.parentElement.querySelector('input');
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
    </script>
</body>
</html>