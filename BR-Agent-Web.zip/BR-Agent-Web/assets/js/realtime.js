// assets/js/realtime.js - التحديث الفوري للبيانات

let realtimeUpdateInterval = null;
let notificationSound = null;
let isPaused = false;

// بدء التحديثات الفورية
function startRealtimeUpdates() {
    // تحميل البيانات أول مرة
    fetchRealtimeData();
    
    // تحديد الفاصل الزمني للتحديث (30 ثانية)
    realtimeUpdateInterval = setInterval(fetchRealtimeData, 30000);
    
    // تهيئة صوت التنبيه
    notificationSound = new Audio('assets/sounds/notification.mp3');
    notificationSound.volume = 0.3;
    
    // إضافة زر الإيقاف المؤقت
    addPauseButton();
    
    // تفعيل WebSocket إذا كان متاحاً
    initializeWebSocket();
}

// جلب البيانات الفورية
function fetchRealtimeData() {
    if (isPaused) return;
    
    $.ajax({
        url: 'api/get_realtime_data.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                updateRealtimeData(response.data);
                
                // التحقق من التنبيهات الجديدة
                if (response.new_alerts && response.new_alerts.length > 0) {
                    showNewAlertsNotification(response.new_alerts);
                }
            }
        },
        error: function(xhr, status, error) {
            console.error('Error fetching realtime data:', error);
        }
    });
}

// تحديث البيانات الفورية
function updateRealtimeData(data) {
    // تحديث المقاييس الرئيسية
    if (data.metrics) {
        updateDashboardMetrics(data.metrics);
    }
    
    // تحديث المخططات
    if (data.charts) {
        updateCharts(data.charts);
    }
    
    // تحديث الجداول
    if (data.alerts) {
        updateRecentAlerts(data.alerts);
    }
    
    if (data.devices) {
        updateRecentDevices(data.devices);
    }
    
    // تحديث وقت آخر تحديث
    $('#last-update').text(moment().format('HH:mm:ss'));
}

// عرض إشعارات التنبيهات الجديدة
function showNewAlertsNotification(alerts) {
    // تشغيل صوت التنبيه
    if (notificationSound) {
        notificationSound.play().catch(e => console.log('Cannot play sound:', e));
    }
    
    // عرض الإشعارات
    alerts.forEach(alert => {
        showToastNotification(alert);
    });
    
    // تحديث العداد
    const currentAlerts = parseInt($('#active-alerts').text()) || 0;
    $('#active-alerts').text(currentAlerts + alerts.length);
    
    // تأثير اهتزاز لزر التنبيهات
    $('#alerts-tab').addClass('shake');
    setTimeout(() => $('#alerts-tab').removeClass('shake'), 500);
}

// عرض إشعار Toast
function showToastNotification(alert) {
    const toastId = 'toast-' + Date.now();
    const severityIcon = getSeverityIcon(alert.severity);
    const severityClass = getSeverityClass(alert.severity);
    
    const toastHTML = `
        <div id="${toastId}" class="toast position-fixed top-0 end-0 m-3" role="alert" style="z-index: 1060;">
            <div class="toast-header bg-${severityClass} text-white">
                <i class="fas fa-${severityIcon} me-2"></i>
                <strong class="me-auto">تنبيه جديد</strong>
                <small>${moment(alert.timestamp).fromNow()}</small>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                <h6>${alert.device_name}</h6>
                <p class="mb-1">${alert.message || alert.type}</p>
                <small class="text-muted">الفرع: ${alert.branch || 'غير معروف'}</small>
            </div>
        </div>
    `;
    
    // إضافة Toast إلى الصفحة
    $('body').append(toastHTML);
    
    // عرض Toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        delay: 5000,
        autohide: true
    });
    toast.show();
    
    // إزالة Toast بعد الاختفاء
    toastElement.addEventListener('hidden.bs.toast', function () {
        $(this).remove();
    });
}

// إضافة زر الإيقاف المؤقت
function addPauseButton() {
    const pauseButton = `
        <button id="pause-updates" class="btn btn-sm btn-outline-secondary ms-2" 
                onclick="toggleUpdatesPause()">
            <i class="fas fa-pause"></i>
        </button>
    `;
    
    $('.navbar-nav').append(`
        <li class="nav-item">
            <div class="d-flex align-items-center ms-2">
                ${pauseButton}
            </div>
        </li>
    `);
}

// تبديل الإيقاف المؤقت
function toggleUpdatesPause() {
    isPaused = !isPaused;
    const button = $('#pause-updates');
    
    if (isPaused) {
        button.html('<i class="fas fa-play"></i>');
        button.removeClass('btn-outline-secondary').addClass('btn-outline-warning');
        showToastNotification({
            device_name: 'النظام',
            type: 'SYSTEM',
            severity: 'info',
            message: 'تم إيقاف التحديثات الفورية مؤقتاً'
        });
    } else {
        button.html('<i class="fas fa-pause"></i>');
        button.removeClass('btn-outline-warning').addClass('btn-outline-secondary');
        fetchRealtimeData(); // تحديث فوري عند الاستئناف
    }
}

// تهيئة WebSocket للتحديثات الفورية
function initializeWebSocket() {
    // التحقق من دعم WebSocket
    if (!('WebSocket' in window)) {
        console.log('WebSocket غير مدعوم في هذا المتصفح');
        return;
    }
    
    // محاولة الاتصال بـ WebSocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = protocol + '//' + window.location.host + '/ws';
    
    try {
        const socket = new WebSocket(wsUrl);
        
        socket.onopen = function() {
            console.log('✅ تم الاتصال بـ WebSocket');
        };
        
        socket.onmessage = function(event) {
            try {
                const data = JSON.parse(event.data);
                handleWebSocketMessage(data);
            } catch (e) {
                console.error('Error parsing WebSocket message:', e);
            }
        };
        
        socket.onclose = function() {
            console.log('❌ تم إغلاق اتصال WebSocket');
            // إعادة المحاولة بعد 5 ثواني
            setTimeout(initializeWebSocket, 5000);
        };
        
        socket.onerror = function(error) {
            console.error('WebSocket error:', error);
        };
        
    } catch (error) {
        console.log('لا يمكن الاتصال بـ WebSocket، سيتم استخدام AJAX فقط');
    }
}

// معالجة رسائل WebSocket
function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'NEW_ALERT':
            showNewAlertsNotification([data.alert]);
            break;
            
        case 'DEVICE_UPDATE':
            updateDeviceStatus(data.device);
            break;
            
        case 'METRICS_UPDATE':
            updateRealtimeData(data.metrics);
            break;
            
        case 'SYSTEM_MESSAGE':
            showSystemMessage(data.message, data.level);
            break;
    }
}

// تحديث حالة الجهاز
function updateDeviceStatus(device) {
    // تحديث الجدول إذا كان الجهاز موجوداً
    const row = $(`#device-${device.id}`);
    if (row.length) {
        const statusBadge = getDeviceStatusBadge(device.status);
        const cpuProgress = getCpuProgressBar(device.cpu_percent);
        
        row.find('.device-status').html(statusBadge);
        row.find('.device-cpu').html(cpuProgress);
    }
}

// توليد badge الحالة
function getDeviceStatusBadge(status) {
    const statusClass = getDeviceStatusClass(status);
    const statusIcon = getDeviceStatusIcon(status);
    
    return `
        <span class="badge bg-${statusClass}">
            <i class="fas fa-${statusIcon} me-1"></i>
            ${status}
        </span>
    `;
}

// توليد شريط التقدم للـ CPU
function getCpuProgressBar(cpu) {
    const cpuColor = getCpuColor(cpu);
    
    return `
        <div class="progress" style="height: 6px;">
            <div class="progress-bar bg-${cpuColor}" 
                 role="progressbar" 
                 style="width: ${cpu}%">
            </div>
        </div>
        <small class="text-muted">${cpu}%</small>
    `;
}

// عرض رسالة النظام
function showSystemMessage(message, level = 'info') {
    const alertClass = {
        'info': 'alert-info',
        'success': 'alert-success',
        'warning': 'alert-warning',
        'error': 'alert-danger'
    }[level] || 'alert-info';
    
    const alertHTML = `
        <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
            <i class="fas fa-info-circle me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // إضافة الرسالة أعلى المحتوى
    $('#page-content').prepend(alertHTML);
    
    // إزالة الرسالة بعد 10 ثواني
    setTimeout(() => {
        $('.alert').alert('close');
    }, 10000);
}

// تنسيق CSS للإشعارات
const style = document.createElement('style');
style.textContent = `
    .shake {
        animation: shake 0.5s;
    }
    
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
        20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
    
    .toast {
        min-width: 300px;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    @media (max-width: 576px) {
        .toast {
            min-width: 90%;
            left: 5%;
            right: 5%;
        }
    }
`;
document.head.appendChild(style);

// التهيئة عند تحميل الصفحة
$(document).ready(function() {
    // بدء التحديثات الفورية
    startRealtimeUpdates();
    
    // إضافة مستمعين للأحداث
    $(document).on('visibilitychange', function() {
        if (document.hidden) {
            // إيقاف المؤقت عندما تكون الصفحة غير مرئية
            if (realtimeUpdateInterval) {
                clearInterval(realtimeUpdateInterval);
            }
        } else {
            // استئناف المؤقت عند عودة الرؤية
            if (!isPaused) {
                realtimeUpdateInterval = setInterval(fetchRealtimeData, 30000);
                fetchRealtimeData(); // تحديث فوري
            }
        }
    });
});