<?php
session_start();
require_once '../config/db.php';
require_once '../includes/auth_check.php';

// التحقق من صلاحيات المدير
if ($_SESSION['user_role'] !== 'admin') {
    header('Location: unauthorized.php');
    exit();
}

// البحث والتصفية
$search = isset($_GET['search']) ? $_GET['search'] : '';
$role = isset($_GET['role']) ? $_GET['role'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';

// بناء استعلام SQL
$sql = "SELECT * FROM users WHERE 1=1";
$params = [];

if ($search) {
    $sql .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($role) {
    $sql .= " AND role = ?";
    $params[] = $role;
}

if ($status !== '') {
    $sql .= " AND is_active = ?";
    $params[] = $status;
}

$sql .= " ORDER BY created_at DESC";

// التنفيذ
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// معالجة الحذف
if (isset($_GET['delete'])) {
    $user_id = $_GET['delete'];
    
    // عدم السماح بحذف المستخدم الحالي
    if ($user_id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        
        $_SESSION['success'] = "تم حذف المستخدم بنجاح";
        header('Location: users.php');
        exit();
    }
}

// معالجة تغيير الحالة
if (isset($_GET['toggle_status'])) {
    $user_id = $_GET['toggle_status'];
    
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    $new_status = $user['is_active'] ? 0 : 1;
    
    $stmt = $pdo->prepare("UPDATE users SET is_active = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$new_status, $user_id]);
    
    $_SESSION['success'] = "تم تغيير حالة المستخدم بنجاح";
    header('Location: users.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - النظام الإداري</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/users.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="page-header">
            <div>
                <h1><i class="fas fa-users-cog"></i> إدارة المستخدمين</h1>
                <p>إدارة حسابات المستخدمين في النظام</p>
            </div>
            <div class="header-actions">
                <a href="add_user.php" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> إضافة مستخدم
                </a>
                <a href="export_users.php" class="btn btn-secondary">
                    <i class="fas fa-file-export"></i> تصدير
                </a>
            </div>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <!-- فلتر البحث -->
        <div class="filter-card">
            <form method="GET" class="filter-form">
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" name="search" placeholder="بحث بالاسم أو البريد أو الهاتف..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="form-group">
                        <select name="role">
                            <option value="">جميع الصلاحيات</option>
                            <option value="admin" <?php echo $role == 'admin' ? 'selected' : ''; ?>>مدير</option>
                            <option value="editor" <?php echo $role == 'editor' ? 'selected' : ''; ?>>محرر</option>
                            <option value="viewer" <?php echo $role == 'viewer' ? 'selected' : ''; ?>>مشاهد</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <select name="status">
                            <option value="">جميع الحالات</option>
                            <option value="1" <?php echo $status === '1' ? 'selected' : ''; ?>>نشط</option>
                            <option value="0" <?php echo $status === '0' ? 'selected' : ''; ?>>غير نشط</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> بحث
                    </button>
                    
                    <?php if ($search || $role || $status !== ''): ?>
                        <a href="users.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> إلغاء
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- جدول المستخدمين -->
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="usersTable" class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>المستخدم</th>
                                <th>البريد الإلكتروني</th>
                                <th>الهاتف</th>
                                <th>الصلاحية</th>
                                <th>الحالة</th>
                                <th>آخر دخول</th>
                                <th>التسجيل</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td>
                                    <div class="user-info">
                                        <div class="user-avatar">
                                            <?php
                                            $avatar = !empty($user['avatar']) ? '../uploads/avatars/' . $user['avatar'] : '../assets/images/default-avatar.png';
                                            ?>
                                            <img src="<?php echo $avatar; ?>" alt="<?php echo htmlspecialchars($user['name']); ?>">
                                        </div>
                                        <div class="user-details">
                                            <h4><?php echo htmlspecialchars($user['name']); ?></h4>
                                            <small>ID: <?php echo $user['username'] ?? 'N/A'; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo $user['phone'] ?? 'غير محدد'; ?></td>
                                <td>
                                    <span class="badge badge-role-<?php echo $user['role']; ?>">
                                        <?php
                                        $role_names = [
                                            'admin' => 'مدير',
                                            'editor' => 'محرر',
                                            'viewer' => 'مشاهد'
                                        ];
                                        echo $role_names[$user['role']] ?? $user['role'];
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="status status-<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                        <?php echo $user['is_active'] ? 'نشط' : 'غير نشط'; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo $user['last_login'] ? date('Y/m/d H:i', strtotime($user['last_login'])) : 'لم يدخل بعد'; ?>
                                </td>
                                <td><?php echo date('Y/m/d', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="view_user.php?id=<?php echo $user['id']; ?>" 
                                           class="btn-icon btn-view" title="عرض">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="edit_user.php?id=<?php echo $user['id']; ?>" 
                                           class="btn-icon btn-edit" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                            <a href="users.php?toggle_status=<?php echo $user['id']; ?>" 
                                               class="btn-icon btn-toggle" 
                                               title="<?php echo $user['is_active'] ? 'تعطيل' : 'تفعيل'; ?>"
                                               onclick="return confirm('هل تريد <?php echo $user['is_active'] ? 'تعطيل' : 'تفعيل'; ?> هذا المستخدم؟')">
                                                <i class="fas fa-power-off"></i>
                                            </a>
                                            
                                            <a href="users.php?delete=<?php echo $user['id']; ?>" 
                                               class="btn-icon btn-delete" title="حذف"
                                               onclick="return confirm('هل أنت متأكد من حذف هذا المستخدم؟ لا يمكن التراجع عن هذا الإجراء.')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        <?php else: ?>
                                            <span class="btn-icon disabled" title="لا يمكن تعديل حسابك">
                                                <i class="fas fa-ban"></i>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- إحصائيات -->
        <div class="stats-cards">
            <?php
            $total_users = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
            $active_users = $pdo->query("SELECT COUNT(*) as count FROM users WHERE is_active = 1")->fetch()['count'];
            $admins = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")->fetch()['count'];
            $today_logins = $pdo->query("SELECT COUNT(*) as count FROM users WHERE DATE(last_login) = CURDATE()")->fetch()['count'];
            ?>
            
            <div class="stat-card mini">
                <i class="fas fa-users"></i>
                <div>
                    <h3><?php echo $total_users; ?></h3>
                    <p>إجمالي المستخدمين</p>
                </div>
            </div>
            
            <div class="stat-card mini">
                <i class="fas fa-user-check"></i>
                <div>
                    <h3><?php echo $active_users; ?></h3>
                    <p>مستخدمين نشطين</p>
                </div>
            </div>
            
            <div class="stat-card mini">
                <i class="fas fa-user-shield"></i>
                <div>
                    <h3><?php echo $admins; ?></h3>
                    <p>مديرين</p>
                </div>
            </div>
            
            <div class="stat-card mini">
                <i class="fas fa-sign-in-alt"></i>
                <div>
                    <h3><?php echo $today_logins; ?></h3>
                    <p>دخول اليوم</p>
                </div>
            </div>
        </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="../assets/js/users.js"></script>
    <script>
        $(document).ready(function() {
            $('#usersTable').DataTable({
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/ar.json'
                },
                order: [[0, 'desc']],
                pageLength: 25,
                responsive: true
            });
            
            // تأكيد الحذف
            $('.btn-delete').on('click', function(e) {
                if (!confirm('هل أنت متأكد من حذف هذا المستخدم؟ هذا الإجراء لا يمكن التراجع عنه.')) {
                    e.preventDefault();
                }
            });
            
            // نسخ البريد الإلكتروني
            $('.user-email').on('click', function() {
                const email = $(this).text();
                navigator.clipboard.writeText(email).then(() => {
                    $(this).addClass('copied');
                    setTimeout(() => $(this).removeClass('copied'), 2000);
                });
            });
        });
    </script>
</body>
</html>