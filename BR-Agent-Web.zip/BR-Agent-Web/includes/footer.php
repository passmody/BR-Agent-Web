<?php
// includes/footer.php - تذييل الصفحة
?>
<footer class="footer mt-5 py-3 bg-dark text-light">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6">
                <span class="text-muted">
                    <i class="fas fa-copyright me-1"></i> 
                    <?php echo date('Y'); ?> BR-Agent System. جميع الحقوق محفوظة.
                </span>
            </div>
            <div class="col-md-6 text-md-end">
                <span class="text-muted">
                    <i class="fas fa-server me-1"></i> 
                    آخر تحديث: <span id="last-update"><?php echo date('H:i:s'); ?></span>
                    <span class="ms-3">
                        <i class="fas fa-database me-1"></i>
                        <span id="data-count">0</span> جهاز نشط
                    </span>
                </span>
            </div>
        </div>
    </div>
</footer>

<!-- JavaScript Libraries -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<!-- مكتبات إضافية -->
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/min/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/locale/ar.js"></script>

<!-- ملفات JavaScript المخصصة -->
<script src="assets/js/main.js"></script>
<script src="assets/js/charts.js"></script>
<script src="assets/js/realtime.js"></script>

<!-- تهيئة -->
<script>
    // تعيين اللغة العربية
    moment.locale('ar');
    toastr.options = {
        "positionClass": "toast-top-left",
        "rtl": true,
        "timeOut": 5000
    };
    
    // تحميل البيانات عند بدء التشغيل
    $(document).ready(function() {
        loadDashboardData();
        startRealtimeUpdates();
    });
</script>
</body>
</html>