<?php
session_start();
require_once '../config/db.php';
require_once '../includes/auth_check.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // تحديث إعدادات المستخدم
    $user_id = $_SESSION['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $theme = $_POST['theme'];
    $notifications = isset($_POST['notifications']) ? 1 : 0;
    
    $stmt = $pdo->prepare("
        UPDATE users 
        SET name = ?, email = ?, theme = ?, notifications_enabled = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([$name, $email, $theme, $notifications, $user_id]);
    
    // تحديث البيانات في الجلسة
    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;
    
    $success = "تم تحديث الإعدادات بنجاح!";
}

// جلب بيانات المستخدم الحالية
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإعدادات</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/settings.css">
</head>
<body class="theme-<?php echo $user['theme'] ?? 'light'; ?>">
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="page-header">
            <h1><i class="icon-settings"></i> الإعدادات</h1>
        </div>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="settings-container">
            <div class="settings-tabs">
                <button class="tab-btn active" data-tab="profile">الملف الشخصي</button>
                <button class="tab-btn" data-tab="security">الأمان</button>
                <button class="tab-btn" data-tab="preferences">التفضيلات</button>
                <button class="tab-btn" data-tab="notifications">الإشعارات</button>
            </div>

            <div class="settings-content">
                <!-- علامة التبويب: الملف الشخصي -->
                <div class="tab-pane active" id="profile">
                    <form method="POST" class="settings-form">
                        <div class="form-group">
                            <label for="name">الاسم الكامل</label>
                            <input type="text" id="name" name="name" 
                                value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">البريد الإلكتروني</label>
                            <input type="email" id="email" name="email" 
                                value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">رقم الهاتف</label>
                            <input type="tel" id="phone" name="phone" 
                                value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="avatar">صورة الملف الشخصي</label>
                            <input type="file" id="avatar" name="avatar" accept="image/*">
                            <small>الحد الأقصى 2MB - صيغ مقبولة: JPG, PNG, GIF</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                    </form>
                </div>

                <!-- علامة التبويب: الأمان -->
                <div class="tab-pane" id="security">
                    <form method="POST" action="change_password.php" class="settings-form">
                        <div class="form-group">
                            <label for="current_password">كلمة المرور الحالية</label>
                            <input type="password" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">كلمة المرور الجديدة</label>
                            <input type="password" id="new_password" name="new_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">تأكيد كلمة المرور</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">تغيير كلمة المرور</button>
                    </form>
                    
                    <div class="security-section">
                        <h3>جلسات الدخول النشطة</h3>
                        <table class="sessions-table">
                            <thead>
                                <tr>
                                    <th>الجهاز</th>
                                    <th>المتصفح</th>
                                    <th>آخر نشاط</th>
                                    <th>إجراء</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- جلب جلسات المستخدم من قاعدة البيانات -->
                                <tr>
                                    <td>Windows - Chrome</td>
                                    <td>Chrome 120.0</td>
                                    <td>قبل 5 دقائق</td>
                                    <td><button class="btn btn-sm btn-danger">إنهاء الجلسة</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- علامة التبويب: التفضيلات -->
                <div class="tab-pane" id="preferences">
                    <form method="POST" class="settings-form">
                        <div class="form-group">
                            <label for="theme">المظهر</label>
                            <select id="theme" name="theme">
                                <option value="light" <?php echo ($user['theme'] ?? 'light') == 'light' ? 'selected' : ''; ?>>
                                    فاتح
                                </option>
                                <option value="dark" <?php echo ($user['theme'] ?? 'light') == 'dark' ? 'selected' : ''; ?>>
                                    داكن
                                </option>
                                <option value="auto" <?php echo ($user['theme'] ?? 'light') == 'auto' ? 'selected' : ''; ?>>
                                    تلقائي
                                </option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="language">اللغة</label>
                            <select id="language" name="language">
                                <option value="ar">العربية</option>
                                <option value="en">الإنجليزية</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="timezone">المنطقة الزمنية</label>
                            <select id="timezone" name="timezone">
                                <option value="Asia/Riyadh" selected>الرياض (UTC+3)</option>
                                <option value="UTC">توقيت عالمي</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="email_notifications" value="1" 
                                    <?php echo ($user['email_notifications'] ?? 1) ? 'checked' : ''; ?>>
                                تفعيل الإشعارات البريدية
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">حفظ التفضيلات</button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/js/settings.js"></script>
</body>
</html>