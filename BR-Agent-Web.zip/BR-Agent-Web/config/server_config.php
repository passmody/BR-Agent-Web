<?php
// config/server_config.php

// منع الوصول المباشر
defined('ROOT_PATH') or die('No direct script access allowed');

class ServerConfig {
    // 1. معلومات السيرفر
    public static $server = [
        'name' => 'نظام مراقبة الأجهزة',
        'version' => '1.0.0',
        'environment' => 'production', // development, testing, production
        'maintenance' => false,
        'maintenance_message' => 'النظام قيد الصيانة. الرجاء المحاولة لاحقاً.'
    ];
    
    // 2. إعدادات API
    public static $api = [
        'base_url' => 'http://your-domain.com/api',
        'version' => 'v1',
        'rate_limit' => [
            'enabled' => true,
            'requests_per_minute' => 60,
            'requests_per_hour' => 1000
        ],
        'cors' => [
            'enabled' => true,
            'allowed_origins' => ['http://your-domain.com', 'http://localhost'],
            'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
            'allowed_headers' => ['Content-Type', 'Authorization', 'X-API-Key']
        ]
    ];
    
    // 3. إعدادات الاتصال بالـAgent
    public static $agent = [
        'protocol' => 'https', // http أو https
        'port' => 443,
        'timeout' => 30,
        'retry_attempts' => 3,
        'data_encryption' => true,
        'compression' => true
    ];
    
    // 4. إعدادات RustDesk
    public static $rustdesk = [
        'enabled' => true,
        'relay_server' => 'rs-relay.rustdesk.com',
        'api_server' => 'rs-api.rustdesk.com',
        'key_path' => '../rustdesk_keys/',
        'auto_setup' => true
    ];
    
    // 5. إعدادات التنبيهات
    public static $alerts = [
        'email' => [
            'enabled' => true,
            'high_priority_recipients' => ['admin@company.com', 'manager@company.com'],
            'low_priority_recipients' => ['it@company.com']
        ],
        'sms' => [
            'enabled' => false,
            'provider' => 'twilio', // أو أي مزود آخر
            'api_key' => '',
            'emergency_numbers' => ['+966501234567']
        ],
        'telegram' => [
            'enabled' => false,
            'bot_token' => '',
            'chat_id' => ''
        ]
    ];
    
    // 6. إعدادات التقارير
    public static $reports = [
        'daily' => [
            'enabled' => true,
            'schedule' => '00:00',
            'recipients' => ['admin@company.com']
        ],
        'weekly' => [
            'enabled' => true,
            'day' => 'sunday', // الأحد
            'time' => '08:00',
            'recipients' => ['management@company.com']
        ],
        'monthly' => [
            'enabled' => true,
            'day' => 1, // أول الشهر
            'time' => '09:00',
            'recipients' => ['ceo@company.com']
        ]
    ];
}
?>