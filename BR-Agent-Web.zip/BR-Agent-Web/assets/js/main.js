// assets/js/main.js - الملف الرئيسي للـ JavaScript

// متغيرات عامة
let dashboardData = null;
let lastUpdateTime = null;
let updateInterval = null;

// دالة تحميل بيانات الداشبورد
function loadDashboardData() {
    showLoading();
    
    $.ajax({
        url: 'api/get_dashboard_data.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                dashboardData = response.data;
                lastUpdateTime = response.timestamp;
                
                updateAllUI();
                hideLoading();
                
                // تحديث بيانات الشريط الجانبي
                updateSidebar();
                
                toastr.success('تم تحديث البيانات بنجاح', 'تم', {timeOut: 2000});
            } else {
                toastr.error(response.message, 'خطأ في تحميل البيانات');
                hideLoading();
            }
        },
        error: function(xhr, status, error) {
            toastr.error('فشل الاتصال بالخادم', 'خطأ');
            hideLoading();
        }
    });
}

// تحديث جميع واجهة المستخدم
function updateAllUI() {
    if (!dashboardData) return;
    
    // تحديث المقاييس الرئيسية
    updateMainMetrics();
    
    // تحديث الجداول
    updateTables();
    
    // تحديث المخططات
    updateCharts(dashboardData.charts);
    
    // تحديث وقت آخر تحديث
    updateLastUpdateTime();
}

// تحديث المقاييس الرئيسية
function updateMainMetrics() {
    const metrics = dashboardData.metrics;
    
    // بطاقة الفروع
    $('#total-branches').text(metrics.total_branches);
    
    // بطاقة الأجهزة
    $('#active-devices').text(metrics.active_devices);
    $('#total-devices').text(metrics.total_devices);
    
    // بطاقة CPU
    $('#avg-cpu').text(metrics.avg_cpu + '%');
    
    // بطاقة التنبيهات
    $('#active-alerts').text(metrics.active_alerts);
    
    // تحديث المؤشرات في الشريط العلوي
    $('#data-count').text(metrics.active_devices);
}

// تحديث الجداول
function updateTables() {
    // جدول التنبيهات الأخيرة
    updateAlertsTable();
    
    // جدول الأجهزة الأخيرة
    updateDevicesTable();
}

// تحديث جدول التنبيهات
function updateAlertsTable() {
    const alerts = dashboardData.recent_alerts;
    const tbody = $('#recent-alerts');
    
    tbody.empty();
    
    if (alerts.length === 0) {
        tbody.append(`
            <tr>
                <td colspan="4" class="text-center py-4">
                    <div class="text-muted">
                        <i class="fas fa-check-circle fa-2x mb-2 text-success"></i>
                        <p class="mb-0">لا توجد تنبيهات نشطة</p>
                    </div>
                </td>
            </tr>
        `);
        return;
    }
    
    alerts.forEach(alert => {
        const severityClass = getSeverityClass(alert.severity);
        const severityIcon = getSeverityIcon(alert.severity);
        
        tbody.append(`
            <tr>
                <td>
                    <span class="badge bg-${severityClass}">
                        <i class="fas fa-${severityIcon} me-1"></i>
                        ${alert.severity}
                    </span>
                </td>
                <td>${alert.device_name || 'غير معروف'}</td>
                <td>${alert.type || 'غير معروف'}</td>
                <td>
                    <small class="text-muted">${alert.time_ago || alert.timestamp}</small>
                </td>
            </tr>
        `);
    });
}

// تحديث جدول الأجهزة
function updateDevicesTable() {
    const devices = dashboardData.recent_devices;
    const tbody = $('#recent-devices');
    
    tbody.empty();
    
    if (devices.length === 0) {
        tbody.append(`
            <tr>
                <td colspan="4" class="text-center py-4">
                    <div class="text-muted">
                        <i class="fas fa-exclamation-circle fa-2x mb-2 text-warning"></i>
                        <p class="mb-0">لا توجد أجهزة نشطة</p>
                    </div>
                </td>
            </tr>
        `);
        return;
    }
    
    devices.forEach(device => {
        const statusClass = getDeviceStatusClass(device.status);
        const statusIcon = getDeviceStatusIcon(device.status);
        const cpuColor = getCpuColor(device.cpu_percent || 0);
        
        tbody.append(`
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <i class="fas fa-desktop text-primary me-2"></i>
                        <div>
                            <div class="fw-bold">${device.device_name || 'غير معروف'}</div>
                            <small class="text-muted">${device.branch_id || 'غير معروف'}</small>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="badge bg-${statusClass}">
                        <i class="fas fa-${statusIcon} me-1"></i>
                        ${device.status || 'غير معروف'}
                    </span>
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="progress flex-grow-1 me-2" style="height: 6px;">
                            <div class="progress-bar bg-${cpuColor}" 
                                 style="width: ${device.cpu_percent || 0}%">
                            </div>
                        </div>
                        <small>${device.cpu_percent || 0}%</small>
                    </div>
                </td>
                <td>
                    <small class="text-muted">${device.last_update_formatted || 'غير معروف'}</small>
                </td>
            </tr>
        `);
    });
}

// تحديث الشريط الجانبي
function updateSidebar() {
    const metrics = dashboardData.metrics;
    
    $('#sidebar-branches').text(metrics.total_branches);
    $('#sidebar-devices').text(metrics.total_devices);
    $('#sidebar-online').text(metrics.active_devices);
    $('#sidebar-alerts').text(metrics.active_alerts);
    $('#sidebar-update').text(moment().format('HH:mm'));
}

// تحديث وقت آخر تحديث
function updateLastUpdateTime() {
    if (lastUpdateTime) {
        $('#last-update').text(moment(lastUpdateTime).format('HH:mm:ss'));
    } else {
        $('#last-update').text(moment().format('HH:mm:ss'));
    }
}

// دالات المساعدة
function getSeverityClass(severity) {
    switch((severity || '').toLowerCase()) {
        case 'critical': return 'danger';
        case 'warning': return 'warning';
        case 'info': return 'info';
        default: return 'secondary';
    }
}

function getSeverityIcon(severity) {
    switch((severity || '').toLowerCase()) {
        case 'critical': return 'exclamation-triangle';
        case 'warning': return 'exclamation-circle';
        case 'info': return 'info-circle';
        default: return 'question-circle';
    }
}

function getDeviceStatusClass(status) {
    if (!status) return 'secondary';
    
    if (status.includes('سليم')) return 'success';
    if (status.includes('تحذير')) return 'warning';
    if (status.includes('حرج')) return 'danger';
    if (status.includes('غير متصل')) return 'secondary';
    return 'secondary';
}

function getDeviceStatusIcon(status) {
    if (!status) return 'question-circle';
    
    if (status.includes('سليم')) return 'check-circle';
    if (status.includes('تحذير')) return 'exclamation-triangle';
    if (status.includes('حرج')) return 'times-circle';
    if (status.includes('غير متصل')) return 'wifi-slash';
    return 'question-circle';
}

function getCpuColor(cpu) {
    if (cpu > 80) return 'danger';
    if (cpu > 60) return 'warning';
    return 'success';
}

// دالات التحميل
function showLoading() {
    $('.loading-spinner').removeClass('d-none');
    $('.btn-refresh').prop('disabled', true);
}

function hideLoading() {
    $('.loading-spinner').addClass('d-none');
    $('.btn-refresh').prop('disabled', false);
}

// تحديث البيانات يدوياً
function refreshData() {
    loadDashboardData();
}

// تصدير تقرير
function exportReport() {
    toastr.info('جاري إنشاء التقرير...', 'تصدير');
    
    setTimeout(() => {
        // هذا مثال بسيط - في الواقع سيتم استدعاء API لإنشاء التقرير
        const dataStr = JSON.stringify(dashboardData, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = `BR-Agent-Report-${moment().format('YYYY-MM-DD-HHmm')}.json`;
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        
        toastr.success('تم تصدير التقرير بنجاح', 'تم');
    }, 1000);
}

// البحث في الجداول
function searchTable(tableId, searchTerm) {
    const table = $('#' + tableId);
    const rows = table.find('tbody tr');
    
    rows.hide();
    
    rows.filter(function() {
        return $(this).text().toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    }).show();
}

// فلترة الجداول
function filterTable(tableId, columnIndex, filterValue) {
    const table = $('#' + tableId);
    const rows = table.find('tbody tr');
    
    if (!filterValue || filterValue === 'الكل') {
        rows.show();
        return;
    }
    
    rows.hide();
    
    rows.filter(function() {
        const cellValue = $(this).find('td').eq(columnIndex).text();
        return cellValue === filterValue;
    }).show();
}

// تهيئة عند تحميل الصفحة
$(document).ready(function() {
    // بدء التحديث التلقائي (كل 30 ثانية)
    updateInterval = setInterval(loadDashboardData, 30000);
    
    // إضافة مستمعين للأحداث
    $(document).on('click', '.btn-refresh', refreshData);
    $(document).on('click', '.btn-export', exportReport);
    
    // بحث تفاعلي
    $('.search-input').on('keyup', function() {
        const tableId = $(this).data('table');
        const searchTerm = $(this).val();
        searchTable(tableId, searchTerm);
    });
    
    // فلتر تفاعلي
    $('.filter-select').on('change', function() {
        const tableId = $(this).data('table');
        const columnIndex = $(this).data('column');
        const filterValue = $(this).val();
        filterTable(tableId, columnIndex, filterValue);
    });
});