/**
 * لوحة التحكم - JavaScript
 */

class Dashboard {
    constructor() {
        this.init();
    }
    
    init() {
        this.initCharts();
        this.initQuickActions();
        this.initNotifications();
        this.initAutoRefresh();
    }
    
    initCharts() {
        // الرسوم البيانية تمت تهيئتها في الصفحة
        console.log('تم تهيئة الرسوم البيانية');
    }
    
    initQuickActions() {
        // زر التحديث
        const refreshBtn = document.getElementById('refreshDashboard');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshDashboard());
        }
        
        // الإجراءات السريعة
        document.querySelectorAll('.quick-action').forEach(action => {
            action.addEventListener('click', function(e) {
                if (this.getAttribute('href') === '#') {
                    e.preventDefault();
                    alert('هذه الميزة قيد التطوير');
                }
            });
        });
    }
    
    initNotifications() {
        // تحديث عداد التنبيهات
        this.updateNotificationCount();
        
        // تحديث تلقائي كل 30 ثانية
        setInterval(() => this.updateNotificationCount(), 30000);
    }
    
    async updateNotificationCount() {
        try {
            const response = await fetch('api/get_notifications_count.php');
            const data = await response.json();
            
            if (data.success) {
                const badge = document.querySelector('.notification-badge');
                if (badge) {
                    badge.textContent = data.count;
                    
                    if (data.count > 0) {
                        badge.style.display = 'flex';
                        
                        // تأثير التنبيه
                        if (data.count > parseInt(badge.textContent)) {
                            this.pulseNotification();
                        }
                    } else {
                        badge.style.display = 'none';
                    }
                }
            }
        } catch (error) {
            console.error('Error updating notifications:', error);
        }
    }
    
    pulseNotification() {
        const bell = document.querySelector('.notification-bell');
        if (bell) {
            bell.classList.add('pulse');
            setTimeout(() => bell.classList.remove('pulse'), 1000);
        }
    }
    
    async refreshDashboard() {
        const refreshBtn = document.getElementById('refreshDashboard');
        const originalHtml = refreshBtn.innerHTML;
        
        // إظهار التحميل
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        refreshBtn.disabled = true;
        
        try {
            // تحديث البيانات
            await Promise.all([
                this.updateStats(),
                this.updateRecentAlerts(),
                this.updateRecentReports()
            ]);
            
            // إظهار رسالة نجاح
            this.showToast('تم تحديث البيانات بنجاح', 'success');
            
        } catch (error) {
            console.error('Error refreshing dashboard:', error);
            this.showToast('حدث خطأ أثناء التحديث', 'error');
        } finally {
            // إعادة الزر لحالته الأصلية
            refreshBtn.innerHTML = originalHtml;
            refreshBtn.disabled = false;
        }
    }
    
    async updateStats() {
        // تحديث الإحصائيات
        const statsCards = document.querySelectorAll('.stat-card .value');
        if (statsCards.length > 0) {
            // محاكاة بيانات جديدة
            statsCards.forEach(card => {
                const currentValue = parseInt(card.textContent);
                const newValue = currentValue + Math.floor(Math.random() * 5);
                this.animateValue(card, currentValue, newValue, 1000);
            });
        }
    }
    
    async updateRecentAlerts() {
        // تحديث التنبيهات الأخيرة
        console.log('Updating recent alerts...');
    }
    
    async updateRecentReports() {
        // تحديث التقارير الأخيرة
        console.log('Updating recent reports...');
    }
    
    animateValue(element, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const value = Math.floor(progress * (end - start) + start);
            element.textContent = value.toLocaleString();
            
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }
    
    initAutoRefresh() {
        // تحديث تلقائي كل 5 دقائق
        setInterval(() => {
            if (document.visibilityState === 'visible') {
                this.refreshDashboard();
            }
        }, 5 * 60 * 1000);
    }
    
    showToast(message, type = 'info') {
        // إزالة أي رسائل سابقة
        const existingToasts = document.querySelectorAll('.toast');
        existingToasts.forEach(toast => toast.remove());
        
        // إنشاء الرسالة الجديدة
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
            <button class="toast-close">&times;</button>
        `;
        
        // إضافة الرسالة للصفحة
        document.body.appendChild(toast);
        
        // إضافة الأنماط
        if (!document.querySelector('#toast-styles')) {
            const style = document.createElement('style');
            style.id = 'toast-styles';
            style.textContent = `
                .toast {
                    position: fixed;
                    top: 20px;
                    left: 20px;
                    background: white;
                    padding: 15px 20px;
                    border-radius: 8px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    z-index: 9999;
                    animation: slideIn 0.3s ease;
                    border-right: 4px solid #4e73df;
                }
                
                .toast-success {
                    border-right-color: #28a745;
                }
                
                .toast-error {
                    border-right-color: #dc3545;
                }
                
                .toast-warning {
                    border-right-color: #ffc107;
                }
                
                .toast i {
                    font-size: 1.2rem;
                }
                
                .toast-success i {
                    color: #28a745;
                }
                
                .toast-error i {
                    color: #dc3545;
                }
                
                .toast-warning i {
                    color: #ffc107;
                }
                
                .toast-close {
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    cursor: pointer;
                    color: #666;
                    margin-right: auto;
                }
                
                @keyframes slideIn {
                    from {
                        transform: translateX(-100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        // إغلاق الرسالة
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        });
        
        // إغلاق الرسالة تلقائياً بعد 5 ثوانٍ
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            }
        }, 5000);
    }
}

// تهيئة لوحة التحكم عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new Dashboard();
});