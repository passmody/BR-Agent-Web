<?php
session_start();
require_once '../config/db.php';

// إذا كان المستخدم مسجل الدخول بالفعل، توجيهه للصفحة الرئيسية
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'البريد الإلكتروني غير صالح';
    } elseif (strlen($password) < 6) {
        $error = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    } else {
        // التحقق من وجود المستخدم
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            // تسجيل الدخول الناجح
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['login_time'] = time();
            
            // تحديث آخر وقت دخول
            $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")
                ->execute([$user['id']]);
            
            // توجيه للصفحة الرئيسية
            header('Location: dashboard.php');
            exit();
        } else {
            $error = 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
        }
    }
}

// عرض رسالة نجاح إذا كانت هناك عملية تسجيل خروج
if (isset($_GET['logout']) && $_GET['logout'] == 'success') {
    $success = 'تم تسجيل الخروج بنجاح';
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - النظام الإداري</title>
    <link rel="stylesheet" href="../assets/css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-chart-line"></i>
                    <h1>النظام الإداري</h1>
                </div>
                <p>مرحباً بعودتك! يرجى تسجيل الدخول لحسابك</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i> البريد الإلكتروني
                    </label>
                    <input type="email" id="email" name="email" 
                        value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                        placeholder="ادخل بريدك الإلكتروني" required>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> كلمة المرور
                    </label>
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" 
                            placeholder="ادخل كلمة المرور" required>
                        <button type="button" class="toggle-password">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        <span>تذكرني</span>
                    </label>
                    <a href="forgot_password.php" class="forgot-link">نسيت كلمة المرور؟</a>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> تسجيل الدخول
                </button>
                
                <div class="divider">
                    <span>أو</span>
                </div>
                
                <button type="button" class="btn-google">
                    <i class="fab fa-google"></i> تسجيل الدخول بحساب Google
                </button>
            </form>
            
            <div class="login-footer">
                <p>ليس لديك حساب؟ <a href="register.php">أنشئ حساب جديد</a></p>
                <p><a href="../index.php"><i class="fas fa-home"></i> العودة للرئيسية</a></p>
            </div>
        </div>
        
        <div class="login-side">
            <div class="features-list">
                <h2>مميزات النظام</h2>
                <ul>
                    <li><i class="fas fa-chart-bar"></i> لوحة تحكم تفاعلية</li>
                    <li><i class="fas fa-file-alt"></i> تقارير متقدمة</li>
                    <li><i class="fas fa-bell"></i> نظام تنبيهات ذكي</li>
                    <li><i class="fas fa-shield-alt"></i> حماية وأمان عالي</li>
                    <li><i class="fas fa-mobile-alt"></i> متوافق مع جميع الأجهزة</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/auth.js"></script>
</body>
</html>