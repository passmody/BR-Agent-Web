<?php
session_start();

// التحقق من تسجيل دخول المستخدم
function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../pages/login.php');
        exit();
    }
}

// التحقق من الصلاحيات
function checkPermission($requiredRole) {
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== $requiredRole) {
        header('Location: ../pages/unauthorized.php');
        exit();
    }
}

// التحقق من وقت الجلسة (30 دقيقة)
function checkSessionTimeout() {
    $timeout = 1800; // 30 دقيقة بالثواني
    
    if (isset($_SESSION['login_time'])) {
        $session_life = time() - $_SESSION['login_time'];
        
        if ($session_life > $timeout) {
            session_destroy();
            header('Location: ../pages/login.php?session=expired');
            exit();
        } else {
            // تجديد وقت الجلسة
            $_SESSION['login_time'] = time();
        }
    }
}

// استدعاء الدوال تلقائياً
checkAuth();
checkSessionTimeout();
?>