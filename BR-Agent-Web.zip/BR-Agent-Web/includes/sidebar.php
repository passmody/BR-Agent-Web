<?php
// includes/sidebar.php - القائمة الجانبية
$pages = [
    'dashboard' => ['النظرة العامة', 'tachometer-alt'],
    'branches' => ['الفروع', 'building'],
    'devices' => ['الأجهزة', 'desktop'],
    'alerts' => ['التنبيهات', 'bell'],
    'reports' => ['التقارير', 'chart-bar'],
    'settings' => ['الإعدادات', 'cog']
];

$current_page = $_GET['page'] ?? 'dashboard';
?>
<div class="sidebar">
    <div class="sidebar-header text-center mb-4">
        <div class="p-3">
            <i class="fas fa-chart-network fa-3x text-white mb-3"></i>
            <h4 class="text-white mb-1">BR-Agent</h4>
            <small class="text-white opacity-75">نظام مراقبة الفروع</small>
        </div>
    </div>
    
    <div class="sidebar-menu">
        <ul class="nav flex-column">
            <?php foreach ($pages as $key => $info): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === $key ? 'active' : ''; ?>" 
                   href="index.php?page=<?php echo $key; ?>">
                    <i class="fas fa-<?php echo $info[1]; ?> me-2"></i>
                    <?php echo $info[0]; ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
        
        <hr class="sidebar-divider my-4 opacity-25">
        
        <div class="px-3 py-2">
            <h6 class="text-white opacity-75 mb-3">
                <i class="fas fa-chart-line me-2"></i>إحصائيات سريعة
            </h6>
            
            <div class="row g-2">
                <div class="col-6">
                    <div class="bg-white bg-opacity-10 rounded p-2 text-center">
                        <small class="text-white opacity-75 d-block">الفروع</small>
                        <span class="text-white fw-bold" id="sidebar-branches">0</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="bg-white bg-opacity-10 rounded p-2 text-center">
                        <small class="text-white opacity-75 d-block">الأجهزة</small>
                        <span class="text-white fw-bold" id="sidebar-devices">0</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="bg-white bg-opacity-10 rounded p-2 text-center">
                        <small class="text-white opacity-75 d-block">متصل</small>
                        <span class="text-white fw-bold" id="sidebar-online">0</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="bg-white bg-opacity-10 rounded p-2 text-center">
                        <small class="text-white opacity-75 d-block">تنبيهات</small>
                        <span class="text-white fw-bold" id="sidebar-alerts">0</span>
                    </div>
                </div>
            </div>
        </div>
        
        <hr class="sidebar-divider my-4 opacity-25">
        
        <div class="px-3">
            <button class="btn btn-outline-light w-100 mb-2" onclick="refreshData()">
                <i class="fas fa-sync-alt me-2"></i>تحديث البيانات
            </button>
            
            <button class="btn btn-light w-100" onclick="exportReport()">
                <i class="fas fa-download me-2"></i>تصدير تقرير
            </button>
        </div>
    </div>
    
    <div class="sidebar-footer mt-auto p-3">
        <div class="text-center">
            <small class="text-white opacity-50">
                <i class="fas fa-clock me-1"></i>
                آخر تحديث: 
                <span id="sidebar-update"><?php echo date('H:i'); ?></span>
            </small>
        </div>
    </div>
</div>