/**
 * ملف معالجة النماذج
 * التحقق من الصحة، الإرسال، والمهام العامة للنماذج
 */

class FormHandler {
    constructor(formId) {
        this.form = document.getElementById(formId);
        this.fields = {};
        this.errors = [];
        this.init();
    }
    
    init() {
        if (!this.form) return;
        
        // جمع حقول النموذج
        this.collectFields();
        
        // إضافة مستمعات الأحداث
        this.addEventListeners();
    }
    
    collectFields() {
        const inputs = this.form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            const name = input.name || input.id;
            if (name) {
                this.fields[name] = {
                    element: input,
                    value: input.value,
                    type: input.type,
                    required: input.required,
                    rules: input.dataset.rules ? input.dataset.rules.split('|') : []
                };
            }
        });
    }
    
    addEventListeners() {
        // التحقق أثناء الكتابة
        Object.keys(this.fields).forEach(fieldName => {
            const field = this.fields[fieldName];
            
            field.element.addEventListener('blur', () => {
                this.validateField(fieldName);
            });
            
            field.element.addEventListener('input', () => {
                this.clearFieldError(fieldName);
            });
        });
        
        // التحقق عند الإرسال
        this.form.addEventListener('submit', (e) => {
            if (!this.validateForm()) {
                e.preventDefault();
                this.showErrors();
            }
        });
    }
    
    validateField(fieldName) {
        const field = this.fields[fieldName];
        if (!field) return true;
        
        const value = field.element.value.trim();
        field.value = value;
        
        let isValid = true;
        let errorMessage = '';
        
        // التحقق من الحقول المطلوبة
        if (field.required && !value) {
            isValid = false;
            errorMessage = 'هذا الحقل مطلوب';
        }
        
        // تطبيق القواعد المخصصة
        if (isValid && value && field.rules.length > 0) {
            field.rules.forEach(rule => {
                switch(rule) {
                    case 'email':
                        if (!this.isValidEmail(value)) {
                            isValid = false;
                            errorMessage = 'البريد الإلكتروني غير صالح';
                        }
                        break;
                        
                    case 'phone':
                        if (!this.isValidPhone(value)) {
                            isValid = false;
                            errorMessage = 'رقم الهاتف غير صالح';
                        }
                        break;
                        
                    case 'number':
                        if (isNaN(value)) {
                            isValid = false;
                            errorMessage = 'يجب أن يكون رقم';
                        }
                        break;
                        
                    case 'min:6':
                        if (value.length < 6) {
                            isValid = false;
                            errorMessage = 'يجب أن يكون 6 أحرف على الأقل';
                        }
                        break;
                        
                    case 'max:100':
                        if (value.length > 100) {
                            isValid = false;
                            errorMessage = 'يجب أن لا يتجاوز 100 حرف';
                        }
                        break;
                }
            });
        }
        
        if (!isValid) {
            this.showFieldError(fieldName, errorMessage);
        } else {
            this.clearFieldError(fieldName);
        }
        
        return isValid;
    }
    
    validateForm() {
        this.errors = [];
        
        Object.keys(this.fields).forEach(fieldName => {
            if (!this.validateField(fieldName)) {
                const field = this.fields[fieldName];
                this.errors.push({
                    field: fieldName,
                    message: field.element.parentElement.querySelector('.error-message')?.textContent || 'خطأ في الحقل'
                });
            }
        });
        
        return this.errors.length === 0;
    }
    
    showFieldError(fieldName, message) {
        const field = this.fields[fieldName];
        if (!field) return;
        
        const formGroup = field.element.closest('.form-group');
        let errorElement = formGroup.querySelector('.error-message');
        
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            formGroup.appendChild(errorElement);
        }
        
        errorElement.textContent = message;
        field.element.classList.add('error');
        
        // إضافة تأثير
        field.element.style.animation = 'shake 0.5s';
        setTimeout(() => {
            field.element.style.animation = '';
        }, 500);
    }
    
    clearFieldError(fieldName) {
        const field = this.fields[fieldName];
        if (!field) return;
        
        const formGroup = field.element.closest('.form-group');
        const errorElement = formGroup.querySelector('.error-message');
        
        if (errorElement) {
            errorElement.remove();
        }
        
        field.element.classList.remove('error');
    }
    
    showErrors() {
        // إظهار ملخص الأخطاء
        if (this.errors.length > 0) {
            let errorHTML = '<div class="form-errors-summary">';
            errorHTML += '<h4><i class="fas fa-exclamation-triangle"></i> يوجد أخطاء في النموذج:</h4>';
            errorHTML += '<ul>';
            
            this.errors.forEach(error => {
                errorHTML += `<li>${error.message}</li>`;
            });
            
            errorHTML += '</ul></div>';
            
            // إزالة الملخص السابق إن وجد
            const existingSummary = this.form.querySelector('.form-errors-summary');
            if (existingSummary) {
                existingSummary.remove();
            }
            
            // إضافة الملخص الجديد
            this.form.insertAdjacentHTML('afterbegin', errorHTML);
            
            // التمرير للأعلى
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }
    
    isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    
    isValidPhone(phone) {
        const regex = /^[\+]?[0-9]{10,15}$/;
        return regex.test(phone);
    }
    
    // وظائف مساعدة عامة
    static enableForm(formId) {
        const form = document.getElementById(formId);
        if (form) {
            const elements = form.elements;
            for (let i = 0; i < elements.length; i++) {
                elements[i].disabled = false;
            }
        }
    }
    
    static disableForm(formId) {
        const form = document.getElementById(formId);
        if (form) {
            const elements = form.elements;
            for (let i = 0; i < elements.length; i++) {
                elements[i].disabled = true;
            }
        }
    }
    
    static showLoading(formId, loadingText = 'جاري المعالجة...') {
        const form = document.getElementById(formId);
        if (!form) return;
        
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.dataset.originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${loadingText}`;
            submitBtn.disabled = true;
        }
        
        this.disableForm(formId);
    }
    
    static hideLoading(formId) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn && submitBtn.dataset.originalText) {
            submitBtn.innerHTML = submitBtn.dataset.originalText;
            submitBtn.disabled = false;
            delete submitBtn.dataset.originalText;
        }
        
        this.enableForm(formId);
    }
    
    static resetForm(formId) {
        const form = document.getElementById(formId);
        if (form) {
            form.reset();
            
            // مسح أخطاء التحقق
            const errorMessages = form.querySelectorAll('.error-message');
            errorMessages.forEach(error => error.remove());
            
            const errorInputs = form.querySelectorAll('.error');
            errorInputs.forEach(input => input.classList.remove('error'));
            
            const errorSummary = form.querySelector('.form-errors-summary');
            if (errorSummary) errorSummary.remove();
        }
    }
    
    static serializeForm(formId) {
        const form = document.getElementById(formId);
        if (!form) return {};
        
        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            if (data[key]) {
                if (Array.isArray(data[key])) {
                    data[key].push(value);
                } else {
                    data[key] = [data[key], value];
                }
            } else {
                data[key] = value;
            }
        }
        
        return data;
    }
}

// تهيئة كائنات معالج النماذج تلقائياً
document.addEventListener('DOMContentLoaded', function() {
    // البحث عن جميع النماذج وتهيئتها
    const forms = document.querySelectorAll('form[data-validate="true"]');
    
    forms.forEach(form => {
        const formId = form.id || `form_${Math.random().toString(36).substr(2, 9)}`;
        if (!form.id) form.id = formId;
        
        new FormHandler(formId);
    });
    
    // إضافة تأثير الاهتزاز للأخطاء
    const style = document.createElement('style');
    style.textContent = `
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        .error-message {
            color: #dc3545;
            font-size: 0.85rem;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .error-message::before {
            content: "⚠️";
        }
        
        .form-errors-summary {
            background-color: #fee;
            border: 1px solid #fcc;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .form-errors-summary h4 {
            color: #c00;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-errors-summary ul {
            margin: 0;
            padding-right: 20px;
        }
        
        .form-errors-summary li {
            margin-bottom: 5px;
            color: #900;
        }
        
        input.error,
        select.error,
        textarea.error {
            border-color: #dc3545 !important;
            background-color: #fff5f5 !important;
        }
    `;
    
    document.head.appendChild(style);
    
    // إضافة التحقق من الملفات
    const fileInputs = document.querySelectorAll('input[type="file"]');
    
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            const maxSize = parseInt(this.dataset.maxSize) || 2 * 1024 * 1024; // 2MB افتراضياً
            const allowedTypes = this.dataset.allowedTypes ? 
                this.dataset.allowedTypes.split(',') : 
                ['image/jpeg', 'image/png', 'image/gif'];
            
            Array.from(this.files).forEach(file => {
                if (file.size > maxSize) {
                    alert(`الملف ${file.name} أكبر من الحجم المسموح (${maxSize / 1024 / 1024}MB)`);
                    this.value = '';
                }
                
                if (!allowedTypes.includes(file.type)) {
                    alert(`نوع الملف ${file.name} غير مسموح. الأنواع المسموحة: ${allowedTypes.join(', ')}`);
                    this.value = '';
                }
            });
        });
    });
});

// تصدير الكلاس للاستخدام في ملفات أخرى
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FormHandler;
}