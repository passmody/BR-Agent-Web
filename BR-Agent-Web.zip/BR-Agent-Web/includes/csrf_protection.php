<?php
// includes/csrf_protection.php

class CSRFProtection {
    private static $token_name = 'csrf_token';
    
    public static function generateToken() {
        if (!isset($_SESSION[self::$token_name])) {
            $_SESSION[self::$token_name] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::$token_name];
    }
    
    public static function validateToken($token) {
        if (!isset($_SESSION[self::$token_name]) || !hash_equals($_SESSION[self::$token_name], $token)) {
            throw new Exception('CSRF token validation failed');
        }
        return true;
    }
    
    public static function getTokenField() {
        return '<input type="hidden" name="csrf_token" value="' . self::generateToken() . '">';
    }
}

// استخدامه في النماذج
echo CSRFProtection::getTokenField();

// التحقق عند الاستلام
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        CSRFProtection::validateToken($_POST['csrf_token']);
        // معالجة النموذج
    } catch (Exception $e) {
        die('طلب غير صالح');
    }
}
?>