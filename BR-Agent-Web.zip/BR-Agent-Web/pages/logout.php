<?php
session_start();

// تسجيل نشاط تسجيل الخروج
if (isset($_SESSION['user_id'])) {
    require_once '../config/db.php';
    
    $stmt = $pdo->prepare("
        INSERT INTO user_activity (user_id, activity_type, description)
        VALUES (?, 'logout', 'تسجيل الخروج من النظام')
    ");
    $stmt->execute([$_SESSION['user_id']]);
}

// تدمير الجلسة بالكامل
session_unset();
session_destroy();
session_write_close();

// توجيه لصفحة تسجيل الدخول مع رسالة نجاح
header('Location: login.php?logout=success');
exit();
?>