<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>النظام الإداري المتكامل</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- شريط التنقل -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <a href="index.php">
                    <i class="fas fa-chart-line"></i>
                    <span>النظام الإداري</span>
                </a>
            </div>
            
            <ul class="nav-menu">
                <li><a href="#home" class="active">الرئيسية</a></li>
                <li><a href="#features">المميزات</a></li>
                <li><a href="#about">عن النظام</a></li>
                <li><a href="#contact">اتصل بنا</a></li>
                <li class="dropdown">
                    <a href="#">الدخول <i class="fas fa-chevron-down"></i></a>
                    <div class="dropdown-content">
                        <a href="pages/login.php"><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</a>
                        <a href="pages/register.php"><i class="fas fa-user-plus"></i> إنشاء حساب</a>
                        <a href="pages/dashboard.php"><i class="fas fa-tachometer-alt"></i> لوحة التحكم</a>
                    </div>
                </li>
            </ul>
            
            <button class="menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <!-- القسم الرئيسي -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">
                    نظام إداري <span class="highlight">متكامل</span> لإدارة أعمالك
                </h1>
                <p class="hero-description">
                    نظام متطور لإدارة المستخدمين، التقارير، التنبيهات والإعدادات.
                    صمم خصيصاً لتسهيل عملياتك الإدارية وزيادة إنتاجيتك.
                </p>
                <div class="hero-buttons">
                    <a href="pages/register.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-rocket"></i> ابدأ مجاناً
                    </a>
                    <a href="#features" class="btn btn-outline btn-lg">
                        <i class="fas fa-play-circle"></i> شاهد الفيديو
                    </a>
                </div>
                
                <div class="hero-stats">
                    <div class="stat-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <h3>+1,200</h3>
                            <p>مستخدم نشط</p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-chart-bar"></i>
                        <div>
                            <h3>+5,400</h3>
                            <p>تقرير مولد</p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-shield-alt"></i>
                        <div>
                            <h3>99.9%</h3>
                            <p>نسبة أمان</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="hero-image">
                <img src="assets/images/dashboard-preview.png" alt="Dashboard Preview">
                <div class="floating-card card-1">
                    <i class="fas fa-bell"></i>
                    <p>تنبيه جديد</p>
                </div>
                <div class="floating-card card-2">
                    <i class="fas fa-chart-pie"></i>
                    <p>تحليل البيانات</p>
                </div>
                <div class="floating-card card-3">
                    <i class="fas fa-cog"></i>
                    <p>إعدادات سريعة</p>
                </div>
            </div>
        </div>
    </section>

    <!-- مميزات النظام -->
    <section id="features" class="features">
        <div class="container">
            <div class="section-header">
                <h2>مميزات النظام</h2>
                <p>اكتشف جميع المميزات المتقدمة التي نقدمها</p>
            </div>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    <h3>لوحة تحكم تفاعلية</h3>
                    <p>لوحة تحكم مصممة بعناية تعرض أهم الإحصائيات والبيانات بطريقة مرئية سهلة الفهم</p>
                    <a href="#" class="feature-link">المزيد <i class="fas fa-arrow-left"></i></a>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3>تقارير متقدمة</h3>
                    <p>أنشئ تقارير مفصلة مع إمكانية التصدير للPDF وExcel مع رسوم بيانية تفاعلية</p>
                    <a href="#" class="feature-link">المزيد <i class="fas fa-arrow-left"></i></a>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h3>نظام تنبيهات ذكي</h3>
                    <p>نظام تنبيهات متكامل مع إشعارات فورية عبر البريد الإلكتروني والتطبيق</p>
                    <a href="#" class="feature-link">المزيد <i class="fas fa-arrow-left"></i></a>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>حماية وأمان عالي</h3>
                    <p>نظام أمني متعدد الطبقات مع تشفير البيانات ومصادقة ثنائية العوامل</p>
                    <a href="#" class="feature-link">المزيد <i class="fas fa-arrow-left"></i></a>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3>تصميم متجاوب</h3>
                    <p>تصميم متكامل يعمل على جميع الأجهزة من الجوال إلى أجهزة الكمبيوتر المكتبية</p>
                    <a href="#" class="feature-link">المزيد <i class="fas fa-arrow-left"></i></a>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h3>إعدادات مرنة</h3>
                    <p>إعدادات متقدمة تتيح لك تخصيص النظام حسب احتياجات عملك ومتطلباتك</p>
                    <a href="#" class="feature-link">المزيد <i class="fas fa-arrow-left"></i></a>
                </div>
            </div>
        </div>
    </section>

    <!-- عن النظام -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <h2>لماذا تختار نظامنا؟</h2>
                <p>نظامنا الإداري صمم بخبرة سنوات لتلبية احتياجات الشركات والمؤسسات بجميع أحجامها</p>
                
                <div class="about-features">
                    <div class="about-feature">
                        <i class="fas fa-bolt"></i>
                        <div>
                            <h4>سرعة عالية</h4>
                            <p>أداء ممتاز مع أوقات تحميل سريعة حتى مع كميات كبيرة من البيانات</p>
                        </div>
                    </div>
                    
                    <div class="about-feature">
                        <i class="fas fa-headset"></i>
                        <div>
                            <h4>دعم فني 24/7</h4>
                            <p>فريق دعم فني متاح على مدار الساعة لمساعدتك في أي وقت</p>
                        </div>
                    </div>
                    
                    <div class="about-feature">
                        <i class="fas fa-sync-alt"></i>
                        <div>
                            <h4>تحديثات مستمرة</h4>
                            <p>تحديثات أسبوعية تضيف مزايا جديدة وتحسن من أداء النظام</p>
                        </div>
                    </div>
                    
                    <div class="about-feature">
                        <i class="fas fa-lock"></i>
                        <div>
                            <h4>خصوصية تامة</h4>
                            <p>بياناتك تبقى خاصة وآمنة مع سياسة خصوصية صارمة</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="about-image">
                <img src="assets/images/about-system.png" alt="About System">
            </div>
        </div>
    </section>

    <!-- اتصل بنا -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-header">
                <h2>اتصل بنا</h2>
                <p>لديك استفسار؟ نحن هنا لمساعدتك</p>
            </div>
            
            <div class="contact-content">
                <form class="contact-form" id="contactForm">
                    <div class="form-group">
                        <label for="name">الاسم الكامل</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">البريد الإلكتروني</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject">الموضوع</label>
                        <input type="text" id="subject" name="subject" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="message">الرسالة</label>
                        <textarea id="message" name="message" rows="5" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> إرسال الرسالة
                    </button>
                </form>
                
                <div class="contact-info">
                    <div class="info-card">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>العنوان</h4>
                            <p>الرياض، المملكة العربية السعودية</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h4>الهاتف</h4>
                            <p>+966 11 123 4567</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>البريد الإلكتروني</h4>
                            <p>info@admin-system.com</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>ساعات العمل</h4>
                            <p>الأحد - الخميس: 8 ص - 5 م</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- تذييل الصفحة -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="logo">
                        <i class="fas fa-chart-line"></i>
                        <span>النظام الإداري</span>
                    </div>
                    <p>نظام إداري متكامل لإدارة أعمالك بكفاءة واحترافية</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4>روابط سريعة</h4>
                    <ul>
                        <li><a href="index.php">الرئيسية</a></li>
                        <li><a href="pages/dashboard.php">لوحة التحكم</a></li>
                        <li><a href="pages/login.php">تسجيل الدخول</a></li>
                        <li><a href="pages/register.php">إنشاء حساب</a></li>
                        <li><a href="#features">المميزات</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>الموارد</h4>
                    <ul>
                        <li><a href="docs/privacy.pdf">سياسة الخصوصية</a></li>
                        <li><a href="docs/terms.pdf">شروط الاستخدام</a></li>
                        <li><a href="docs/help.pdf">مركز المساعدة</a></li>
                        <li><a href="docs/api.pdf">واجهة البرمجة</a></li>
                        <li><a href="sitemap.xml">خريطة الموقع</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>النشرة البريدية</h4>
                    <p>اشترك لتصلك آخر التحديثات والعروض</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="بريدك الإلكتروني" required>
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>© 2024 النظام الإداري المتكامل. جميع الحقوق محفوظة.</p>
                <p>تم التطوير بـ <i class="fas fa-heart"></i> في المملكة العربية السعودية</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/home.js"></script>
</body>
</html>