<?php
// includes/backup.php

class BackupSystem {
    public static function createBackup() {
        $backup_dir = '../backups/' . date('Y-m-d');
        if (!is_dir($backup_dir)) {
            mkdir($backup_dir, 0755, true);
        }
        
        $backup_file = $backup_dir . '/backup_' . date('H-i-s') . '.sql';
        
        // تصدير قاعدة البيانات
        $command = sprintf(
            'mysqldump -u%s -p%s %s > %s',
            DB_USER,
            DB_PASS,
            DB_NAME,
            $backup_file
        );
        
        exec($command, $output, $return_var);
        
        if ($return_var === 0) {
            // ضغط الملف
            $zip_file = $backup_file . '.zip';
            $zip = new ZipArchive();
            if ($zip->open($zip_file, ZipArchive::CREATE) === TRUE) {
                $zip->addFile($backup_file, 'database.sql');
                $zip->close();
                unlink($backup_file); // حذف الملف غير المضغوط
            }
            
            // حذف النسخ القديمة (احتفظ بآخر 7 أيام فقط)
            self::cleanOldBackups();
            
            return true;
        }
        
        return false;
    }
}
?>