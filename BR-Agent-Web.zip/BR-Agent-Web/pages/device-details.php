<?php
session_start();
require_once '../includes/auth_check.php';
require_once '../config/db.php';
require_once '../includes/functions.php';

$device_id = $_GET['id'] ?? '';

if (empty($device_id)) {
    header('Location: devices.php');
    exit();
}

// جلب معلومات الجهاز
$stmt = $pdo->prepare("
    SELECT d.*, u.full_name as created_by_name
    FROM devices d
    LEFT JOIN users u ON d.created_by = u.id
    WHERE d.device_id = :device_id
");
$stmt->execute([':device_id' => $device_id]);
$device = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$device) {
    header('Location: devices.php?error=device_not_found');
    exit();
}

// جلب المقاييس التاريخية (آخر 24 ساعة)
$stmt = $pdo->prepare("
    SELECT 
        DATE_FORMAT(timestamp, '%H:%i') as time,
        cpu_usage,
        ram_usage,
        disk_usage,
        network_up,
        network_down
    FROM device_metrics 
    WHERE device_id = :device_id 
    AND timestamp >= NOW() - INTERVAL 24 HOUR
    ORDER BY timestamp ASC
    LIMIT 100
");
$stmt->execute([':device_id' => $device_id]);
$metrics_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب النشاطات
$stmt = $pdo->prepare("
    SELECT 
        action,
        details,
        created_at,
        TIMEDIFF(NOW(), created_at) as time_ago
    FROM activity_logs 
    WHERE device_id = :device_id
    ORDER BY created_at DESC
    LIMIT 20
");
$stmt->execute([':device_id' => $device_id]);
$activities = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب الأوامر السابقة
$stmt = $pdo->prepare("
    SELECT 
        command,
        status,
        sent_at,
        executed_at,
        u.username as sent_by
    FROM device_commands dc
    LEFT JOIN users u ON dc.sent_by = u.id
    WHERE device_id = :device_id
    ORDER BY sent_at DESC
    LIMIT 10
");
$stmt->execute([':device_id' => $device_id]);
$commands = $stmt->fetchAll(PDO::FETCH_ASSOC);

// حساب الإحصائيات
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_data_points,
        AVG(cpu_usage) as avg_cpu,
        AVG(ram_usage) as avg_ram,
        AVG(disk_usage) as avg_disk,
        MIN(timestamp) as first_seen,
        MAX(timestamp) as last_data
    FROM device_metrics 
    WHERE device_id = :device_id
");
$stmt->execute([':device_id' => $device_id]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// تحديد حالة الجهاز
$status_class = 'offline';
$status_text = 'غير متصل';
$last_seen_time = strtotime($device['last_seen']);
$five_min_ago = time() - 300;

if ($device['is_active'] && $last_seen_time >= $five_min_ago) {
    $status_class = 'online';
    $status_text = 'متصل';
}

// تحذيرات الأداء
$warnings = [];
if ($device['cpu_usage'] > 80) $warnings[] = 'استخدام عالي للمعالج';
if ($device['ram_usage'] > 85) $warnings[] = 'استخدام عالي للذاكرة';
if ($device['disk_usage'] > 90) $warnings[] = 'مساحة تخزين منخفضة';
if (!$device['internet_status']) $warnings[] = 'الاتصال بالإنترنت مقطوع';

// تحضير بيانات المخططات
$chart_labels = [];
$chart_cpu = [];
$chart_ram = [];
$chart_disk = [];

foreach ($metrics_history as $metric) {
    $chart_labels[] = $metric['time'];
    $chart_cpu[] = $metric['cpu_usage'];
    $chart_ram[] = $metric['ram_usage'];
    $chart_disk[] = $metric['disk_usage'];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($device['device_name']); ?> - تفاصيل</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/devices.css">
    <link rel="stylesheet" href="../assets/css/device-details.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="container">
            <!-- رأس الصفحة -->
            <div class="page-header">
                <div class="device-header">
                    <div class="device-icon-large">
                        <i class="fas fa-desktop"></i>
                    </div>
                    <div class="device-title">
                        <h1 class="page-title"><?php echo htmlspecialchars($device['device_name']); ?></h1>
                        <div class="device-meta">
                            <span class="device-id"><?php echo $device['device_id']; ?></span>
                            <span class="device-group"><?php echo $device['device_group']; ?></span>
                            <span class="status-badge-large <?php echo $status_class; ?>">
                                <?php if ($status_class === 'online'): ?>
                                🟢 <?php echo $status_text; ?>
                                <?php elseif (!empty($warnings)): ?>
                                ⚠️ يحتاج انتباه
                                <?php else: ?>
                                🔴 <?php echo $status_text; ?>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="header-actions">
                    <button onclick="remoteControl('<?php echo $device['device_id']; ?>')" 
                            class="btn btn-success">
                        <i class="fas fa-desktop"></i> التحكم عن بعد
                    </button>
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" 
                                type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-cog"></i> إجراءات
                        </button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#" onclick="sendCommand('restart')">
                                <i class="fas fa-redo"></i> إعادة تشغيل
                            </a>
                            <a class="dropdown-item" href="#" onclick="sendCommand('shutdown')">
                                <i class="fas fa-power-off"></i> إيقاف تشغيل
                            </a>
                            <a class="dropdown-item" href="#" onclick="sendCommand('update')">
                                <i class="fas fa-sync"></i> تحديث الـAgent
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#" onclick="collectLogs()">
                                <i class="fas fa-download"></i> جمع السجلات
                            </a>
                            <a class="dropdown-item" href="#" onclick="runDiagnostics()">
                                <i class="fas fa-stethoscope"></i> تشخيص النظام
                            </a>
                        </div>
                    </div>
                    <a href="devices.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-right"></i> العودة
                    </a>
                </div>
            </div>

            <!-- التنبيهات إذا وجدت -->
            <?php if (!empty($warnings)): ?>
            <div class="alerts-container">
                <div class="alert alert-warning">
                    <h4><i class="fas fa-exclamation-triangle"></i> تنبيهات النظام</h4>
                    <ul>
                        <?php foreach ($warnings as $warning): ?>
                        <li><?php echo $warning; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>

            <!-- بطاقات الأداء -->
            <div class="performance-cards">
                <div class="perf-card cpu">
                    <div class="perf-header">
                        <h4><i class="fas fa-microchip"></i> المعالج</h4>
                        <span class="perf-value <?php echo $device['cpu_usage'] > 80 ? 'text-danger' : 'text-success'; ?>">
                            <?php echo $device['cpu_usage']; ?>%
                        </span>
                    </div>
                    <div class="perf-chart">
                        <canvas id="cpuChart" width="100" height="80"></canvas>
                    </div>
                    <div class="perf-details">
                        <span><?php echo $device['cpu_name']; ?></span>
                        <span><?php echo $device['cpu_cores']; ?> نواة</span>
                    </div>
                </div>
                
                <div class="perf-card ram">
                    <div class="perf-header">
                        <h4><i class="fas fa-memory"></i> الذاكرة</h4>
                        <span class="perf-value <?php echo $device['ram_usage'] > 85 ? 'text-warning' : 'text-info'; ?>">
                            <?php echo $device['ram_usage']; ?>%
                        </span>
                    </div>
                    <div class="perf-chart">
                        <canvas id="ramChart" width="100" height="80"></canvas>
                    </div>
                    <div class="perf-details">
                        <span>مستخدم: <?php echo round($device['total_ram_gb'] * $device['ram_usage'] / 100, 2); ?> جيجا</span>
                        <span>إجمالي: <?php echo $device['total_ram_gb']; ?> جيجا</span>
                    </div>
                </div>
                
                <div class="perf-card disk">
                    <div class="perf-header">
                        <h4><i class="fas fa-hdd"></i> القرص</h4>
                        <span class="perf-value <?php echo $device['disk_usage'] > 90 ? 'text-danger' : 'text-primary'; ?>">
                            <?php echo $device['disk_usage']; ?>%
                        </span>
                    </div>
                    <div class="perf-chart">
                        <canvas id="diskChart" width="100" height="80"></canvas>
                    </div>
                    <div class="perf-details">
                        <span>مستخدم: <?php echo round($device['total_disk_gb'] * $device['disk_usage'] / 100, 2); ?> جيجا</span>
                        <span>إجمالي: <?php echo $device['total_disk_gb']; ?> جيجا</span>
                    </div>
                </div>
                
                <div class="perf-card network">
                    <div class="perf-header">
                        <h4><i class="fas fa-wifi"></i> الشبكة</h4>
                        <span class="perf-value <?php echo $device['internet_status'] ? 'text-success' : 'text-danger'; ?>">
                            <?php echo $device['internet_status'] ? '🟢 متصل' : '🔴 مقطوع'; ?>
                        </span>
                    </div>
                    <div class="network-stats">
                        <div class="network-stat">
                            <span>⬆️ رفع</span>
                            <strong><?php echo round($device['network_up'] / 1024, 2); ?> ميجا/ث</strong>
                        </div>
                        <div class="network-stat">
                            <span>⬇️ تنزيل</span>
                            <strong><?php echo round($device['network_down'] / 1024, 2); ?> ميجا/ث</strong>
                        </div>
                    </div>
                    <div class="perf-details">
                        <span>IP: <?php echo $device['ip_address'] ?? 'غير معروف'; ?></span>
                        <span>MAC: <?php echo $device['mac_address'] ?? 'غير معروف'; ?></span>
                    </div>
                </div>
            </div>

            <!-- مخطط الأداء التاريخي -->
            <div class="card mt-4">
                <div class="card-header">
                    <h4><i class="fas fa-chart-line"></i> الأداء خلال 24 ساعة الماضية</h4>
                </div>
                <div class="card-body">
                    <canvas id="performanceChart" height="100"></canvas>
                </div>
            </div>

            <!-- المعلومات التفصيلية -->
            <div class="row mt-4">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h4><i class="fas fa-info-circle"></i> معلومات النظام</h4>
                        </div>
                        <div class="card-body">
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">نظام التشغيل</span>
                                    <span class="info-value"><?php echo $device['os_name']; ?> <?php echo $device['os_version']; ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">تاريخ الإضافة</span>
                                    <span class="info-value"><?php echo date('Y-m-d', strtotime($device['created_at'])); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">تم الإضافة بواسطة</span>
                                    <span class="info-value"><?php echo $device['created_by_name'] ?? 'غير معروف'; ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">آخر تحديث</span>
                                    <span class="info-value"><?php echo time_ago($device['updated_at']); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">الإصدار</span>
                                    <span class="info-value"><?php echo $device['agent_version'] ?? '1.0.0'; ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">فاصل التحديث</span>
                                    <span class="info-value">كل <?php echo $device['update_interval'] ?? 60; ?> ثانية</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h4><i class="fas fa-history"></i> آخر النشاطات</h4>
                        </div>
                        <div class="card-body">
                            <div class="activity-list">
                                <?php if (empty($activities)): ?>
                                <div class="empty-activity">
                                    <i class="fas fa-history fa-2x"></i>
                                    <p>لا توجد نشاطات مسجلة</p>
                                </div>
                                <?php else: ?>
                                    <?php foreach ($activities as $activity): ?>
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-circle"></i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-text"><?php echo $activity['details']; ?></div>
                                            <div class="activity-time">
                                                <?php echo date('H:i', strtotime($activity['created_at'])); ?>
                                                <span class="time-ago">(<?php echo format_time_ago($activity['time_ago']); ?>)</span>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الأوامر السابقة -->
            <div class="card mt-4">
                <div class="card-header">
                    <h4><i class="fas fa-terminal"></i> الأوامر المرسلة</h4>
                </div>
                <div class="card-body">
                    <div class="commands-list">
                        <?php if (empty($commands)): ?>
                        <div class="empty-commands">
                            <i class="fas fa-terminal fa-2x"></i>
                            <p>لم يتم إرسال أي أوامر</p>
                        </div>
                        <?php else: ?>
                        <table class="commands-table">
                            <thead>
                                <tr>
                                    <th>الأمر</th>
                                    <th>الحالة</th>
                                    <th>أرسل بواسطة</th>
                                    <th>وقت الإرسال</th>
                                    <th>وقت التنفيذ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($commands as $cmd): ?>
                                <tr>
                                    <td>
                                        <span class="command-badge">
                                            <?php echo get_command_name($cmd['command']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $cmd['status']; ?>">
                                            <?php echo $cmd['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $cmd['sent_by'] ?? 'نظام'; ?></td>
                                    <td><?php echo date('H:i', strtotime($cmd['sent_at'])); ?></td>
                                    <td>
                                        <?php if ($cmd['executed_at']): ?>
                                        <?php echo date('H:i', strtotime($cmd['executed_at'])); ?>
                                        <?php else: ?>
                                        <span class="text-muted">بانتظار التنفيذ</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/js/main.js"></script>
    <script>
        // تعريف متغيرات PHP لجافاسكربت
        const deviceData = {
            device_id: '<?php echo $device_id; ?>',
            device_name: '<?php echo addslashes($device['device_name']); ?>',
            status: '<?php echo $status_class; ?>',
            last_seen: '<?php echo $device['last_seen']; ?>'
        };
        
        const chartData = {
            labels: <?php echo json_encode($chart_labels); ?>,
            cpu: <?php echo json_encode($chart_cpu); ?>,
            ram: <?php echo json_encode($chart_ram); ?>,
            disk: <?php echo json_encode($chart_disk); ?>
        };
        
        // رسم مخططات الأداء
        document.addEventListener('DOMContentLoaded', function() {
            // مخطط المعالج (دائري)
            new Chart(document.getElementById('cpuChart'), {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: [
                            <?php echo $device['cpu_usage']; ?>,
                            100 - <?php echo $device['cpu_usage']; ?>
                        ],
                        backgroundColor: [
                            <?php echo $device['cpu_usage'] > 80 ? "'#e74c3c'" : "'#2ecc71'"; ?>,
                            '#f0f0f0'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    cutout: '70%',
                    responsive: false,
                    plugins: { legend: { display: false } }
                }
            });
            
            // مخطط الذاكرة (دائري)
            new Chart(document.getElementById('ramChart'), {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: [
                            <?php echo $device['ram_usage']; ?>,
                            100 - <?php echo $device['ram_usage']; ?>
                        ],
                        backgroundColor: [
                            <?php echo $device['ram_usage'] > 85 ? "'#f39c12'" : "'#3498db'"; ?>,
                            '#f0f0f0'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    cutout: '70%',
                    responsive: false,
                    plugins: { legend: { display: false } }
                }
            });
            
            // مخطط القرص (دائري)
            new Chart(document.getElementById('diskChart'), {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: [
                            <?php echo $device['disk_usage']; ?>,
                            100 - <?php echo $device['disk_usage']; ?>
                        ],
                        backgroundColor: [
                            <?php echo $device['disk_usage'] > 90 ? "'#e74c3c'" : "'#9b59b6'"; ?>,
                            '#f0f0f0'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    cutout: '70%',
                    responsive: false,
                    plugins: { legend: { display: false } }
                }
            });
            
            // مخطط الأداء التاريخي (خطي)
            const ctx = document.getElementById('performanceChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: chartData.labels,
                    datasets: [
                        {
                            label: 'المعالج %',
                            data: chartData.cpu,
                            borderColor: '#e74c3c',
                            backgroundColor: 'rgba(231, 76, 60, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'الذاكرة %',
                            data: chartData.ram,
                            borderColor: '#3498db',
                            backgroundColor: 'rgba(52, 152, 219, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'القرص %',
                            data: chartData.disk,
                            borderColor: '#9b59b6',
                            backgroundColor: 'rgba(155, 89, 182, 0.1)',
                            tension: 0.4,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    scales: {
                        x: {
                            display: true,
                            title: {
                                display: true,
                                text: 'الوقت'
                            }
                        },
                        y: {
                            display: true,
                            title: {
                                display: true,
                                text: 'النسبة %'
                            },
                            min: 0,
                            max: 100
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                            rtl: true
                        },
                        tooltip: {
                            rtl: true,
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ' + context.parsed.y + '%';
                                }
                            }
                        }
                    }
                }
            });
        });
        
        // إرسال أمر للجهاز
        function sendCommand(command) {
            if (!confirm(`هل أنت متأكد من إرسال أمر "${command}" للجهاز؟`)) {
                return;
            }
            
            fetch(`../api/send_command.php?device_id=${deviceData.device_id}&command=${command}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        alert(data.error || 'حدث خطأ في إرسال الأمر');
                    }
                })
                .catch(error => {
                    alert('خطأ في الاتصال: ' + error.message);
                });
        }
        
        // التحكم عن بعد
        function remoteControl() {
            fetch(`../api/send_command.php?device_id=${deviceData.device_id}&command=remote_control`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.rustdesk) {
                        const confirmMsg = `فتح RustDesk للتحكم عن بعد؟\n\nID: ${data.rustdesk.id}\nPassword: ${data.rustdesk.password}`;
                        
                        if (confirm(confirmMsg)) {
                            // محاولة فتح RustDesk
                            window.open(data.rustdesk.direct_link, '_blank');
                            
                            // عرض بيانات الاتصال في حالة فشل الفتح التلقائي
                            alert(`إذا لم يفتح RustDesk تلقائياً:\n\n1. افتح RustDesk\n2. أدخل ID: ${data.rustdesk.id}\n3. أدخل Password: ${data.rustdesk.password}`);
                        }
                    } else {
                        alert('فشل الاتصال بالجهاز أو لم يتم إعداد RustDesk');
                    }
                });
        }
        
        // جمع السجلات
        function collectLogs() {
            sendCommand('collect_logs');
        }
        
        // تشخيص النظام
        function runDiagnostics() {
            sendCommand('run_scan');
        }
        
        // تحديث تلقائي كل 30 ثانية إذا كان الجهاز متصلاً
        function autoRefresh() {
            if (deviceData.status === 'online') {
                setTimeout(() => {
                    location.reload();
                }, 30000); // 30 ثانية
            }
        }
        
        // بدء التحديث التلقائي
        autoRefresh();
    </script>
</body>
</html>