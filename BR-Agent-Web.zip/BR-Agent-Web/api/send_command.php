<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/auth_check.php';
require_once '../config/db.php';

$device_id = $_GET['device_id'] ?? '';
$command = $_GET['command'] ?? '';

if (empty($device_id) || empty($command)) {
    echo json_encode(['error' => 'بيانات غير مكتملة']);
    exit();
}

// التحقق من الصلاحيات
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'manager') {
    echo json_encode(['error' => 'غير مصرح لك']);
    exit();
}

// التحقق من وجود الجهاز
$stmt = $pdo->prepare("SELECT * FROM devices WHERE device_id = :device_id");
$stmt->execute([':device_id' => $device_id]);
$device = $stmt->fetch();

if (!$device) {
    echo json_encode(['error' => 'الجهاز غير موجود']);
    exit();
}

// معالجة الأوامر
$command_map = [
    'restart' => 'إعادة تشغيل',
    'shutdown' => 'إيقاف التشغيل',
    'update' => 'تحديث البرنامج',
    'collect_logs' => 'جمع السجلات',
    'run_scan' => 'فحص النظام',
    'backup' => 'إنشاء نسخة احتياطية'
];

if (!isset($command_map[$command])) {
    echo json_encode(['error' => 'الأمر غير معروف']);
    exit();
}

// حفظ الأمر في قاعدة البيانات (للتتبع)
$stmt = $pdo->prepare("
    INSERT INTO device_commands 
    (device_id, command, status, sent_by, sent_at)
    VALUES 
    (:device_id, :command, 'pending', :user_id, NOW())
");
$stmt->execute([
    ':device_id' => $device_id,
    ':command' => $command,
    ':user_id' => $_SESSION['user_id']
]);

// تسجيل النشاط
$stmt = $pdo->prepare("
    INSERT INTO activity_logs 
    (device_id, action, details, user_id)
    VALUES 
    (:device_id, 'command_sent', :details, :user_id)
");
$stmt->execute([
    ':device_id' => $device_id,
    ':details' => "تم إرسال أمر: {$command_map[$command]}",
    ':user_id' => $_SESSION['user_id']
]);

// محاكاة إرسال الأمر للجهاز (في الواقع هنا راح يرسل عبر WebSocket أو REST API)
$command_id = $pdo->lastInsertId();

// محاكاة تنفيذ الأمر بعد 2 ثانية
$response_data = [
    'success' => true,
    'message' => "تم إرسال الأمر '{$command_map[$command]}' للجهاز",
    'command_id' => $command_id,
    'estimated_time' => '10-30 ثانية'
];

// إذا كان الأمر هو التحكم عن بعد، نعيد بيانات RustDesk
if ($command === 'remote_control') {
    // توليد بيانات RustDesk
    require_once '../includes/rustdesk.php';
    $rustdesk_config = generateRustDeskConfig($device_id);
    
    $response_data['rustdesk'] = [
        'id' => $rustdesk_config['id'],
        'password' => $rustdesk_config['password'],
        'direct_link' => "rustdesk://{$rustdesk_config['id']}"
    ];
}

echo json_encode($response_data);
?>