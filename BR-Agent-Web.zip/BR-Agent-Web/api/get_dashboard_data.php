<?php
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $client = FirebaseConnection::getClient();
    
    if (!$client) {
        throw new Exception('فشل الاتصال بـ Firebase');
    }
    
    // جلب جميع البيانات مرة واحدة
    $data = [
        'metrics' => get_main_metrics($client),
        'recent_alerts' => get_recent_alerts($client),
        'recent_devices' => get_recent_devices($client),
        'charts' => get_charts_data($client)
    ];
    
    json_response([
        'success' => true,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    // بيانات وهمية للعرض عند فشل الاتصال
    json_response([
        'success' => false,
        'message' => $e->getMessage(),
        'data' => get_mock_data(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}

function get_main_metrics($client) {
    // جلب عدد الفروع
    $branchesRef = $client->collection('branches');
    $branchesCount = count(iterator_to_array($branchesRef->documents()));
    
    // جلب عدد الأجهزة
    $devicesRef = $client->collection('devices');
    $devices = iterator_to_array($devicesRef->documents());
    $devicesCount = count($devices);
    
    // حساب الأجهزة النشطة
    $activeDevices = 0;
    $totalCpu = 0;
    $deviceData = [];
    
    foreach ($devices as $doc) {
        if ($doc->exists()) {
            $device = $doc->data();
            $deviceData[] = $device;
            
            // التحقق إذا كان الجهاز نشطاً (آخر تحديث منذ أقل من 5 دقائق)
            if (isset($device['last_update'])) {
                $age = time() - strtotime($device['last_update']);
                if ($age < 300) {
                    $activeDevices++;
                }
            }
            
            // جمع استخدام CPU
            if (isset($device['cpu_percent'])) {
                $totalCpu += $device['cpu_percent'];
            }
        }
    }
    
    // جلب التنبيهات النشطة
    $alertsRef = $client->collection('alerts')
        ->where('resolved', '=', false);
    $activeAlerts = count(iterator_to_array($alertsRef->documents()));
    
    return [
        'total_branches' => $branchesCount,
        'total_devices' => $devicesCount,
        'active_devices' => $activeDevices,
        'avg_cpu' => $devicesCount > 0 ? round($totalCpu / $devicesCount, 1) : 0,
        'active_alerts' => $activeAlerts,
        'devices_data' => $deviceData
    ];
}

function get_recent_alerts($client) {
    $alertsRef = $client->collection('alerts')
        ->orderBy('timestamp', 'DESC')
        ->limit(10);
    
    $alerts = [];
    foreach ($alertsRef->documents() as $doc) {
        if ($doc->exists()) {
            $alert = $doc->data();
            $alert['id'] = $doc->id();
            $alert['time_ago'] = get_time_ago($alert['timestamp'] ?? null);
            $alerts[] = $alert;
        }
    }
    
    return $alerts;
}

function get_recent_devices($client) {
    $devicesRef = $client->collection('devices')
        ->orderBy('last_update', 'DESC')
        ->limit(10);
    
    $devices = [];
    foreach ($devicesRef->documents() as $doc) {
        if ($doc->exists()) {
            $device = $doc->data();
            $device['id'] = $doc->id();
            $device['status'] = calculate_device_status($device);
            $device['last_update_formatted'] = get_time_ago($device['last_update'] ?? null);
            $devices[] = $device;
        }
    }
    
    return $devices;
}

function get_charts_data($client) {
    // بيانات المخططات للـ 24 ساعة الماضية
    $charts = [
        'resource_usage' => [],
        'status_distribution' => [
            'سليم' => 0,
            'تحذير' => 0,
            'حرج' => 0,
            'غير متصل' => 0
        ]
    ];
    
    // توليد بيانات استخدام الموارد
    for ($i = 23; $i >= 0; $i--) {
        $hour = date('H:00', strtotime("-$i hours"));
        $charts['resource_usage'][] = [
            'time' => $hour,
            'cpu' => rand(30, 80),
            'memory' => rand(40, 85),
            'disk' => rand(50, 90)
        ];
    }
    
    return $charts;
}

function calculate_device_status($device) {
    // نفس الدالة السابقة
    $last_update = $device['last_update'] ?? null;
    if (!$last_update) {
        return 'غير متصل';
    }
    
    $age_seconds = time() - strtotime($last_update);
    if ($age_seconds > 600) {
        return 'غير متصل';
    }
    
    $anomaly_score = $device['anomaly_score'] ?? 0;
    if ($anomaly_score > 80) {
        return 'حرج';
    } elseif ($anomaly_score > 60) {
        return 'تحذير';
    }
    
    return 'سليم';
}

function get_mock_data() {
    // بيانات وهمية للعرض
    return [
        'metrics' => [
            'total_branches' => 3,
            'total_devices' => 15,
            'active_devices' => 12,
            'avg_cpu' => 45.5,
            'active_alerts' => 3
        ],
        'recent_alerts' => [
            [
                'id' => '1',
                'device_name' => 'SERVER-01',
                'type' => 'CPU_CRITICAL',
                'severity' => 'critical',
                'timestamp' => date('Y-m-d H:i:s', strtotime('-10 minutes')),
                'time_ago' => 'قبل 10 دقائق',
                'message' => 'استخدام CPU تجاوز 90%'
            ],
            [
                'id' => '2',
                'device_name' => 'SERVER-02',
                'type' => 'MEMORY_WARNING',
                'severity' => 'warning',
                'timestamp' => date('Y-m-d H:i:s', strtotime('-30 minutes')),
                'time_ago' => 'قبل 30 دقيقة',
                'message' => 'استخدام الذاكرة تجاوز 85%'
            ]
        ],
        'recent_devices' => [
            [
                'id' => '1',
                'device_name' => 'SERVER-01',
                'branch_id' => 'branch-01',
                'cpu_percent' => 65,
                'mem_percent' => 70,
                'status' => 'سليم',
                'last_update' => date('Y-m-d H:i:s'),
                'last_update_formatted' => 'الآن'
            ]
        ],
        'charts' => [
            'resource_usage' => [],
            'status_distribution' => [
                'سليم' => 8,
                'تحذير' => 3,
                'حرج' => 1,
                'غير متصل' => 3
            ]
        ]
    ];
}
?>